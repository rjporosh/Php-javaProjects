-- MySQL dump 10.13  Distrib 5.6.37, for Linux (x86_64)
--
-- Host: localhost    Database: rkgps_test
-- ------------------------------------------------------
-- Server version	5.6.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `es_1enquiry`
--

DROP TABLE IF EXISTS `es_1enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_1enquiry` (
  `es_enquiryid` int(11) NOT NULL AUTO_INCREMENT,
  `eq_serialno` int(11) NOT NULL,
  `eq_createdon` date NOT NULL,
  `eq_name` varchar(255) NOT NULL,
  `eq_address` varchar(255) NOT NULL,
  `eq_city` varchar(255) NOT NULL,
  `eq_wardname` varchar(255) NOT NULL,
  `eq_sex` varchar(255) NOT NULL,
  `eq_class` varchar(255) NOT NULL,
  `eq_phno` varchar(255) NOT NULL,
  `eq_mobile` varchar(255) NOT NULL,
  `eq_emailid` varchar(255) NOT NULL,
  `eq_reftype` varchar(255) NOT NULL,
  `eq_refname` varchar(255) NOT NULL,
  `eq_description` varchar(255) NOT NULL,
  `eq_formtype` varchar(255) NOT NULL,
  `eq_paymode` varchar(255) NOT NULL,
  `eq_chequeno` varchar(255) NOT NULL,
  `eq_bankname` varchar(255) NOT NULL,
  `eq_submitedon` date NOT NULL,
  `eq_acadamic` varchar(255) NOT NULL,
  `eq_marksobtain` int(11) NOT NULL,
  `eq_outof` int(11) NOT NULL,
  `eq_oralexam` varchar(255) NOT NULL,
  `eq_familyinteraction` varchar(255) NOT NULL,
  `eq_percentage` double NOT NULL,
  `eq_result` varchar(255) NOT NULL,
  `eq_amountpaid` varchar(255) NOT NULL,
  `eq_state` varchar(255) NOT NULL,
  `es_preadmissionid` int(11) NOT NULL,
  `eq_mothername` varchar(255) NOT NULL,
  `eq_zip` varchar(255) NOT NULL,
  `college_id` int(11) NOT NULL,
  `eq_prv_acdmic` text NOT NULL,
  `eq_countryid` varchar(255) NOT NULL,
  `eq_dob` date NOT NULL,
  `eq_application_no` varchar(255) NOT NULL,
  `es_voucherentryid` int(11) NOT NULL,
  `pre_class` varchar(255) NOT NULL,
  `scat_id` varchar(255) NOT NULL,
  PRIMARY KEY (`es_enquiryid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_1enquiry`
--

LOCK TABLES `es_1enquiry` WRITE;
/*!40000 ALTER TABLE `es_1enquiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_1enquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_academic`
--

DROP TABLE IF EXISTS `es_academic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_academic` (
  `es_aid` int(11) NOT NULL AUTO_INCREMENT,
  `es_achairman` varchar(255) NOT NULL,
  `es_atrep1` varchar(255) NOT NULL,
  `es_atrep2` varchar(255) NOT NULL,
  `es_atrep3` varchar(255) NOT NULL,
  `es_atrep4` varchar(255) NOT NULL,
  `es_atrep5` varchar(255) NOT NULL,
  `es_atrep6` varchar(255) NOT NULL,
  `es_apopassociation` varchar(255) NOT NULL,
  `es_status` varchar(255) NOT NULL,
  PRIMARY KEY (`es_aid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_academic`
--

LOCK TABLES `es_academic` WRITE;
/*!40000 ALTER TABLE `es_academic` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_academic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_addon_modules`
--

DROP TABLE IF EXISTS `es_addon_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_addon_modules` (
  `addon_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `v_admin` varchar(255) NOT NULL,
  `v_staff` varchar(255) NOT NULL,
  `v_n_staff` varchar(255) NOT NULL,
  `v_student` varchar(255) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `created_type` varchar(255) NOT NULL DEFAULT 'admin',
  `created_on` date NOT NULL,
  PRIMARY KEY (`addon_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_addon_modules`
--

LOCK TABLES `es_addon_modules` WRITE;
/*!40000 ALTER TABLE `es_addon_modules` DISABLE KEYS */;
INSERT INTO `es_addon_modules` (`addon_id`, `title`, `link`, `image`, `v_admin`, `v_staff`, `v_n_staff`, `v_student`, `created_by`, `created_type`, `created_on`) VALUES (1,'website URL','www.rettula.com','','N','N','N','N',1,'admin','2012-07-03');
/*!40000 ALTER TABLE `es_addon_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_admins`
--

DROP TABLE IF EXISTS `es_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_admins` (
  `es_adminsid` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_fname` varchar(255) NOT NULL,
  `user_type` enum('super','admin') NOT NULL,
  `user_theme` varchar(255) NOT NULL DEFAULT 'pink.css',
  `admin_lname` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_phoneno` varchar(255) NOT NULL,
  `admin_more` text NOT NULL,
  `admin_permissions` text NOT NULL,
  PRIMARY KEY (`es_adminsid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_admins`
--

LOCK TABLES `es_admins` WRITE;
/*!40000 ALTER TABLE `es_admins` DISABLE KEYS */;
INSERT INTO `es_admins` (`es_adminsid`, `admin_username`, `admin_password`, `admin_fname`, `user_type`, `user_theme`, `admin_lname`, `admin_email`, `admin_phoneno`, `admin_more`, `admin_permissions`) VALUES (1,'admin','admin','Admin','super','pink.css','Admin','dummymailler@gmail.com','12345556','','1_p,1_1,1_2,1_4,1_3,2_p,2_1,2_2,2_3,2_4,2_5,2_6,2_7,2_8,2_9,2_10,2_11,2_12,2_13,2_14,2_15,2_20,2_16,2_17,2_18,2_19,3_p,3_1,3_2,3_3,3_5,3_4,3_7,4_p,5_p,5_1,5_3,5_2,6_p,6_1,6_2,6_3,6_6,6_7,6_8,6_9,6_10,6_11,6_12,6_13,6_14,6_15,6_16,7_p,7_1,7_2,7_3,7_4,7_5,8_p,8_1,8_2,8_3,8_101,8_4,8_5,8_6,8_16,8_102,8_7,8_8,8_9,8_17,8_103,8_104,8_10,8_11,8_12,8_18,8_105,8_106,8_13,8_14,8_15,8_19,8_107,8_108,9_p,9_1,9_17,9_18,9_19,9_2,9_20,9_21,9_22,9_23,9_3,9_4,9_5,9_6,9_101,9_7,9_102,9_8,9_103,9_24,9_25,9_33,9_11,9_12,9_26,9_13,9_27,9_14,9_29,9_30,9_31,9_15,9_16,9_32,10_p,10_1,10_2,10_3,10_4,10_5,10_6,10_7,10_8,10_11,10_9,10_10,10_12,11_p,11_1,11_2,11_3,11_4,11_5,11_6,11_7,11_8,11_9,11_10,11_11,11_12,11_13,11_14,11_15,11_16,11_17,11_18,11_19,11_20,11_21,11_23,11_101,11_102,11_22,11_103,11_104,12_p,12_1,12_2,12_3,12_4,12_5,12_11,12_6,12_7,12_8,12_12,12_9,12_10,13_p,13_1,13_2,13_3,13_17,13_4,13_5,13_6,13_18,13_7,13_8,13_9,13_19,13_20,13_10,13_11,13_12,13_21,13_22,13_13,13_14,13_15,13_16,13_23,13_101,13_102,13_103,13_104,13_106,13_105,14_p,14_1,14_2,14_3,14_101,14_4,14_5,14_6,14_102,14_7,14_8,14_9,14_103,14_10,14_21,14_104,14_11,14_105,14_12,14_106,14_13,14_14,14_15,14_16,14_107,14_17,14_18,14_19,14_20,15_p,15_1,15_2,15_3,16_p,16_1,16_2,16_3,16_101,16_4,16_5,16_6,16_102,16_7,16_8,16_10,16_11,16_12,16_103,16_13,16_14,16_15,16_17,16_18,16_20,16_21,16_24,16_104,16_105,16_22,16_25,16_23,16_26,16_106,16_107,16_27,16_28,16_29,17_p,17_1,17_6,17_2,17_3,17_101,17_4,17_5,17_7,17_8,17_9,18_p,18_5,18_1,18_2,18_3,18_4,18_6,18_7,18_8,18_9,18_10,18_11,18_12,19_p,19_1,19_2,19_3,19_4,19_5,19_6,19_11,19_7,19_12,19_13,19_14,19_15,19_101,19_102,19_8,19_16,19_9,19_10,19_17,19_18,20_p,20_1,20_5,20_101,20_2,20_6,20_102,20_3,20_4,21_p,21_1,21_2,21_3,22_p,22_1,22_2,22_3,22_5,22_4,22_6,23_p,24_p,24_1,24_2,24_3,24_4,25_p,25_1,25_2,25_5,25_6,25_3,25_4,25_7,25_8,26_p,26_1,26_2,27_p,27_1,27_2,27_3,28_p,28_1,28_2,28_3,28_4,28_5,29_p,29_1,29_2,30_p,30_1,30_2,30_3,30_4,30_5,30_6,30_7,30_8,31_p,31_1,31_2,31_3,31_5,31_4,32_p,32_3,32_1,32_4,32_2,32_5,33_p,33_1,33_2,33_3,33_8,33_4,33_5,33_6,33_7,34_p,34_1,34_2,35_p,35_1,35_2,35_3,13_108,13_109,5_11,5_12,5_5,5_6,6_20,121_1,121_2,_121_3');
/*!40000 ALTER TABLE `es_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_allowencemaster`
--

DROP TABLE IF EXISTS `es_allowencemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_allowencemaster` (
  `es_allowencemasterid` int(11) NOT NULL AUTO_INCREMENT,
  `alw_post` varchar(255) NOT NULL,
  `alw_type` varchar(255) NOT NULL,
  `alw_fromdate` date NOT NULL,
  `alw_todate` date NOT NULL,
  `alw_amount` varchar(255) NOT NULL,
  `alw_amt_type` varchar(255) NOT NULL,
  `alw_dept` varchar(255) NOT NULL,
  PRIMARY KEY (`es_allowencemasterid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_allowencemaster`
--

LOCK TABLES `es_allowencemaster` WRITE;
/*!40000 ALTER TABLE `es_allowencemaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_allowencemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_assignment`
--

DROP TABLE IF EXISTS `es_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_assignment` (
  `es_assignmentid` int(11) NOT NULL AUTO_INCREMENT,
  `as_name` varchar(255) NOT NULL,
  `as_class` varchar(255) NOT NULL,
  `as_sec` varchar(255) NOT NULL,
  `as_suject` varchar(255) NOT NULL,
  `as_lastdate` date NOT NULL,
  `as_description` longtext NOT NULL,
  `as_createdon` date NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `as_marks` int(11) NOT NULL,
  `person_type` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`es_assignmentid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_assignment`
--

LOCK TABLES `es_assignment` WRITE;
/*!40000 ALTER TABLE `es_assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_attemptcerti`
--

DROP TABLE IF EXISTS `es_attemptcerti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_attemptcerti` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(35) NOT NULL,
  `state` varchar(35) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_attemptcerti`
--

LOCK TABLES `es_attemptcerti` WRITE;
/*!40000 ALTER TABLE `es_attemptcerti` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_attemptcerti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_attend_staff`
--

DROP TABLE IF EXISTS `es_attend_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_attend_staff` (
  `es_attend_staffid` int(11) NOT NULL AUTO_INCREMENT,
  `at_staff_dept` varchar(255) NOT NULL,
  `at_staff_date` datetime NOT NULL,
  `at_staff_id` varchar(255) NOT NULL,
  `at_staff_name` varchar(255) NOT NULL,
  `at_staff_desig` varchar(255) NOT NULL,
  `at_staff_attend` varchar(255) NOT NULL,
  `at_staff_remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`es_attend_staffid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_attend_staff`
--

LOCK TABLES `es_attend_staff` WRITE;
/*!40000 ALTER TABLE `es_attend_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_attend_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_attend_student`
--

DROP TABLE IF EXISTS `es_attend_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_attend_student` (
  `es_attend_studentid` int(11) NOT NULL AUTO_INCREMENT,
  `at_std_group` varchar(255) NOT NULL,
  `at_std_class` varchar(255) NOT NULL,
  `at_attendance_date` datetime NOT NULL,
  `at_std_subject` varchar(255) NOT NULL,
  `at_std_period` int(11) NOT NULL,
  `at_period_from` int(11) NOT NULL,
  `at_period_to` int(11) NOT NULL,
  `at_reg_no` varchar(255) NOT NULL,
  `at_stud_name` varchar(255) NOT NULL,
  `at_attendance` varchar(255) NOT NULL,
  `at_remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`es_attend_studentid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_attend_student`
--

LOCK TABLES `es_attend_student` WRITE;
/*!40000 ALTER TABLE `es_attend_student` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_attend_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_bonafied`
--

DROP TABLE IF EXISTS `es_bonafied`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_bonafied` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(35) NOT NULL,
  `state` varchar(35) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_bonafied`
--

LOCK TABLES `es_bonafied` WRITE;
/*!40000 ALTER TABLE `es_bonafied` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_bonafied` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_bonafiedbank`
--

DROP TABLE IF EXISTS `es_bonafiedbank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_bonafiedbank` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(35) NOT NULL,
  `state` varchar(35) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_bonafiedbank`
--

LOCK TABLES `es_bonafiedbank` WRITE;
/*!40000 ALTER TABLE `es_bonafiedbank` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_bonafiedbank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_book_orders`
--

DROP TABLE IF EXISTS `es_book_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_book_orders` (
  `es_bookordersid` int(11) NOT NULL AUTO_INCREMENT,
  `fld_booksupplier` varchar(255) NOT NULL,
  `fld_itempurchased` longtext NOT NULL,
  `fld_orderdate` datetime NOT NULL,
  `fld_recnote` int(11) NOT NULL,
  `fld_recdate` datetime NOT NULL,
  `fld_recbillno` varchar(255) NOT NULL,
  `fld_recitemsreceived` longtext NOT NULL,
  `fld_totalamount` float NOT NULL,
  `fld_orderstatus` enum('pending','complete') NOT NULL,
  `fld_status` enum('active','inactive','deleted') NOT NULL,
  PRIMARY KEY (`es_bookordersid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_book_orders`
--

LOCK TABLES `es_book_orders` WRITE;
/*!40000 ALTER TABLE `es_book_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_book_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_book_reservation`
--

DROP TABLE IF EXISTS `es_book_reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_book_reservation` (
  `reserv_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `staff_or_student_id` bigint(20) NOT NULL,
  `book_id` bigint(20) NOT NULL,
  `reservetype` enum('student','staff') NOT NULL,
  `reserved_on` date NOT NULL,
  `expired_on` date NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`reserv_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_book_reservation`
--

LOCK TABLES `es_book_reservation` WRITE;
/*!40000 ALTER TABLE `es_book_reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_book_reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_bookcategory`
--

DROP TABLE IF EXISTS `es_bookcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_bookcategory` (
  `es_bookcategoryid` int(11) NOT NULL AUTO_INCREMENT,
  `fld_categoryname` varchar(255) NOT NULL,
  `fld_description` varchar(255) NOT NULL,
  `fld_status` enum('active','inactive','deleted') NOT NULL,
  PRIMARY KEY (`es_bookcategoryid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_bookcategory`
--

LOCK TABLES `es_bookcategory` WRITE;
/*!40000 ALTER TABLE `es_bookcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_bookcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_bookinventory`
--

DROP TABLE IF EXISTS `es_bookinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_bookinventory` (
  `es_bookinventoryid` int(11) NOT NULL AUTO_INCREMENT,
  `fld_bookinventoryname` varchar(255) NOT NULL,
  `fld_shortname` varchar(255) NOT NULL,
  `fld_description` varchar(255) NOT NULL,
  `fld_status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`es_bookinventoryid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_bookinventory`
--

LOCK TABLES `es_bookinventory` WRITE;
/*!40000 ALTER TABLE `es_bookinventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_bookinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_bookissue`
--

DROP TABLE IF EXISTS `es_bookissue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_bookissue` (
  `es_bookissueid` int(11) NOT NULL AUTO_INCREMENT,
  `bki_id` bigint(20) NOT NULL,
  `bki_bookid` int(11) NOT NULL,
  `issuetype` varchar(255) NOT NULL,
  `issuedate` date NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`es_bookissueid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_bookissue`
--

LOCK TABLES `es_bookissue` WRITE;
/*!40000 ALTER TABLE `es_bookissue` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_bookissue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_booklets`
--

DROP TABLE IF EXISTS `es_booklets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_booklets` (
  `booklet_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `book_name` varchar(255) NOT NULL,
  `book_file` varchar(255) NOT NULL,
  `book_desc` longtext NOT NULL,
  `user_type` enum('admin','staff') NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created_on` date NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`booklet_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_booklets`
--

LOCK TABLES `es_booklets` WRITE;
/*!40000 ALTER TABLE `es_booklets` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_booklets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_bookreturns`
--

DROP TABLE IF EXISTS `es_bookreturns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_bookreturns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `book_id` bigint(20) NOT NULL,
  `return_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_bookreturns`
--

LOCK TABLES `es_bookreturns` WRITE;
/*!40000 ALTER TABLE `es_bookreturns` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_bookreturns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_booksupplier_master`
--

DROP TABLE IF EXISTS `es_booksupplier_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_booksupplier_master` (
  `fld_supplier_masterid` int(11) NOT NULL AUTO_INCREMENT,
  `fld_name` varchar(255) NOT NULL,
  `fld_address` varchar(255) NOT NULL,
  `fld_city` varchar(255) NOT NULL,
  `fld_state` varchar(255) NOT NULL,
  `fld_country` varchar(255) NOT NULL,
  `fld_office_no` varchar(255) NOT NULL,
  `fld_mobile_no` varchar(255) NOT NULL,
  `fld_email` varchar(255) NOT NULL,
  `fld_fax` varchar(255) NOT NULL,
  `fld_description` varchar(255) NOT NULL,
  `fld_status` enum('active','inactive','deleted') NOT NULL,
  PRIMARY KEY (`fld_supplier_masterid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_booksupplier_master`
--

LOCK TABLES `es_booksupplier_master` WRITE;
/*!40000 ALTER TABLE `es_booksupplier_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_booksupplier_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_branch`
--

DROP TABLE IF EXISTS `es_branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_branch` (
  `es_branchid` varchar(255) NOT NULL,
  `es_branchname` varchar(255) NOT NULL,
  `es_orderby` varchar(255) NOT NULL,
  PRIMARY KEY (`es_branchid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_branch`
--

LOCK TABLES `es_branch` WRITE;
/*!40000 ALTER TABLE `es_branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_candidate`
--

DROP TABLE IF EXISTS `es_candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_candidate` (
  `es_candidateid` int(11) NOT NULL AUTO_INCREMENT,
  `st_postaplied` varchar(255) NOT NULL,
  `st_firstname` varchar(255) NOT NULL,
  `st_lastname` varchar(255) NOT NULL,
  `st_gender` varchar(255) NOT NULL,
  `st_dob` varchar(255) NOT NULL,
  `st_primarysubject` varchar(255) NOT NULL,
  `st_fatherhusname` varchar(255) NOT NULL,
  `st_noofdughters` int(11) NOT NULL,
  `st_noofsons` int(11) NOT NULL,
  `st_email` varchar(255) NOT NULL,
  `st_mobilenocomunication` varchar(255) NOT NULL,
  `st_examp1` varchar(255) NOT NULL,
  `st_examp2` varchar(255) NOT NULL,
  `st_examp3` varchar(255) NOT NULL,
  `st_marks1` varchar(255) NOT NULL,
  `st_marks2` varchar(255) NOT NULL,
  `st_marks3` varchar(255) NOT NULL,
  `st_borduniversity1` varchar(255) NOT NULL,
  `st_borduniversity2` varchar(255) NOT NULL,
  `st_borduniversity3` varchar(255) NOT NULL,
  `st_year1` varchar(255) NOT NULL,
  `st_year2` varchar(255) NOT NULL,
  `st_year3` varchar(255) NOT NULL,
  `st_insititute1` varchar(255) NOT NULL,
  `st_insititute2` varchar(255) NOT NULL,
  `st_insititute3` varchar(255) NOT NULL,
  `st_position1` varchar(255) NOT NULL,
  `st_position2` varchar(255) NOT NULL,
  `st_position3` varchar(255) NOT NULL,
  `st_period1` varchar(255) NOT NULL,
  `st_period2` varchar(255) NOT NULL,
  `st_period3` varchar(255) NOT NULL,
  `st_pradress` varchar(255) NOT NULL,
  `st_prcity` varchar(255) NOT NULL,
  `st_prpincode` varchar(255) NOT NULL,
  `st_prphonecode` varchar(255) NOT NULL,
  `st_prstate` varchar(255) NOT NULL,
  `st_prresino` varchar(255) NOT NULL,
  `st_prcountry` varchar(255) NOT NULL,
  `st_prmobno` varchar(255) NOT NULL,
  `st_peadress` varchar(255) NOT NULL,
  `st_pecity` varchar(255) NOT NULL,
  `st_pepincode` varchar(255) NOT NULL,
  `st_pephoneno` varchar(255) NOT NULL,
  `st_pestate` varchar(255) NOT NULL,
  `st_peresino` varchar(255) NOT NULL,
  `st_pecountry` varchar(255) NOT NULL,
  `st_pemobileno` varchar(255) NOT NULL,
  `st_refposname1` varchar(255) NOT NULL,
  `st_refposname2` varchar(255) NOT NULL,
  `st_refposname3` varchar(255) NOT NULL,
  `st_refdesignation1` varchar(255) NOT NULL,
  `st_refdesignation2` varchar(255) NOT NULL,
  `st_refdesignation3` varchar(255) NOT NULL,
  `st_refinsititute1` varchar(255) NOT NULL,
  `st_refinsititute2` varchar(255) NOT NULL,
  `st_refinsititute3` varchar(255) NOT NULL,
  `st_refemail1` varchar(255) NOT NULL,
  `st_refemail2` varchar(255) NOT NULL,
  `st_refemail3` varchar(255) NOT NULL,
  `st_writentest` varchar(255) NOT NULL,
  `st_technicalinterview` varchar(255) NOT NULL,
  `st_finalinterview` varchar(255) NOT NULL,
  `status` enum('selected','notselected','onhold') NOT NULL,
  `st_perviouspackage` varchar(255) NOT NULL,
  `st_basic` varchar(255) NOT NULL,
  `st_dateofjoining` varchar(255) NOT NULL,
  `st_post` varchar(255) NOT NULL,
  `st_department` varchar(255) NOT NULL,
  `st_remarks` varchar(255) NOT NULL,
  `st_qualification` varchar(255) NOT NULL,
  `st_class` varchar(255) NOT NULL,
  `es_staffid` int(11) NOT NULL,
  `staff_status` enum('addedtostaff','notadded') NOT NULL,
  `st_emailsend` varchar(255) NOT NULL,
  PRIMARY KEY (`es_candidateid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_candidate`
--

LOCK TABLES `es_candidate` WRITE;
/*!40000 ALTER TABLE `es_candidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_caste`
--

DROP TABLE IF EXISTS `es_caste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_caste` (
  `caste_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `caste` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`caste_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_caste`
--

LOCK TABLES `es_caste` WRITE;
/*!40000 ALTER TABLE `es_caste` DISABLE KEYS */;
INSERT INTO `es_caste` (`caste_id`, `caste`, `created_on`) VALUES (1,'OBC','2012-07-02'),(2,'General','2012-07-02'),(3,'SC','2012-07-02'),(4,'ST','2012-07-02');
/*!40000 ALTER TABLE `es_caste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_categorylibrary`
--

DROP TABLE IF EXISTS `es_categorylibrary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_categorylibrary` (
  `es_categorylibraryid` int(11) NOT NULL AUTO_INCREMENT,
  `lb_categoryname` varchar(255) NOT NULL,
  `lb_catdesc` longtext NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`es_categorylibraryid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_categorylibrary`
--

LOCK TABLES `es_categorylibrary` WRITE;
/*!40000 ALTER TABLE `es_categorylibrary` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_categorylibrary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_chapters`
--

DROP TABLE IF EXISTS `es_chapters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_chapters` (
  `chapter_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` int(11) NOT NULL,
  `chapter_name` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`chapter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_chapters`
--

LOCK TABLES `es_chapters` WRITE;
/*!40000 ALTER TABLE `es_chapters` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_chapters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_charcerti`
--

DROP TABLE IF EXISTS `es_charcerti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_charcerti` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_charcerti`
--

LOCK TABLES `es_charcerti` WRITE;
/*!40000 ALTER TABLE `es_charcerti` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_charcerti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_classes`
--

DROP TABLE IF EXISTS `es_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_classes` (
  `es_classesid` int(11) NOT NULL AUTO_INCREMENT,
  `classid` float NOT NULL,
  `es_classname` varchar(255) NOT NULL,
  `es_orderby` int(11) NOT NULL,
  `es_groupid` int(11) NOT NULL,
  PRIMARY KEY (`es_classesid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_classes`
--

LOCK TABLES `es_classes` WRITE;
/*!40000 ALTER TABLE `es_classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_classifieds`
--

DROP TABLE IF EXISTS `es_classifieds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_classifieds` (
  `es_classifiedsid` int(11) NOT NULL AUTO_INCREMENT,
  `cfs_name` varchar(255) NOT NULL,
  `cfs_modeofadds` varchar(255) NOT NULL,
  `cfs_posteddate` date NOT NULL,
  `cfs_details` longtext NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`es_classifiedsid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_classifieds`
--

LOCK TABLES `es_classifieds` WRITE;
/*!40000 ALTER TABLE `es_classifieds` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_classifieds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_deductionmaster`
--

DROP TABLE IF EXISTS `es_deductionmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_deductionmaster` (
  `es_deductionmasterid` int(11) NOT NULL AUTO_INCREMENT,
  `ded_post` varchar(255) NOT NULL,
  `ded_type` varchar(255) NOT NULL,
  `ded_fromdate` date NOT NULL,
  `ded_todate` date NOT NULL,
  `ded_amount` varchar(255) NOT NULL,
  `ded_amt_type` varchar(255) NOT NULL,
  `ded_dept` varchar(255) NOT NULL,
  PRIMARY KEY (`es_deductionmasterid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_deductionmaster`
--

LOCK TABLES `es_deductionmaster` WRITE;
/*!40000 ALTER TABLE `es_deductionmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_deductionmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_departments`
--

DROP TABLE IF EXISTS `es_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_departments` (
  `es_departmentsid` int(11) NOT NULL AUTO_INCREMENT,
  `deptid` varchar(12) NOT NULL,
  `es_deptname` varchar(255) NOT NULL,
  `es_orderby` int(11) NOT NULL,
  `es_groupid` int(11) NOT NULL,
  PRIMARY KEY (`es_departmentsid`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_departments`
--

LOCK TABLES `es_departments` WRITE;
/*!40000 ALTER TABLE `es_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_deptposts`
--

DROP TABLE IF EXISTS `es_deptposts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_deptposts` (
  `es_deptpostsid` int(11) NOT NULL AUTO_INCREMENT,
  `es_postshortname` varchar(255) NOT NULL,
  `es_postcode` varchar(255) NOT NULL,
  `es_postname` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`es_deptpostsid`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_deptposts`
--

LOCK TABLES `es_deptposts` WRITE;
/*!40000 ALTER TABLE `es_deptposts` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_deptposts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_dispatch`
--

DROP TABLE IF EXISTS `es_dispatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_dispatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dispatch_category` varchar(255) NOT NULL,
  `status` enum('Active','Inactive','Delete') NOT NULL DEFAULT 'Active',
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_dispatch`
--

LOCK TABLES `es_dispatch` WRITE;
/*!40000 ALTER TABLE `es_dispatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_dispatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_dispatch_entry`
--

DROP TABLE IF EXISTS `es_dispatch_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_dispatch_entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dispatchgroup` int(11) NOT NULL,
  `dateofdispatch` date NOT NULL,
  `received_company` varchar(255) NOT NULL,
  `received_address` text NOT NULL,
  `subject` varchar(255) NOT NULL,
  `partculars` text NOT NULL,
  `reference_no` varchar(255) NOT NULL,
  `recived_by` varchar(255) NOT NULL,
  `submited_to` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `latter_status` enum('Open','Closed') NOT NULL DEFAULT 'Closed',
  `status` enum('Active','Inactive','Delete') NOT NULL DEFAULT 'Active',
  `out_sender` varchar(255) NOT NULL,
  `out_to` varchar(255) NOT NULL,
  `out_address` text NOT NULL,
  `out_type` varchar(255) NOT NULL,
  `out_sentthrough` varchar(255) NOT NULL,
  `in_receivedthrough` varchar(255) NOT NULL,
  `consignment_no` varchar(255) NOT NULL,
  `dispatch_type` varchar(255) NOT NULL,
  `outward_dispatch_type` varchar(255) NOT NULL,
  `d_letter_types` varchar(255) NOT NULL,
  `p_latter_id` int(11) NOT NULL,
  `courrier_name` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_dispatch_entry`
--

LOCK TABLES `es_dispatch_entry` WRITE;
/*!40000 ALTER TABLE `es_dispatch_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_dispatch_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_eligibilitycerti`
--

DROP TABLE IF EXISTS `es_eligibilitycerti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_eligibilitycerti` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(35) NOT NULL,
  `state` varchar(35) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_eligibilitycerti`
--

LOCK TABLES `es_eligibilitycerti` WRITE;
/*!40000 ALTER TABLE `es_eligibilitycerti` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_eligibilitycerti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_enquiry`
--

DROP TABLE IF EXISTS `es_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_enquiry` (
  `es_enquiryid` int(11) NOT NULL AUTO_INCREMENT,
  `eq_serialno` int(11) NOT NULL,
  `eq_createdon` date NOT NULL,
  `eq_name` varchar(255) NOT NULL,
  `eq_address` varchar(255) NOT NULL,
  `eq_city` varchar(255) NOT NULL,
  `eq_wardname` varchar(255) NOT NULL,
  `eq_sex` varchar(255) NOT NULL,
  `eq_class` varchar(255) NOT NULL,
  `eq_phno` varchar(255) NOT NULL,
  `eq_mobile` varchar(255) NOT NULL,
  `eq_emailid` varchar(255) NOT NULL,
  `eq_reftype` varchar(255) NOT NULL,
  `eq_refname` varchar(255) NOT NULL,
  `eq_description` varchar(255) NOT NULL,
  `eq_formtype` varchar(255) NOT NULL,
  `eq_paymode` varchar(255) NOT NULL,
  `eq_chequeno` varchar(255) NOT NULL,
  `eq_bankname` varchar(255) NOT NULL,
  `eq_submitedon` date NOT NULL,
  `eq_acadamic` varchar(255) NOT NULL,
  `eq_marksobtain` int(11) NOT NULL,
  `eq_outof` int(11) NOT NULL,
  `eq_oralexam` varchar(255) NOT NULL,
  `eq_familyinteraction` varchar(255) NOT NULL,
  `eq_percentage` double NOT NULL,
  `eq_result` varchar(255) NOT NULL,
  `eq_amountpaid` varchar(255) NOT NULL,
  `eq_state` varchar(255) NOT NULL,
  `es_preadmissionid` int(11) NOT NULL,
  `eq_mothername` varchar(255) NOT NULL,
  `eq_zip` varchar(255) NOT NULL,
  `college_id` int(11) NOT NULL,
  `eq_prv_acdmic` text NOT NULL,
  `eq_countryid` varchar(255) NOT NULL,
  `eq_dob` date NOT NULL,
  `eq_application_no` varchar(255) NOT NULL,
  `es_voucherentryid` int(11) NOT NULL,
  `pre_class` varchar(255) NOT NULL,
  `scat_id` varchar(255) NOT NULL,
  PRIMARY KEY (`es_enquiryid`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_enquiry`
--

LOCK TABLES `es_enquiry` WRITE;
/*!40000 ALTER TABLE `es_enquiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_enquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_enquiry2jul2012`
--

DROP TABLE IF EXISTS `es_enquiry2jul2012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_enquiry2jul2012` (
  `es_enquiryid` int(11) NOT NULL AUTO_INCREMENT,
  `eq_serialno` int(11) NOT NULL,
  `eq_createdon` date NOT NULL,
  `eq_name` varchar(255) NOT NULL,
  `eq_permaddress` varchar(255) NOT NULL,
  `eq_tempaddress` varchar(255) NOT NULL,
  `eq_city` varchar(255) NOT NULL,
  `eq_wardname` varchar(255) NOT NULL,
  `eq_sex` varchar(255) NOT NULL,
  `eq_class` varchar(255) NOT NULL,
  `eq_phno` varchar(255) NOT NULL,
  `eq_canmobile` varchar(255) NOT NULL,
  `eq_fathmobile` varchar(255) NOT NULL,
  `eq_emailid` varchar(255) NOT NULL,
  `eq_reftype` varchar(255) NOT NULL,
  `eq_refname` varchar(255) NOT NULL,
  `eq_description` varchar(255) NOT NULL,
  `eq_formtype` varchar(255) NOT NULL,
  `eq_paymode` varchar(255) NOT NULL,
  `eq_chequeno` varchar(255) NOT NULL,
  `eq_bankname` varchar(255) NOT NULL,
  `eq_submitedon` date NOT NULL,
  `eq_acadamic` varchar(255) NOT NULL,
  `eq_marksobtain` int(11) NOT NULL,
  `eq_outof` int(11) NOT NULL,
  `eq_oralexam` varchar(255) NOT NULL,
  `eq_familyinteraction` varchar(255) NOT NULL,
  `eq_percentage` double NOT NULL,
  `eq_result` varchar(255) NOT NULL,
  `eq_amountpaid` varchar(255) NOT NULL,
  `eq_state` varchar(255) NOT NULL,
  `es_preadmissionid` int(11) NOT NULL,
  `eq_mothername` varchar(255) NOT NULL,
  `eq_zip` varchar(255) NOT NULL,
  `college_id` int(11) NOT NULL,
  `eq_prv_acdmic` text NOT NULL,
  `eq_bs1` varchar(255) NOT NULL,
  `eq_bs2` varchar(255) NOT NULL,
  `eq_bs3` varchar(255) NOT NULL,
  `eq_bs4` varchar(255) NOT NULL,
  `eq_py1` varchar(255) NOT NULL,
  `eq_py2` varchar(255) NOT NULL,
  `eq_py3` varchar(255) NOT NULL,
  `eq_py4` varchar(255) NOT NULL,
  `eq_sub1` varchar(255) NOT NULL,
  `eq_sub2` varchar(255) NOT NULL,
  `eq_sub3` varchar(255) NOT NULL,
  `eq_sub4` varchar(255) NOT NULL,
  `eq_per1` varchar(255) NOT NULL,
  `eq_per2` varchar(255) NOT NULL,
  `eq_per3` varchar(255) NOT NULL,
  `eq_per4` varchar(255) NOT NULL,
  `eq_countryid` varchar(255) NOT NULL,
  `eq_dob` date NOT NULL,
  `eq_application_no` varchar(255) NOT NULL,
  `es_voucherentryid` int(11) NOT NULL,
  `pre_class` varchar(255) NOT NULL,
  `scat_id` varchar(255) NOT NULL,
  PRIMARY KEY (`es_enquiryid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_enquiry2jul2012`
--

LOCK TABLES `es_enquiry2jul2012` WRITE;
/*!40000 ALTER TABLE `es_enquiry2jul2012` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_enquiry2jul2012` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_exam`
--

DROP TABLE IF EXISTS `es_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_exam` (
  `es_examid` int(11) NOT NULL AUTO_INCREMENT,
  `es_examname` varchar(255) NOT NULL,
  `es_examordby` int(11) NOT NULL,
  PRIMARY KEY (`es_examid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_exam`
--

LOCK TABLES `es_exam` WRITE;
/*!40000 ALTER TABLE `es_exam` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_exam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_exam_academic`
--

DROP TABLE IF EXISTS `es_exam_academic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_exam_academic` (
  `es_exam_academicid` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `academic_year` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`es_exam_academicid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_exam_academic`
--

LOCK TABLES `es_exam_academic` WRITE;
/*!40000 ALTER TABLE `es_exam_academic` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_exam_academic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_exam_details`
--

DROP TABLE IF EXISTS `es_exam_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_exam_details` (
  `es_exam_detailsid` int(11) NOT NULL AUTO_INCREMENT,
  `academicexam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `exam_date` datetime NOT NULL,
  `exam_duration` varchar(255) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `pass_marks` int(11) NOT NULL,
  `upload_exam_paper` longtext NOT NULL,
  PRIMARY KEY (`es_exam_detailsid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_exam_details`
--

LOCK TABLES `es_exam_details` WRITE;
/*!40000 ALTER TABLE `es_exam_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_exam_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_exam_details_old`
--

DROP TABLE IF EXISTS `es_exam_details_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_exam_details_old` (
  `es_exam_detailsid` int(11) NOT NULL AUTO_INCREMENT,
  `academicexam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `exam_date` datetime NOT NULL,
  `exam_duration` varchar(255) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `pass_marks` int(11) NOT NULL,
  `venue` longtext NOT NULL,
  PRIMARY KEY (`es_exam_detailsid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_exam_details_old`
--

LOCK TABLES `es_exam_details_old` WRITE;
/*!40000 ALTER TABLE `es_exam_details_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_exam_details_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_examfee`
--

DROP TABLE IF EXISTS `es_examfee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_examfee` (
  `exam_fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_preadmissionid` bigint(20) NOT NULL,
  `fine_name` varchar(255) NOT NULL,
  `fine_amount` double NOT NULL,
  `created_on` date NOT NULL,
  `paid_amount` double NOT NULL,
  `deduction_allowed` double NOT NULL,
  `paid_on` date NOT NULL,
  `balance` double NOT NULL,
  `remarks` text NOT NULL,
  `voucherid` varchar(255) NOT NULL,
  PRIMARY KEY (`exam_fee_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_examfee`
--

LOCK TABLES `es_examfee` WRITE;
/*!40000 ALTER TABLE `es_examfee` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_examfee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_execommittee`
--

DROP TABLE IF EXISTS `es_execommittee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_execommittee` (
  `es_exid` int(11) NOT NULL AUTO_INCREMENT,
  `es_chairman` varchar(255) NOT NULL,
  `es_vchairman` varchar(255) NOT NULL,
  `es_secretary` varchar(255) NOT NULL,
  `es_jointsecretary` varchar(255) NOT NULL,
  `es_teachrep` varchar(255) NOT NULL,
  `es_partrep` varchar(255) NOT NULL,
  `es_reservedrep` varchar(255) NOT NULL,
  `es_total` varchar(255) NOT NULL,
  `es_eduinst` varchar(255) NOT NULL,
  `es_add1` varchar(255) NOT NULL,
  `es_nopresodent` varchar(255) NOT NULL,
  `es_add2` varchar(255) NOT NULL,
  `es_phno2` varchar(255) NOT NULL,
  `es_nosecretary` varchar(255) NOT NULL,
  `es_add3` varchar(255) NOT NULL,
  `es_phno3` varchar(255) NOT NULL,
  `es_status` varchar(255) NOT NULL,
  PRIMARY KEY (`es_exid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_execommittee`
--

LOCK TABLES `es_execommittee` WRITE;
/*!40000 ALTER TABLE `es_execommittee` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_execommittee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_expcerti`
--

DROP TABLE IF EXISTS `es_expcerti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_expcerti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `aced_year` varchar(255) NOT NULL,
  `doj` varchar(255) NOT NULL,
  `charac` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_on` varchar(255) NOT NULL,
  `conduct` varchar(255) NOT NULL,
  `dept` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_expcerti`
--

LOCK TABLES `es_expcerti` WRITE;
/*!40000 ALTER TABLE `es_expcerti` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_expcerti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_fa_groups`
--

DROP TABLE IF EXISTS `es_fa_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_fa_groups` (
  `es_fa_groupsid` int(11) NOT NULL AUTO_INCREMENT,
  `fa_groupname` varchar(255) NOT NULL,
  `fa_undergroup` varchar(255) NOT NULL,
  `fa_display` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`es_fa_groupsid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_fa_groups`
--

LOCK TABLES `es_fa_groups` WRITE;
/*!40000 ALTER TABLE `es_fa_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_fa_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_fee_inst_last_date`
--

DROP TABLE IF EXISTS `es_fee_inst_last_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_fee_inst_last_date` (
  `inst_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_finance_masterid` int(11) NOT NULL,
  `instalment_no` int(11) NOT NULL,
  `last_date` date NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`inst_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_fee_inst_last_date`
--

LOCK TABLES `es_fee_inst_last_date` WRITE;
/*!40000 ALTER TABLE `es_fee_inst_last_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_fee_inst_last_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_feemaster`
--

DROP TABLE IF EXISTS `es_feemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_feemaster` (
  `es_feemasterid` int(11) NOT NULL AUTO_INCREMENT,
  `fee_particular` varchar(255) NOT NULL,
  `fee_class` int(11) NOT NULL,
  `fee_amount` double NOT NULL,
  `fee_instalments` int(11) NOT NULL,
  `fee_extra1` varchar(255) NOT NULL,
  `fee_extra2` varchar(255) NOT NULL,
  `fee_fromdate` date NOT NULL,
  `fee_todate` date NOT NULL,
  PRIMARY KEY (`es_feemasterid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_feemaster`
--

LOCK TABLES `es_feemaster` WRITE;
/*!40000 ALTER TABLE `es_feemaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_feemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_feepaid`
--

DROP TABLE IF EXISTS `es_feepaid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_feepaid` (
  `es_feepaidid` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` bigint(20) NOT NULL,
  `class` varchar(255) NOT NULL,
  `particularid` int(11) NOT NULL,
  `particulartname` varchar(255) NOT NULL,
  `feeamount` float NOT NULL,
  `date` date NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `es_installment` int(11) NOT NULL,
  `fi_fromdate` date NOT NULL,
  `fi_todate` date NOT NULL,
  `es_voucherentryid` int(11) NOT NULL,
  `fee_waived` varchar(255) NOT NULL,
  `fid` varchar(100) DEFAULT NULL,
  `month_number` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`es_feepaidid`)
) ENGINE=MyISAM AUTO_INCREMENT=838 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_feepaid`
--

LOCK TABLES `es_feepaid` WRITE;
/*!40000 ALTER TABLE `es_feepaid` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_feepaid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_feepaid_new`
--

DROP TABLE IF EXISTS `es_feepaid_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_feepaid_new` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `es_preadmissionid` bigint(20) NOT NULL,
  `financemaster_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `paid_on` date NOT NULL,
  `voucherid` int(50) NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_feepaid_new`
--

LOCK TABLES `es_feepaid_new` WRITE;
/*!40000 ALTER TABLE `es_feepaid_new` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_feepaid_new` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_feepaid_new_details`
--

DROP TABLE IF EXISTS `es_feepaid_new_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_feepaid_new_details` (
  `fp_det_id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL,
  `particulars` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  `particularid` varchar(100) DEFAULT NULL,
  `studentid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`fp_det_id`)
) ENGINE=MyISAM AUTO_INCREMENT=627 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_feepaid_new_details`
--

LOCK TABLES `es_feepaid_new_details` WRITE;
/*!40000 ALTER TABLE `es_feepaid_new_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_feepaid_new_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_feesnotice`
--

DROP TABLE IF EXISTS `es_feesnotice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_feesnotice` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(222) NOT NULL,
  `state` varchar(222) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `fee` varchar(230) NOT NULL,
  `subject` varchar(230) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_feesnotice`
--

LOCK TABLES `es_feesnotice` WRITE;
/*!40000 ALTER TABLE `es_feesnotice` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_feesnotice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_finance_master`
--

DROP TABLE IF EXISTS `es_finance_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_finance_master` (
  `es_finance_masterid` int(11) NOT NULL AUTO_INCREMENT,
  `fi_startdate` date NOT NULL,
  `fi_enddate` date NOT NULL,
  `fi_address` text NOT NULL,
  `fi_currency` varchar(255) NOT NULL,
  `fi_symbol` varchar(255) NOT NULL,
  `fi_email` varchar(255) NOT NULL,
  `fi_initialbalance` float NOT NULL,
  `fi_phoneno` varchar(255) NOT NULL,
  `fi_school_logo` varchar(255) NOT NULL,
  `fi_website` varchar(255) NOT NULL,
  `fi_ac_startdate` date NOT NULL,
  `fi_ac_enddate` date NOT NULL,
  `fi_schoolname` varchar(255) NOT NULL,
  `fi_endclass` varchar(255) NOT NULL,
  PRIMARY KEY (`es_finance_masterid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_finance_master`
--

LOCK TABLES `es_finance_master` WRITE;
/*!40000 ALTER TABLE `es_finance_master` DISABLE KEYS */;
INSERT INTO `es_finance_master` (`es_finance_masterid`, `fi_startdate`, `fi_enddate`, `fi_address`, `fi_currency`, `fi_symbol`, `fi_email`, `fi_initialbalance`, `fi_phoneno`, `fi_school_logo`, `fi_website`, `fi_ac_startdate`, `fi_ac_enddate`, `fi_schoolname`, `fi_endclass`) VALUES (1,'2014-04-01','2015-03-31','Rajiv Nagar,Chianki,Medininagar,Palamu,Jharkhand-822102.','INR','Rs','rkgpsschool@gmail.com',0,'+919890977983','st_10052017_011042_logo1.jpg','www.freeschoolerp.org','2014-04-01','2015-03-31','Free School ERP School','CBSE aff');
/*!40000 ALTER TABLE `es_finance_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_fine_charged_collected`
--

DROP TABLE IF EXISTS `es_fine_charged_collected`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_fine_charged_collected` (
  `es_fcc_id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` bigint(20) NOT NULL,
  `class` int(11) NOT NULL,
  `es_feemasterid` int(11) NOT NULL,
  `fine_amount` double NOT NULL,
  `amount_paid` double NOT NULL,
  `deduction_allowed` double NOT NULL,
  `es_installment` int(11) NOT NULL,
  `date` date NOT NULL,
  `fi_fromdate` date NOT NULL,
  `fi_todate` date NOT NULL,
  `es_voucherentryid` int(11) NOT NULL,
  PRIMARY KEY (`es_fcc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_fine_charged_collected`
--

LOCK TABLES `es_fine_charged_collected` WRITE;
/*!40000 ALTER TABLE `es_fine_charged_collected` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_fine_charged_collected` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_fine_master`
--

DROP TABLE IF EXISTS `es_fine_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_fine_master` (
  `es_fine_masterid` int(11) NOT NULL AUTO_INCREMENT,
  `fine_amount` float NOT NULL,
  `fine_type` enum('Percentage','Amount') NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`es_fine_masterid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_fine_master`
--

LOCK TABLES `es_fine_master` WRITE;
/*!40000 ALTER TABLE `es_fine_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_fine_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_goodsissue`
--

DROP TABLE IF EXISTS `es_goodsissue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_goodsissue` (
  `es_goodsissueid` int(11) NOT NULL AUTO_INCREMENT,
  `fld_issuedate` datetime NOT NULL,
  `fld_issueto` varchar(255) NOT NULL,
  `fld_inventoryid` int(11) NOT NULL,
  `fld_issueditem` longtext NOT NULL,
  `fld_returneditem` longtext NOT NULL,
  `fld_departmentid` int(11) NOT NULL,
  `fld_issuestatus` enum('notreturned','partialreturned','returned') NOT NULL,
  `fld_status` enum('active','inactive','deleted') NOT NULL,
  `fld_remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`es_goodsissueid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_goodsissue`
--

LOCK TABLES `es_goodsissue` WRITE;
/*!40000 ALTER TABLE `es_goodsissue` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_goodsissue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_groups`
--

DROP TABLE IF EXISTS `es_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_groups` (
  `es_groupsid` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` float NOT NULL,
  `es_groupname` varchar(255) NOT NULL,
  `es_grouporderby` int(11) NOT NULL,
  PRIMARY KEY (`es_groupsid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_groups`
--

LOCK TABLES `es_groups` WRITE;
/*!40000 ALTER TABLE `es_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_holidaynoti`
--

DROP TABLE IF EXISTS `es_holidaynoti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_holidaynoti` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_holidaynoti`
--

LOCK TABLES `es_holidaynoti` WRITE;
/*!40000 ALTER TABLE `es_holidaynoti` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_holidaynoti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_holidays`
--

DROP TABLE IF EXISTS `es_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `holiday_date` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_holidays`
--

LOCK TABLES `es_holidays` WRITE;
/*!40000 ALTER TABLE `es_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_hostel_charges`
--

DROP TABLE IF EXISTS `es_hostel_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_hostel_charges` (
  `es_hostel_charges_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_roomallotmentid` int(11) NOT NULL,
  `es_hostelbuldid` int(11) NOT NULL,
  `es_personid` bigint(20) NOT NULL,
  `es_persontype` varchar(255) NOT NULL,
  `due_month` date NOT NULL,
  `room_rate` double NOT NULL,
  `amount_paid` double NOT NULL,
  `deduction` double NOT NULL,
  `balance` double NOT NULL,
  `name` varchar(255) NOT NULL,
  `father` varchar(255) NOT NULL,
  `paid_on` date NOT NULL,
  `remarks` text NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`es_hostel_charges_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_hostel_charges`
--

LOCK TABLES `es_hostel_charges` WRITE;
/*!40000 ALTER TABLE `es_hostel_charges` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_hostel_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_hostel_health`
--

DROP TABLE IF EXISTS `es_hostel_health`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_hostel_health` (
  `es_hostel_healthid` int(11) NOT NULL AUTO_INCREMENT,
  `health_regno` int(11) NOT NULL,
  `health_name` varchar(255) NOT NULL,
  `health_class` varchar(255) NOT NULL,
  `health_section` varchar(255) NOT NULL,
  `health_problem` varchar(255) NOT NULL,
  `health_doctorname` varchar(255) NOT NULL,
  `health_address` varchar(255) NOT NULL,
  `health_contactno` int(11) NOT NULL,
  `health_prescription` varchar(255) NOT NULL,
  `es_personid` bigint(20) NOT NULL,
  `es_persontpe` varchar(255) NOT NULL,
  `es_createdon` date NOT NULL,
  PRIMARY KEY (`es_hostel_healthid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_hostel_health`
--

LOCK TABLES `es_hostel_health` WRITE;
/*!40000 ALTER TABLE `es_hostel_health` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_hostel_health` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_hostelbuld`
--

DROP TABLE IF EXISTS `es_hostelbuld`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_hostelbuld` (
  `es_hostelbuldid` int(11) NOT NULL AUTO_INCREMENT,
  `buld_name` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `createdon` date NOT NULL,
  PRIMARY KEY (`es_hostelbuldid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_hostelbuld`
--

LOCK TABLES `es_hostelbuld` WRITE;
/*!40000 ALTER TABLE `es_hostelbuld` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_hostelbuld` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_hostelperson_item`
--

DROP TABLE IF EXISTS `es_hostelperson_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_hostelperson_item` (
  `es_hostelperson_itemid` int(11) NOT NULL AUTO_INCREMENT,
  `hostelperson_itemno` int(11) NOT NULL,
  `hostelperson_itemcode` int(11) NOT NULL,
  `hostelperson_itemname` varchar(255) NOT NULL,
  `hostelperson_itemtype` varchar(255) NOT NULL,
  `hostelperson_itemqty` int(11) NOT NULL,
  `es_personid` bigint(20) NOT NULL,
  `hostelperson_itemissued` datetime NOT NULL,
  `es_persontype` varchar(255) NOT NULL,
  `es_roomallotmentid` int(11) NOT NULL,
  `status` enum('issued','issuereturn') NOT NULL,
  `return_on` date NOT NULL,
  PRIMARY KEY (`es_hostelperson_itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_hostelperson_item`
--

LOCK TABLES `es_hostelperson_item` WRITE;
/*!40000 ALTER TABLE `es_hostelperson_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_hostelperson_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_hostelroom`
--

DROP TABLE IF EXISTS `es_hostelroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_hostelroom` (
  `es_hostelroomid` int(11) NOT NULL AUTO_INCREMENT,
  `room_type` varchar(255) NOT NULL,
  `room_capacity` int(11) NOT NULL,
  `room_vacancy` int(11) NOT NULL,
  `room_no` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `buld_name` varchar(255) NOT NULL,
  `es_hostelbuldid` int(11) DEFAULT NULL,
  `room_rate` double NOT NULL,
  PRIMARY KEY (`es_hostelroomid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_hostelroom`
--

LOCK TABLES `es_hostelroom` WRITE;
/*!40000 ALTER TABLE `es_hostelroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_hostelroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_idcard_image`
--

DROP TABLE IF EXISTS `es_idcard_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_idcard_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `horizontal_image` varchar(255) NOT NULL,
  `vertical_image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_idcard_image`
--

LOCK TABLES `es_idcard_image` WRITE;
/*!40000 ALTER TABLE `es_idcard_image` DISABLE KEYS */;
INSERT INTO `es_idcard_image` (`id`, `horizontal_image`, `vertical_image`) VALUES (1,'st_07032012_010723_waheguru.png','st_07032012_010723_BabaJi-1024x768.jpg');
/*!40000 ALTER TABLE `es_idcard_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_in_category`
--

DROP TABLE IF EXISTS `es_in_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_in_category` (
  `es_in_categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `in_category_name` varchar(255) NOT NULL,
  `in_description` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  PRIMARY KEY (`es_in_categoryid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_in_category`
--

LOCK TABLES `es_in_category` WRITE;
/*!40000 ALTER TABLE `es_in_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_in_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_in_goods_issue`
--

DROP TABLE IF EXISTS `es_in_goods_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_in_goods_issue` (
  `es_in_goods_issueid` int(11) NOT NULL AUTO_INCREMENT,
  `in_issue_date` datetime NOT NULL,
  `in_issue_to` varchar(255) NOT NULL,
  `in_inventory_id` int(11) NOT NULL,
  `in_issued_items` longtext NOT NULL,
  `in_returned_items` longtext NOT NULL,
  `in_department_id` int(11) NOT NULL,
  `in_issue_status` enum('notreturned','partialreturned','returned') NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`es_in_goods_issueid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_in_goods_issue`
--

LOCK TABLES `es_in_goods_issue` WRITE;
/*!40000 ALTER TABLE `es_in_goods_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_in_goods_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_in_item_master`
--

DROP TABLE IF EXISTS `es_in_item_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_in_item_master` (
  `es_in_item_masterid` int(11) NOT NULL AUTO_INCREMENT,
  `in_item_code` varchar(255) NOT NULL,
  `in_item_name` varchar(255) NOT NULL,
  `cost` varchar(255) NOT NULL,
  `in_inventory_id` int(11) NOT NULL,
  `in_category_id` int(11) NOT NULL,
  `in_qty_available` float NOT NULL,
  `in_reorder_level` float NOT NULL,
  `in_quantity_issued` float NOT NULL DEFAULT '0',
  `in_last_recieved_date` datetime NOT NULL,
  `in_last_issued_date` datetime NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  `in_units` varchar(255) NOT NULL,
  `test` varchar(255) NOT NULL,
  `test1` varchar(255) NOT NULL,
  PRIMARY KEY (`es_in_item_masterid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_in_item_master`
--

LOCK TABLES `es_in_item_master` WRITE;
/*!40000 ALTER TABLE `es_in_item_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_in_item_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_in_maintain`
--

DROP TABLE IF EXISTS `es_in_maintain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_in_maintain` (
  `es_in_maintainid` int(11) NOT NULL AUTO_INCREMENT,
  `in_maintain_name` varchar(255) NOT NULL,
  `in_description` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  PRIMARY KEY (`es_in_maintainid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_in_maintain`
--

LOCK TABLES `es_in_maintain` WRITE;
/*!40000 ALTER TABLE `es_in_maintain` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_in_maintain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_in_orders`
--

DROP TABLE IF EXISTS `es_in_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_in_orders` (
  `es_in_ordersid` int(11) NOT NULL AUTO_INCREMENT,
  `in_suplier_name` varchar(255) NOT NULL,
  `in_items_purchased` longtext NOT NULL,
  `order_date` datetime NOT NULL,
  `in_rec_note_no` int(11) NOT NULL,
  `in_rec_date` datetime NOT NULL,
  `in_rec_bill_no` varchar(255) NOT NULL,
  `in_items_recieved` longtext NOT NULL,
  `in_tot_amnt` float NOT NULL,
  `in_ord_status` enum('pending','complete') NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  PRIMARY KEY (`es_in_ordersid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_in_orders`
--

LOCK TABLES `es_in_orders` WRITE;
/*!40000 ALTER TABLE `es_in_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_in_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_in_supplier_master`
--

DROP TABLE IF EXISTS `es_in_supplier_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_in_supplier_master` (
  `es_in_supplier_masterid` int(11) NOT NULL AUTO_INCREMENT,
  `in_name` varchar(255) NOT NULL,
  `in_address` varchar(255) NOT NULL,
  `in_city` varchar(255) NOT NULL,
  `in_state` varchar(255) NOT NULL,
  `in_country` varchar(255) NOT NULL,
  `in_office_no` varchar(255) NOT NULL,
  `in_mobile_no` varchar(255) NOT NULL,
  `in_email` varchar(255) NOT NULL,
  `in_fax` varchar(255) NOT NULL,
  `in_description` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  PRIMARY KEY (`es_in_supplier_masterid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_in_supplier_master`
--

LOCK TABLES `es_in_supplier_master` WRITE;
/*!40000 ALTER TABLE `es_in_supplier_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_in_supplier_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_incharge`
--

DROP TABLE IF EXISTS `es_incharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_incharge` (
  `incharge_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_classesid` varchar(255) NOT NULL,
  `es_staffid` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`incharge_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_incharge`
--

LOCK TABLES `es_incharge` WRITE;
/*!40000 ALTER TABLE `es_incharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_incharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_institutes`
--

DROP TABLE IF EXISTS `es_institutes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_institutes` (
  `inst_id` int(11) NOT NULL AUTO_INCREMENT,
  `inst_name` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`inst_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_institutes`
--

LOCK TABLES `es_institutes` WRITE;
/*!40000 ALTER TABLE `es_institutes` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_institutes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_intxcerti`
--

DROP TABLE IF EXISTS `es_intxcerti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_intxcerti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_intxcerti`
--

LOCK TABLES `es_intxcerti` WRITE;
/*!40000 ALTER TABLE `es_intxcerti` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_intxcerti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_inventory`
--

DROP TABLE IF EXISTS `es_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_inventory` (
  `es_inventoryid` int(11) NOT NULL AUTO_INCREMENT,
  `in_inventory_name` varchar(255) NOT NULL,
  `in_short_name` varchar(255) NOT NULL,
  `in_description` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`es_inventoryid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_inventory`
--

LOCK TABLES `es_inventory` WRITE;
/*!40000 ALTER TABLE `es_inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_investment`
--

DROP TABLE IF EXISTS `es_investment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_investment` (
  `es_invtid` int(11) NOT NULL AUTO_INCREMENT,
  `es_employee` varchar(255) NOT NULL,
  `es_invttype` varchar(255) NOT NULL,
  `es_amt` varchar(255) NOT NULL,
  `es_amt_type` varchar(255) NOT NULL,
  `es_fromdate` date NOT NULL,
  `es_todate` date NOT NULL,
  PRIMARY KEY (`es_invtid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_investment`
--

LOCK TABLES `es_investment` WRITE;
/*!40000 ALTER TABLE `es_investment` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_investment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_issueloan`
--

DROP TABLE IF EXISTS `es_issueloan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_issueloan` (
  `es_issueloanid` int(11) NOT NULL AUTO_INCREMENT,
  `es_staffid` int(11) NOT NULL,
  `es_loanmasterid` int(11) NOT NULL,
  `loan_intrestrate` float NOT NULL,
  `loan_amount` float NOT NULL,
  `loan_instalments` int(11) NOT NULL,
  `deductionmonth` date NOT NULL,
  `dud_amount` float NOT NULL,
  `amountpaidtillnow` float NOT NULL,
  `noofinstalmentscompleted` int(11) NOT NULL,
  `created_on` date NOT NULL,
  `voucherid` varchar(255) NOT NULL,
  PRIMARY KEY (`es_issueloanid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_issueloan`
--

LOCK TABLES `es_issueloan` WRITE;
/*!40000 ALTER TABLE `es_issueloan` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_issueloan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_itembook_master`
--

DROP TABLE IF EXISTS `es_itembook_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_itembook_master` (
  `fld_item_masterid` int(11) NOT NULL AUTO_INCREMENT,
  `fld_item_code` varchar(255) NOT NULL,
  `fld_item_name` varchar(255) NOT NULL,
  `fld_cost` varchar(255) NOT NULL,
  `fld_inventory_id` int(11) NOT NULL,
  `fld_category_id` int(11) NOT NULL,
  `fld_qty_available` float NOT NULL,
  `fld_reorder_level` float NOT NULL,
  `fld_quantity_issued` float NOT NULL DEFAULT '0',
  `fld_last_recieved_date` datetime NOT NULL,
  `fld_last_issued_date` datetime NOT NULL,
  `fld_status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  `fld_units` varchar(255) NOT NULL,
  `fld_test` varchar(255) NOT NULL,
  `fld_test1` varchar(255) NOT NULL,
  PRIMARY KEY (`fld_item_masterid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_itembook_master`
--

LOCK TABLES `es_itembook_master` WRITE;
/*!40000 ALTER TABLE `es_itembook_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_itembook_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_knowledge_articles`
--

DROP TABLE IF EXISTS `es_knowledge_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_knowledge_articles` (
  `es_knowledge_articlesid` int(11) NOT NULL AUTO_INCREMENT,
  `kb_category_id` int(11) NOT NULL,
  `kb_article_name` varchar(255) NOT NULL,
  `kb_article_desc` text NOT NULL,
  `kb_article_date` datetime NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `kb_priority` varchar(255) NOT NULL,
  `kb_views` bigint(20) NOT NULL,
  `created_by` int(11) NOT NULL,
  `person_type` varchar(255) NOT NULL,
  PRIMARY KEY (`es_knowledge_articlesid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_knowledge_articles`
--

LOCK TABLES `es_knowledge_articles` WRITE;
/*!40000 ALTER TABLE `es_knowledge_articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_knowledge_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_knowledge_base`
--

DROP TABLE IF EXISTS `es_knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_knowledge_base` (
  `es_knowledge_baseid` int(11) NOT NULL AUTO_INCREMENT,
  `kb_category` varchar(255) NOT NULL,
  `kb_description` text NOT NULL,
  `kb_date` datetime NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`es_knowledge_baseid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_knowledge_base`
--

LOCK TABLES `es_knowledge_base` WRITE;
/*!40000 ALTER TABLE `es_knowledge_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_leaveleter`
--

DROP TABLE IF EXISTS `es_leaveleter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_leaveleter` (
  `es_leaveleterid` int(11) NOT NULL AUTO_INCREMENT,
  `leave_msg` longtext NOT NULL,
  PRIMARY KEY (`es_leaveleterid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_leaveleter`
--

LOCK TABLES `es_leaveleter` WRITE;
/*!40000 ALTER TABLE `es_leaveleter` DISABLE KEYS */;
INSERT INTO `es_leaveleter` (`es_leaveleterid`, `leave_msg`) VALUES (1,'<p>&nbsp;</p><p>To,</p><p>The principal,&nbsp;</p><p>Hello</p><p>This is a leave letter format</p>');
/*!40000 ALTER TABLE `es_leaveleter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_leavemaster`
--

DROP TABLE IF EXISTS `es_leavemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_leavemaster` (
  `es_leavemasterid` int(11) NOT NULL AUTO_INCREMENT,
  `lev_post` varchar(255) NOT NULL,
  `lev_type` varchar(255) NOT NULL,
  `lev_leavescount` varchar(255) NOT NULL,
  `lev_carryforward` varchar(255) NOT NULL,
  `lev_days` varchar(255) NOT NULL,
  `lev_enchashable` varchar(255) NOT NULL,
  `lev_dept` varchar(255) NOT NULL,
  `lev_from_date` date NOT NULL,
  `lev_to_date` date NOT NULL,
  `leave_dur_frm` date NOT NULL,
  `leave_dur_to` date NOT NULL,
  PRIMARY KEY (`es_leavemasterid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_leavemaster`
--

LOCK TABLES `es_leavemaster` WRITE;
/*!40000 ALTER TABLE `es_leavemaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_leavemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_leaves`
--

DROP TABLE IF EXISTS `es_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_leaves` (
  `es_leaveid` int(255) NOT NULL AUTO_INCREMENT,
  `es_staffid` int(255) NOT NULL,
  `es_leavestaff` varchar(255) NOT NULL,
  `es_staffstatus` varchar(255) NOT NULL,
  `es_noofleaves` varchar(255) NOT NULL,
  `es_takenleaves` varchar(255) NOT NULL,
  PRIMARY KEY (`es_leaveid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_leaves`
--

LOCK TABLES `es_leaves` WRITE;
/*!40000 ALTER TABLE `es_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_ledger`
--

DROP TABLE IF EXISTS `es_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_ledger` (
  `es_ledgerid` int(11) NOT NULL AUTO_INCREMENT,
  `lg_name` varchar(255) NOT NULL,
  `lg_groupname` varchar(255) NOT NULL,
  `lg_openingbalance` double NOT NULL,
  `lg_createdon` date NOT NULL,
  `lg_amounttype` varchar(255) NOT NULL,
  PRIMARY KEY (`es_ledgerid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_ledger`
--

LOCK TABLES `es_ledger` WRITE;
/*!40000 ALTER TABLE `es_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_libaraypublisher`
--

DROP TABLE IF EXISTS `es_libaraypublisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_libaraypublisher` (
  `es_libaraypublisherid` int(11) NOT NULL AUTO_INCREMENT,
  `library_publishername` varchar(255) NOT NULL,
  `library_pulisheradress` varchar(255) NOT NULL,
  `library_city` varchar(255) NOT NULL,
  `libaray_state` varchar(255) NOT NULL,
  `libarary_country` varchar(255) NOT NULL,
  `libaray_phoneno` varchar(255) NOT NULL,
  `librray_mobileno` varchar(255) NOT NULL,
  `library_fax` varchar(255) NOT NULL,
  `libarary_email` varchar(255) NOT NULL,
  `libarary_aditinalinformation` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`es_libaraypublisherid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_libaraypublisher`
--

LOCK TABLES `es_libaraypublisher` WRITE;
/*!40000 ALTER TABLE `es_libaraypublisher` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_libaraypublisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_libbook`
--

DROP TABLE IF EXISTS `es_libbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_libbook` (
  `es_libbookid` int(11) NOT NULL AUTO_INCREMENT,
  `lbook_dateofpurchase` date NOT NULL,
  `lbook_aceesnofrom` int(11) NOT NULL,
  `lbook_accessnoto` int(11) NOT NULL,
  `lbook_bookfromno` int(11) NOT NULL,
  `lbook_booktono` int(11) NOT NULL,
  `lbook_author` varchar(255) NOT NULL,
  `lbook_title` varchar(255) NOT NULL,
  `lbook_publishername` varchar(255) NOT NULL,
  `lbook_publisherplace` varchar(255) NOT NULL,
  `lbook_booksubject` varchar(255) NOT NULL,
  `lbook_bookedition` varchar(255) NOT NULL,
  `lbook_year` varchar(255) NOT NULL,
  `lbook_cost` varchar(255) NOT NULL,
  `lbook_sourse` varchar(255) NOT NULL,
  `lbook_aditinalbookinfo` varchar(255) NOT NULL,
  `lbook_bookstatus` varchar(255) NOT NULL,
  `lbook_category` varchar(255) NOT NULL,
  `lbook_class` varchar(255) NOT NULL,
  `lbook_booksubcategory` varchar(255) NOT NULL,
  `lbook_ref` varchar(255) NOT NULL,
  `lbook_statusstatus` varchar(255) NOT NULL,
  `lbook_pages` varchar(255) NOT NULL,
  `lbook_volume` varchar(255) NOT NULL,
  `lbook_bilnumber` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `issuestatus` enum('issued','notissued') NOT NULL,
  PRIMARY KEY (`es_libbookid`)
) ENGINE=MyISAM AUTO_INCREMENT=547 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_libbook`
--

LOCK TABLES `es_libbook` WRITE;
/*!40000 ALTER TABLE `es_libbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_libbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_libbookfinedet`
--

DROP TABLE IF EXISTS `es_libbookfinedet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_libbookfinedet` (
  `es_libbookfinedetid` int(11) NOT NULL AUTO_INCREMENT,
  `es_libbooksid` varchar(255) NOT NULL,
  `es_libbookbwid` varchar(255) NOT NULL,
  `es_libbookfine` varchar(255) NOT NULL,
  `es_libbookdate` varchar(255) NOT NULL,
  `es_type` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `es_issuetype` varchar(255) NOT NULL,
  `fine_paid` varchar(255) NOT NULL,
  `fine_deducted` varchar(255) NOT NULL,
  `paid_on` date NOT NULL,
  `remarks` text NOT NULL,
  `returnedon` date NOT NULL,
  PRIMARY KEY (`es_libbookfinedetid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_libbookfinedet`
--

LOCK TABLES `es_libbookfinedet` WRITE;
/*!40000 ALTER TABLE `es_libbookfinedet` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_libbookfinedet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_libfine`
--

DROP TABLE IF EXISTS `es_libfine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_libfine` (
  `es_libfineid` int(11) NOT NULL AUTO_INCREMENT,
  `es_libfinenoofdays` varchar(255) NOT NULL,
  `es_libfineamount` varchar(255) NOT NULL,
  `es_libfineduration` varchar(255) NOT NULL,
  `es_libfinefor` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`es_libfineid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_libfine`
--

LOCK TABLES `es_libfine` WRITE;
/*!40000 ALTER TABLE `es_libfine` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_libfine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_loancerti`
--

DROP TABLE IF EXISTS `es_loancerti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_loancerti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_loancerti`
--

LOCK TABLES `es_loancerti` WRITE;
/*!40000 ALTER TABLE `es_loancerti` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_loancerti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_loanmaster`
--

DROP TABLE IF EXISTS `es_loanmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_loanmaster` (
  `es_loanmasterid` int(11) NOT NULL AUTO_INCREMENT,
  `loan_post` varchar(255) NOT NULL,
  `loan_type` varchar(255) NOT NULL,
  `loan_name` varchar(255) NOT NULL,
  `loan_fromdate` date NOT NULL,
  `loan_todate` date NOT NULL,
  `loan_intrestrate` varchar(255) NOT NULL,
  `loan_maxlimit` varchar(255) NOT NULL,
  `loan_dept` varchar(255) NOT NULL,
  PRIMARY KEY (`es_loanmasterid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_loanmaster`
--

LOCK TABLES `es_loanmaster` WRITE;
/*!40000 ALTER TABLE `es_loanmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_loanmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_loanpayment`
--

DROP TABLE IF EXISTS `es_loanpayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_loanpayment` (
  `es_loanpaymentid` int(11) NOT NULL AUTO_INCREMENT,
  `es_issueloanid` int(11) NOT NULL,
  `inst_amount` float NOT NULL,
  `onmonth` date NOT NULL,
  PRIMARY KEY (`es_loanpaymentid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_loanpayment`
--

LOCK TABLES `es_loanpayment` WRITE;
/*!40000 ALTER TABLE `es_loanpayment` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_loanpayment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_marks`
--

DROP TABLE IF EXISTS `es_marks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_marks` (
  `es_marksid` int(11) NOT NULL AUTO_INCREMENT,
  `es_examdetailsid` int(11) NOT NULL,
  `es_marksstudentid` bigint(20) NOT NULL,
  `es_marksobtined` varchar(255) NOT NULL DEFAULT '0',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`es_marksid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_marks`
--

LOCK TABLES `es_marks` WRITE;
/*!40000 ALTER TABLE `es_marks` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_marks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_meeting`
--

DROP TABLE IF EXISTS `es_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_meeting` (
  `es_mid` int(11) NOT NULL AUTO_INCREMENT,
  `es_mschool1` date NOT NULL,
  `es_mschool2` date NOT NULL,
  `es_mschool3` date NOT NULL,
  `es_mschool4` date NOT NULL,
  `es_mschool5` date NOT NULL,
  `es_mschool6` date NOT NULL,
  `es_macademic1` date NOT NULL,
  `es_macademic2` date NOT NULL,
  `es_macademic3` date NOT NULL,
  `es_macademic4` date NOT NULL,
  `es_macademic5` date NOT NULL,
  `es_macademic6` date NOT NULL,
  `es_mparents1` date NOT NULL,
  `es_mparents2` date NOT NULL,
  `es_mparents3` date NOT NULL,
  `es_mparents4` date NOT NULL,
  `es_mparents5` date NOT NULL,
  `es_mparents6` date NOT NULL,
  `es_status` varchar(255) NOT NULL,
  PRIMARY KEY (`es_mid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_meeting`
--

LOCK TABLES `es_meeting` WRITE;
/*!40000 ALTER TABLE `es_meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_message_documents`
--

DROP TABLE IF EXISTS `es_message_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_message_documents` (
  `doc_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `es_messagesid` bigint(20) NOT NULL,
  `message_doc` varchar(255) NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_message_documents`
--

LOCK TABLES `es_message_documents` WRITE;
/*!40000 ALTER TABLE `es_message_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_message_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_messages`
--

DROP TABLE IF EXISTS `es_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_messages` (
  `es_messagesid` bigint(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `from_type` varchar(255) NOT NULL,
  `to_id` int(11) NOT NULL,
  `to_type` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `message` longtext NOT NULL,
  `created_on` datetime NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `from_status` enum('active','inactive','deleted') NOT NULL,
  `to_status` enum('active','inactive','deleted') NOT NULL,
  `replay_status` enum('notreplied','replied') NOT NULL DEFAULT 'notreplied',
  PRIMARY KEY (`es_messagesid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_messages`
--

LOCK TABLES `es_messages` WRITE;
/*!40000 ALTER TABLE `es_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_modules_alloted`
--

DROP TABLE IF EXISTS `es_modules_alloted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_modules_alloted` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `max_no_courses` varchar(255) NOT NULL,
  `max_no_students` varchar(255) NOT NULL,
  `modules_permissions` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_modules_alloted`
--

LOCK TABLES `es_modules_alloted` WRITE;
/*!40000 ALTER TABLE `es_modules_alloted` DISABLE KEYS */;
INSERT INTO `es_modules_alloted` (`id`, `max_no_courses`, `max_no_students`, `modules_permissions`, `created_on`) VALUES (1,'1000','999999999','1_p,2_p,3_p,4_p,5_p,6_p,7_p,8_p,9_p,10_p,11_p,12_p,13_p,14_p,15_p,16_p,17_p,18_p,19_p,20_p,21_p,22_p,23_p,24_p,25_p,26_p,27_p,28_p,29_p,30_p,31_p,32_p,33_p,34_p,35_p','2012-06-06');
/*!40000 ALTER TABLE `es_modules_alloted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_new_timetable`
--

DROP TABLE IF EXISTS `es_new_timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_new_timetable` (
  `new_time_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `period_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`new_time_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_new_timetable`
--

LOCK TABLES `es_new_timetable` WRITE;
/*!40000 ALTER TABLE `es_new_timetable` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_new_timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_notice`
--

DROP TABLE IF EXISTS `es_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_notice` (
  `es_noticeid` int(11) NOT NULL AUTO_INCREMENT,
  `es_title` varchar(255) NOT NULL,
  `es_message` longtext NOT NULL,
  `es_date` date NOT NULL,
  `es_subject` varchar(255) NOT NULL,
  PRIMARY KEY (`es_noticeid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_notice`
--

LOCK TABLES `es_notice` WRITE;
/*!40000 ALTER TABLE `es_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_notice_messages`
--

DROP TABLE IF EXISTS `es_notice_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_notice_messages` (
  `es_messagesid` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `from_type` varchar(255) NOT NULL,
  `to_id` int(11) NOT NULL,
  `to_type` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `message` longtext NOT NULL,
  `created_on` datetime NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `from_status` enum('active','inactive','deleted') NOT NULL,
  `to_status` enum('active','inactive','deleted') NOT NULL,
  `replay_status` enum('notreplied','replied') NOT NULL DEFAULT 'notreplied',
  `replied_message_id` bigint(20) NOT NULL,
  `read_status` enum('Unread','Read') NOT NULL DEFAULT 'Unread',
  PRIMARY KEY (`es_messagesid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_notice_messages`
--

LOCK TABLES `es_notice_messages` WRITE;
/*!40000 ALTER TABLE `es_notice_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_notice_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_offerletter`
--

DROP TABLE IF EXISTS `es_offerletter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_offerletter` (
  `es_offerletterid` int(11) NOT NULL AUTO_INCREMENT,
  `ofr_message` longtext NOT NULL,
  PRIMARY KEY (`es_offerletterid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_offerletter`
--

LOCK TABLES `es_offerletter` WRITE;
/*!40000 ALTER TABLE `es_offerletter` DISABLE KEYS */;
INSERT INTO `es_offerletter` (`es_offerletterid`, `ofr_message`) VALUES (1,'<p><em>Offer Letter</em></p>');
/*!40000 ALTER TABLE `es_offerletter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_old_balances`
--

DROP TABLE IF EXISTS `es_old_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_old_balances` (
  `ob_id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` bigint(20) NOT NULL,
  `old_balance` varchar(255) NOT NULL,
  `paid_amount` varchar(255) NOT NULL,
  `wived_amount` varchar(255) NOT NULL,
  `last_paid_dt` date NOT NULL,
  `balance` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`ob_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_old_balances`
--

LOCK TABLES `es_old_balances` WRITE;
/*!40000 ALTER TABLE `es_old_balances` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_old_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_old_balances_paid`
--

DROP TABLE IF EXISTS `es_old_balances_paid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_old_balances_paid` (
  `obp_id` int(11) NOT NULL AUTO_INCREMENT,
  `ob_id` int(11) NOT NULL,
  `paid_amount` varchar(255) NOT NULL,
  `waived_amount` varchar(255) NOT NULL,
  `paid_on` date NOT NULL,
  PRIMARY KEY (`obp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_old_balances_paid`
--

LOCK TABLES `es_old_balances_paid` WRITE;
/*!40000 ALTER TABLE `es_old_balances_paid` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_old_balances_paid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_other_fine_dettails`
--

DROP TABLE IF EXISTS `es_other_fine_dettails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_other_fine_dettails` (
  `otherfine_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_preadmissionid` int(11) NOT NULL,
  `fine_name` varchar(255) NOT NULL,
  `fine_amount` double NOT NULL,
  `created_on` date NOT NULL,
  `paid_amount` double NOT NULL,
  `deduction_allowed` double NOT NULL,
  `paid_on` date NOT NULL,
  `balance` double NOT NULL,
  `remarks` text NOT NULL,
  `voucherid` varchar(225) NOT NULL,
  PRIMARY KEY (`otherfine_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_other_fine_dettails`
--

LOCK TABLES `es_other_fine_dettails` WRITE;
/*!40000 ALTER TABLE `es_other_fine_dettails` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_other_fine_dettails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_otherletter_formats`
--

DROP TABLE IF EXISTS `es_otherletter_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_otherletter_formats` (
  `letter_id` int(11) NOT NULL AUTO_INCREMENT,
  `letter_title` text NOT NULL,
  `letter_desc` longtext NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`letter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_otherletter_formats`
--

LOCK TABLES `es_otherletter_formats` WRITE;
/*!40000 ALTER TABLE `es_otherletter_formats` DISABLE KEYS */;
INSERT INTO `es_otherletter_formats` (`letter_id`, `letter_title`, `letter_desc`, `status`, `created_on`) VALUES (1,'Only Transfer','<p><strong>&nbsp;HAHA WELCOME sjdsjjhsjsd &nbsp;</strong></p>','active','2017-06-09');
/*!40000 ALTER TABLE `es_otherletter_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_payslipdetails`
--

DROP TABLE IF EXISTS `es_payslipdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_payslipdetails` (
  `es_payslipdetailsid` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `pay_month` date NOT NULL,
  `basic_salary` float NOT NULL,
  `tot_allowance` float NOT NULL,
  `tot_deductions` float NOT NULL,
  `net_salary` float NOT NULL,
  `balance` varchar(255) NOT NULL,
  `leavedays` varchar(255) NOT NULL,
  `totalleave` varchar(255) NOT NULL,
  `voucherid` varchar(255) NOT NULL,
  PRIMARY KEY (`es_payslipdetailsid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_payslipdetails`
--

LOCK TABLES `es_payslipdetails` WRITE;
/*!40000 ALTER TABLE `es_payslipdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_payslipdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_pfmaster`
--

DROP TABLE IF EXISTS `es_pfmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_pfmaster` (
  `es_pfmasterid` int(11) NOT NULL AUTO_INCREMENT,
  `pf_post` varchar(255) NOT NULL,
  `pf_empcont` float NOT NULL,
  `pf_empconttype` varchar(255) NOT NULL,
  `pf_empycont` float NOT NULL,
  `pf_empyconttype` varchar(255) NOT NULL,
  `pf_dept` varchar(255) NOT NULL,
  `pf_from_date` date NOT NULL,
  `pf_to_date` date NOT NULL,
  PRIMARY KEY (`es_pfmasterid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_pfmaster`
--

LOCK TABLES `es_pfmaster` WRITE;
/*!40000 ALTER TABLE `es_pfmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_pfmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_photogallery`
--

DROP TABLE IF EXISTS `es_photogallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_photogallery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_photogallery`
--

LOCK TABLES `es_photogallery` WRITE;
/*!40000 ALTER TABLE `es_photogallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_photogallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_planningyear`
--

DROP TABLE IF EXISTS `es_planningyear`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_planningyear` (
  `es_pid` int(11) NOT NULL AUTO_INCREMENT,
  `es_junewd` varchar(255) NOT NULL,
  `es_junesun` varchar(255) NOT NULL,
  `es_junetd` varchar(255) NOT NULL,
  `es_julywd` varchar(255) NOT NULL,
  `es_julysun` varchar(255) NOT NULL,
  `es_julytd` varchar(255) NOT NULL,
  `es_augwd` varchar(255) NOT NULL,
  `es_augsun` varchar(255) NOT NULL,
  `es_augtd` varchar(255) NOT NULL,
  `es_septwd` varchar(255) NOT NULL,
  `es_septsun` varchar(255) NOT NULL,
  `es_septtd` varchar(255) NOT NULL,
  `es_octwd` varchar(255) NOT NULL,
  `es_octsun` varchar(255) NOT NULL,
  `es_octtd` varchar(255) NOT NULL,
  `es_otherwd1` varchar(255) NOT NULL,
  `es_othersun1` varchar(255) NOT NULL,
  `es_othertd1` varchar(255) NOT NULL,
  `es_novwd` varchar(255) NOT NULL,
  `es_novsun` varchar(255) NOT NULL,
  `es_novtd` varchar(255) NOT NULL,
  `es_decwd` varchar(255) NOT NULL,
  `es_decsun` varchar(255) NOT NULL,
  `es_dectd` varchar(255) NOT NULL,
  `es_janwd` varchar(255) NOT NULL,
  `es_jansun` varchar(255) NOT NULL,
  `es_jantd` varchar(255) NOT NULL,
  `es_febwd` varchar(255) NOT NULL,
  `es_febsun` varchar(255) NOT NULL,
  `es_febtd` varchar(255) NOT NULL,
  `es_marchwd` varchar(255) NOT NULL,
  `es_marchsun` varchar(255) NOT NULL,
  `es_marchtd` varchar(255) NOT NULL,
  `es_aprilwd` varchar(255) NOT NULL,
  `es_aprilsun` varchar(255) NOT NULL,
  `es_apriltd` varchar(255) NOT NULL,
  `es_maywd` varchar(255) NOT NULL,
  `es_maysun` varchar(255) NOT NULL,
  `es_maytd` varchar(255) NOT NULL,
  `es_otherwd2` varchar(255) NOT NULL,
  `es_othersun2` varchar(255) NOT NULL,
  `es_othertd2` varchar(255) NOT NULL,
  `es_status` varchar(255) NOT NULL,
  PRIMARY KEY (`es_pid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_planningyear`
--

LOCK TABLES `es_planningyear` WRITE;
/*!40000 ALTER TABLE `es_planningyear` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_planningyear` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_preadmission`
--

DROP TABLE IF EXISTS `es_preadmission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_preadmission` (
  `es_preadmissionid` int(11) NOT NULL AUTO_INCREMENT,
  `pre_serialno` varchar(255) NOT NULL,
  `pre_student_username` varchar(255) NOT NULL,
  `pre_student_password` varchar(255) NOT NULL,
  `pre_dateofbirth` date NOT NULL,
  `pre_fathername` varchar(255) NOT NULL,
  `pre_mothername` varchar(255) NOT NULL,
  `pre_fathersoccupation` varchar(255) NOT NULL,
  `pre_motheroccupation` varchar(255) NOT NULL,
  `pre_contactname1` varchar(255) NOT NULL,
  `pre_contactno1` varchar(255) NOT NULL,
  `pre_contactno2` varchar(255) NOT NULL,
  `pre_contactname2` varchar(255) NOT NULL,
  `pre_address1` varchar(255) NOT NULL,
  `pre_city1` varchar(255) NOT NULL,
  `pre_state1` varchar(255) NOT NULL,
  `pre_country1` varchar(255) NOT NULL,
  `pre_phno1` varchar(255) NOT NULL,
  `pre_mobile1` varchar(255) NOT NULL,
  `pre_prev_acadamicname` varchar(255) NOT NULL,
  `pre_prev_class` varchar(255) NOT NULL,
  `pre_prev_university` varchar(255) NOT NULL,
  `pre_prev_percentage` varchar(255) NOT NULL,
  `pre_prev_tcno` varchar(255) NOT NULL,
  `pre_current_acadamicname` varchar(255) NOT NULL,
  `pre_current_class1` varchar(255) NOT NULL,
  `pre_current_percentage1` varchar(255) NOT NULL,
  `pre_current_result1` varchar(255) NOT NULL,
  `pre_current_class2` varchar(255) NOT NULL,
  `pre_current_percentage2` varchar(255) NOT NULL,
  `pre_current_result2` varchar(255) NOT NULL,
  `pre_current_class3` varchar(255) NOT NULL,
  `pre_current_percentage3` varchar(255) NOT NULL,
  `pre_current_result3` varchar(255) NOT NULL,
  `pre_physical_details` varchar(255) NOT NULL,
  `pre_height` varchar(255) NOT NULL,
  `pre_weight` varchar(255) NOT NULL,
  `pre_alerge` varchar(255) NOT NULL,
  `pre_physical_status` varchar(255) NOT NULL,
  `pre_special_care` varchar(255) NOT NULL,
  `pre_class` varchar(255) NOT NULL,
  `pre_sec` varchar(255) NOT NULL,
  `pre_name` varchar(255) NOT NULL,
  `pre_age` varchar(255) NOT NULL,
  `pre_address` varchar(255) NOT NULL,
  `pre_city` varchar(255) NOT NULL,
  `pre_state` varchar(255) NOT NULL,
  `pre_country` varchar(255) NOT NULL,
  `pre_phno` varchar(255) NOT NULL,
  `pre_mobile` varchar(255) NOT NULL,
  `pre_resno` varchar(255) NOT NULL,
  `pre_resno1` varchar(255) NOT NULL,
  `pre_image` varchar(255) NOT NULL,
  `test1` varchar(255) NOT NULL,
  `test2` varchar(255) NOT NULL,
  `test3` varchar(255) NOT NULL,
  `pre_pincode1` varchar(255) NOT NULL,
  `pre_pincode` varchar(255) NOT NULL,
  `pre_emailid` varchar(255) NOT NULL,
  `pre_fromdate` date NOT NULL,
  `pre_todate` date NOT NULL,
  `status` enum('pass','fail','resultawaiting','inactive') NOT NULL,
  `pre_status` enum('inactive','active') NOT NULL DEFAULT 'active',
  `es_user_theme` varchar(255) NOT NULL,
  `pre_hobbies` int(9) NOT NULL,
  `pre_blood_group` varchar(255) NOT NULL,
  `pre_gender` enum('male','female') NOT NULL,
  `admission_status` enum('newadmission','promoted') NOT NULL,
  `caste_id` int(11) NOT NULL,
  `tr_place_id` int(11) NOT NULL,
  `ann_income` varchar(255) NOT NULL,
  `admission_date` date NOT NULL,
  `document_deposited` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `fee_concession` varchar(255) NOT NULL,
  `es_program` varchar(255) NOT NULL,
  `es_branch` varchar(100) NOT NULL,
  `es_admitted` varchar(100) NOT NULL,
  `es_rcat` varchar(50) NOT NULL,
  `es_phandcaped` varchar(100) NOT NULL,
  `es_econbackward` varchar(50) NOT NULL,
  `es_home` varchar(50) NOT NULL,
  `pre_hobbies1` varchar(255) NOT NULL,
  `pre_hobbies2` varchar(255) NOT NULL,
  `pre_building` varchar(50) NOT NULL,
  `pre_room` varchar(50) NOT NULL,
  `roll_no` bigint(20) NOT NULL,
  `pre_transport` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`es_preadmissionid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_preadmission`
--

LOCK TABLES `es_preadmission` WRITE;
/*!40000 ALTER TABLE `es_preadmission` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_preadmission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_preadmission_details`
--

DROP TABLE IF EXISTS `es_preadmission_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_preadmission_details` (
  `es_preadmission_detailsid` int(11) NOT NULL AUTO_INCREMENT,
  `es_preadmissionid` bigint(20) NOT NULL,
  `pre_class` varchar(255) NOT NULL,
  `pre_fromdate` date NOT NULL,
  `pre_todate` date NOT NULL,
  `status` enum('pass','fail','resultawaiting','inactive') NOT NULL,
  `admission_status` enum('newadmission','promoted') NOT NULL,
  `scat_id` int(11) NOT NULL,
  `pre_age` varchar(255) NOT NULL,
  `test2` varchar(255) NOT NULL,
  PRIMARY KEY (`es_preadmission_detailsid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_preadmission_details`
--

LOCK TABLES `es_preadmission_details` WRITE;
/*!40000 ALTER TABLE `es_preadmission_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_preadmission_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_questionbank`
--

DROP TABLE IF EXISTS `es_questionbank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_questionbank` (
  `q_id` int(11) NOT NULL AUTO_INCREMENT,
  `chapter_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `choice_1` text NOT NULL,
  `choice_2` text NOT NULL,
  `choice_3` text NOT NULL,
  `choice_4` text NOT NULL,
  `answer` enum('A','B','C','D') NOT NULL,
  `feed_dis` varchar(255) NOT NULL,
  `correct_ans` text NOT NULL,
  `wrong_ans` text NOT NULL,
  `created_on` date NOT NULL,
  `user_type` enum('admin','staff') NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`q_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_questionbank`
--

LOCK TABLES `es_questionbank` WRITE;
/*!40000 ALTER TABLE `es_questionbank` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_questionbank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_requirement`
--

DROP TABLE IF EXISTS `es_requirement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_requirement` (
  `es_requirementid` int(11) NOT NULL AUTO_INCREMENT,
  `es_post` varchar(255) NOT NULL,
  `es_depatname` varchar(255) NOT NULL,
  `es_qualification` varchar(255) NOT NULL,
  `es_experience` varchar(255) NOT NULL,
  `es_noofpositions` int(11) NOT NULL,
  `es_date_posteddate` date NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`es_requirementid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_requirement`
--

LOCK TABLES `es_requirement` WRITE;
/*!40000 ALTER TABLE `es_requirement` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_requirement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_resignation`
--

DROP TABLE IF EXISTS `es_resignation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_resignation` (
  `es_resignationid` int(11) NOT NULL AUTO_INCREMENT,
  `res_letter` longtext NOT NULL,
  PRIMARY KEY (`es_resignationid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_resignation`
--

LOCK TABLES `es_resignation` WRITE;
/*!40000 ALTER TABLE `es_resignation` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_resignation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_roomallotment`
--

DROP TABLE IF EXISTS `es_roomallotment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_roomallotment` (
  `es_roomallotmentid` int(11) NOT NULL AUTO_INCREMENT,
  `es_hostelroomid` int(11) NOT NULL,
  `es_personid` bigint(20) NOT NULL,
  `es_persontype` varchar(255) NOT NULL,
  `alloted_date` date NOT NULL,
  `dealloted_date` date NOT NULL,
  `status` enum('allocated','deallocated') NOT NULL,
  PRIMARY KEY (`es_roomallotmentid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_roomallotment`
--

LOCK TABLES `es_roomallotment` WRITE;
/*!40000 ALTER TABLE `es_roomallotment` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_roomallotment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_schoolcommittee`
--

DROP TABLE IF EXISTS `es_schoolcommittee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_schoolcommittee` (
  `ex_id` int(11) NOT NULL AUTO_INCREMENT,
  `ex_chariman` varchar(255) NOT NULL,
  `ex_member` varchar(255) NOT NULL,
  `ex_teachermem` varchar(255) NOT NULL,
  `ex_nonteachingmem` varchar(255) NOT NULL,
  `ex_officioses` varchar(255) NOT NULL,
  `es_status` varchar(255) NOT NULL,
  PRIMARY KEY (`ex_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_schoolcommittee`
--

LOCK TABLES `es_schoolcommittee` WRITE;
/*!40000 ALTER TABLE `es_schoolcommittee` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_schoolcommittee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_sections`
--

DROP TABLE IF EXISTS `es_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_sections` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_sections`
--

LOCK TABLES `es_sections` WRITE;
/*!40000 ALTER TABLE `es_sections` DISABLE KEYS */;
INSERT INTO `es_sections` (`section_id`, `section_name`, `created_on`) VALUES (1,'A','2017-10-05');
/*!40000 ALTER TABLE `es_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_sections_student`
--

DROP TABLE IF EXISTS `es_sections_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_sections_student` (
  `section_student_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) NOT NULL,
  `course_id` bigint(20) NOT NULL,
  `year_id` bigint(20) NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `section_id` bigint(20) NOT NULL,
  PRIMARY KEY (`section_student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_sections_student`
--

LOCK TABLES `es_sections_student` WRITE;
/*!40000 ALTER TABLE `es_sections_student` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_sections_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_security`
--

DROP TABLE IF EXISTS `es_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_security` (
  `es_securityid` int(11) NOT NULL AUTO_INCREMENT,
  `sec_name` varchar(255) NOT NULL,
  `sec_address` varchar(255) NOT NULL,
  `sec_contact_person` varchar(255) NOT NULL,
  `sec_vehicle_no` varchar(255) NOT NULL,
  `sec_purpose` varchar(255) NOT NULL,
  `sec_mode_app` varchar(255) NOT NULL,
  `sec_time_out` datetime NOT NULL,
  `sec_remarks` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `sec_time_in` datetime NOT NULL,
  `sec_colour` varchar(255) NOT NULL,
  `sec_make_vehicle` varchar(255) NOT NULL,
  `sec_reg_no` varchar(255) NOT NULL,
  `sec_phone` varchar(255) NOT NULL,
  `sec_mobile` varchar(255) NOT NULL,
  PRIMARY KEY (`es_securityid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_security`
--

LOCK TABLES `es_security` WRITE;
/*!40000 ALTER TABLE `es_security` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_shortlisted`
--

DROP TABLE IF EXISTS `es_shortlisted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_shortlisted` (
  `es_shortlistedid` int(11) NOT NULL AUTO_INCREMENT,
  `stl_message` longtext NOT NULL,
  PRIMARY KEY (`es_shortlistedid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_shortlisted`
--

LOCK TABLES `es_shortlisted` WRITE;
/*!40000 ALTER TABLE `es_shortlisted` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_shortlisted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_staff`
--

DROP TABLE IF EXISTS `es_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_staff` (
  `es_staffid` int(11) NOT NULL AUTO_INCREMENT,
  `st_postaplied` varchar(255) NOT NULL,
  `st_firstname` varchar(255) NOT NULL,
  `st_lastname` varchar(255) NOT NULL,
  `st_gender` varchar(255) NOT NULL,
  `st_dob` varchar(255) NOT NULL,
  `st_primarysubject` varchar(255) NOT NULL,
  `st_fatherhusname` varchar(255) NOT NULL,
  `st_noofdughters` varchar(255) NOT NULL,
  `st_noofsons` varchar(255) NOT NULL,
  `st_email` varchar(255) NOT NULL,
  `st_mobilenocomunication` varchar(255) NOT NULL,
  `st_examp1` varchar(255) NOT NULL,
  `st_examp2` varchar(255) NOT NULL,
  `st_examp3` varchar(255) NOT NULL,
  `st_borduniversity1` varchar(255) NOT NULL,
  `st_borduniversity2` varchar(255) NOT NULL,
  `st_borduniversity3` varchar(255) NOT NULL,
  `st_year1` varchar(255) NOT NULL,
  `st_year2` varchar(255) NOT NULL,
  `st_year3` varchar(255) NOT NULL,
  `st_insititute1` varchar(255) NOT NULL,
  `st_insititute2` varchar(255) NOT NULL,
  `st_insititute3` varchar(255) NOT NULL,
  `st_position1` varchar(255) NOT NULL,
  `st_position2` varchar(255) NOT NULL,
  `st_position3` varchar(255) NOT NULL,
  `st_period1` varchar(255) NOT NULL,
  `st_period2` varchar(255) NOT NULL,
  `st_period3` varchar(255) NOT NULL,
  `st_pradress` varchar(255) NOT NULL,
  `st_prcity` varchar(255) NOT NULL,
  `st_prpincode` varchar(255) NOT NULL,
  `st_prphonecode` varchar(255) NOT NULL,
  `st_prstate` varchar(255) NOT NULL,
  `st_prresino` varchar(255) NOT NULL,
  `st_prcountry` varchar(255) NOT NULL,
  `st_prmobno` varchar(255) NOT NULL,
  `st_peadress` varchar(255) NOT NULL,
  `st_pecity` varchar(255) NOT NULL,
  `st_pepincode` varchar(255) NOT NULL,
  `st_pephoneno` varchar(255) NOT NULL,
  `st_pestate` varchar(255) NOT NULL,
  `st_peresino` varchar(255) NOT NULL,
  `st_pecountry` varchar(255) NOT NULL,
  `st_pemobileno` varchar(255) NOT NULL,
  `st_refposname1` varchar(255) NOT NULL,
  `st_refposname2` varchar(255) NOT NULL,
  `st_refposname3` varchar(255) NOT NULL,
  `st_refdesignation1` varchar(255) NOT NULL,
  `st_refdesignation2` varchar(255) NOT NULL,
  `st_refdesignation3` varchar(255) NOT NULL,
  `st_refinsititute1` varchar(255) NOT NULL,
  `st_refinsititute2` varchar(255) NOT NULL,
  `st_refinsititute3` varchar(255) NOT NULL,
  `st_refemail1` varchar(255) NOT NULL,
  `st_refemail2` varchar(255) NOT NULL,
  `st_refemail3` varchar(255) NOT NULL,
  `st_writentest` varchar(255) NOT NULL,
  `st_technicalinterview` varchar(255) NOT NULL,
  `st_finalinterview` varchar(255) NOT NULL,
  `status` enum('selected','notselected','onhold','added','dismisied') NOT NULL,
  `st_perviouspackage` varchar(255) NOT NULL,
  `st_basic` varchar(255) NOT NULL,
  `st_dateofjoining` varchar(255) NOT NULL,
  `st_post` varchar(255) NOT NULL,
  `st_department` varchar(255) NOT NULL,
  `st_remarks` int(255) NOT NULL,
  `intdate` date NOT NULL,
  `image` varchar(255) NOT NULL,
  `selstatus` enum('issued','notissued','accepted','notaccepted') NOT NULL,
  `tcstatus` enum('notissued','issued','resigned') NOT NULL,
  `st_username` varchar(255) NOT NULL,
  `st_password` varchar(255) NOT NULL,
  `st_theme` varchar(255) NOT NULL,
  `st_class` varchar(255) NOT NULL,
  `st_subject` varchar(255) NOT NULL,
  `st_qualification` varchar(255) NOT NULL,
  `st_marks1` varchar(255) NOT NULL,
  `st_marks2` varchar(255) NOT NULL,
  `st_marks3` varchar(255) NOT NULL,
  `st_permissions` varchar(255) NOT NULL,
  `st_bloodgroup` varchar(255) NOT NULL,
  `teach_nonteach` enum('teaching','nonteaching') NOT NULL DEFAULT 'teaching',
  `st_emailsend` varchar(255) NOT NULL,
  `terminationdate` varchar(255) NOT NULL,
  `hrdsid` varchar(255) NOT NULL,
  `st_mail` varchar(222) NOT NULL,
  `title` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `st_doa` varchar(255) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `ifsc` varchar(255) NOT NULL,
  `national_publication` varchar(255) NOT NULL,
  `patent` varchar(255) NOT NULL,
  `pf_no` varchar(255) NOT NULL,
  `grosspay` varchar(255) NOT NULL,
  `da` varchar(255) NOT NULL,
  `hra` varchar(255) NOT NULL,
  `allowances` varchar(255) NOT NULL,
  `handi` varchar(255) NOT NULL,
  `minority` varchar(255) NOT NULL,
  `fyteacher` varchar(255) NOT NULL,
  `fycst` varchar(255) NOT NULL,
  `fycs` varchar(255) NOT NULL,
  `commitee` varchar(255) NOT NULL,
  `aicte` varchar(255) NOT NULL,
  `staff_status` varchar(255) NOT NULL,
  `sem` varchar(255) NOT NULL,
  `noofleaves` varchar(255) NOT NULL,
  `incharge` varchar(255) NOT NULL,
  `add_incharge` varchar(255) NOT NULL,
  `st_class1` varchar(255) NOT NULL,
  `st_primarysubject1` varchar(255) NOT NULL,
  `st_status1` varchar(255) NOT NULL,
  `st_class2` varchar(255) NOT NULL,
  `st_primarysubject2` varchar(255) NOT NULL,
  `st_status2` varchar(255) NOT NULL,
  `st_class3` varchar(255) NOT NULL,
  `st_primarysubject3` varchar(255) NOT NULL,
  `st_status3` varchar(255) NOT NULL,
  `st_class4` varchar(255) NOT NULL,
  `st_primarysubject4` varchar(255) NOT NULL,
  `st_status4` varchar(255) NOT NULL,
  `st_class5` varchar(255) NOT NULL,
  `st_primarysubject5` varchar(255) NOT NULL,
  `st_status5` varchar(255) NOT NULL,
  `lab1` varchar(255) NOT NULL,
  `lab2` varchar(255) NOT NULL,
  `lab3` varchar(255) NOT NULL,
  `lab4` varchar(255) NOT NULL,
  `lab5` varchar(255) NOT NULL,
  `coordinator` varchar(255) NOT NULL,
  PRIMARY KEY (`es_staffid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_staff`
--

LOCK TABLES `es_staff` WRITE;
/*!40000 ALTER TABLE `es_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_stationary`
--

DROP TABLE IF EXISTS `es_stationary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_stationary` (
  `stationary_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `st_pay_id` bigint(20) NOT NULL,
  `item_qty` int(11) NOT NULL,
  `invoice_no` varchar(255) NOT NULL,
  `total_amount` bigint(20) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`stationary_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_stationary`
--

LOCK TABLES `es_stationary` WRITE;
/*!40000 ALTER TABLE `es_stationary` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_stationary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_stationary_payment`
--

DROP TABLE IF EXISTS `es_stationary_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_stationary_payment` (
  `st_pay_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) NOT NULL,
  `invoice_no` varchar(255) NOT NULL,
  `total_amount` bigint(20) NOT NULL,
  `waived_amount` bigint(20) NOT NULL,
  `paid_amount` bigint(20) NOT NULL,
  `pay_status` enum('Paid','Pending') NOT NULL DEFAULT 'Pending',
  `saled_date` date NOT NULL,
  `paid_date` date NOT NULL,
  PRIMARY KEY (`st_pay_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_stationary_payment`
--

LOCK TABLES `es_stationary_payment` WRITE;
/*!40000 ALTER TABLE `es_stationary_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_stationary_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_studentabsentnoti`
--

DROP TABLE IF EXISTS `es_studentabsentnoti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_studentabsentnoti` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `exam_name` varchar(222) NOT NULL,
  `exam_date` varchar(222) NOT NULL,
  `roll_number` varchar(222) NOT NULL,
  `marks_obtained` varchar(222) NOT NULL,
  `rank` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `charector` varchar(222) NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `games` varchar(222) NOT NULL,
  `hobbies` varchar(222) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_studentabsentnoti`
--

LOCK TABLES `es_studentabsentnoti` WRITE;
/*!40000 ALTER TABLE `es_studentabsentnoti` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_studentabsentnoti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_subcategory`
--

DROP TABLE IF EXISTS `es_subcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_subcategory` (
  `es_subcategoryid` int(11) NOT NULL AUTO_INCREMENT,
  `subcat_catname` int(11) NOT NULL,
  `subcat_scatname` varchar(255) NOT NULL,
  `subcat_scatdesc` longtext NOT NULL,
  `subcat_status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`es_subcategoryid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_subcategory`
--

LOCK TABLES `es_subcategory` WRITE;
/*!40000 ALTER TABLE `es_subcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_subcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_subject`
--

DROP TABLE IF EXISTS `es_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_subject` (
  `es_subjectid` int(11) NOT NULL AUTO_INCREMENT,
  `subjectid` float NOT NULL,
  `es_subjectname` varchar(255) NOT NULL,
  `es_subjectcode` varchar(255) NOT NULL,
  `es_subjectshortname` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`es_subjectid`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_subject`
--

LOCK TABLES `es_subject` WRITE;
/*!40000 ALTER TABLE `es_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_taxmaster`
--

DROP TABLE IF EXISTS `es_taxmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_taxmaster` (
  `es_taxmasterid` int(11) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(255) NOT NULL,
  `tax_percentage_type` varchar(255) NOT NULL,
  `tax_to` varchar(255) NOT NULL,
  `tax_from` varchar(255) NOT NULL,
  `tax_rate` varchar(255) NOT NULL,
  `tax_from_date` date NOT NULL,
  `tax_to_date` date NOT NULL,
  `tax_gender` varchar(100) NOT NULL,
  PRIMARY KEY (`es_taxmasterid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_taxmaster`
--

LOCK TABLES `es_taxmaster` WRITE;
/*!40000 ALTER TABLE `es_taxmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_taxmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_tcmaster`
--

DROP TABLE IF EXISTS `es_tcmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_tcmaster` (
  `es_tcmasterid` int(11) NOT NULL AUTO_INCREMENT,
  `tcm_description` longtext NOT NULL,
  PRIMARY KEY (`es_tcmasterid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_tcmaster`
--

LOCK TABLES `es_tcmaster` WRITE;
/*!40000 ALTER TABLE `es_tcmaster` DISABLE KEYS */;
INSERT INTO `es_tcmaster` (`es_tcmasterid`, `tcm_description`) VALUES (1,'tc master');
/*!40000 ALTER TABLE `es_tcmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_tcstudent`
--

DROP TABLE IF EXISTS `es_tcstudent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_tcstudent` (
  `es_tcstudentid` int(11) NOT NULL AUTO_INCREMENT,
  `tcm_description` longtext NOT NULL,
  PRIMARY KEY (`es_tcstudentid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_tcstudent`
--

LOCK TABLES `es_tcstudent` WRITE;
/*!40000 ALTER TABLE `es_tcstudent` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_tcstudent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_timetable`
--

DROP TABLE IF EXISTS `es_timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_timetable` (
  `es_timetableid` int(11) NOT NULL AUTO_INCREMENT,
  `es_class` varchar(255) NOT NULL,
  `es_m1` varchar(255) NOT NULL,
  `es_m2` varchar(255) NOT NULL,
  `es_m3` varchar(255) NOT NULL,
  `es_m4` varchar(255) NOT NULL,
  `es_m5` varchar(255) NOT NULL,
  `es_m6` varchar(255) NOT NULL,
  `es_m7` varchar(255) NOT NULL,
  `es_m8` varchar(255) NOT NULL,
  `es_m9` varchar(255) NOT NULL,
  `es_subject` varchar(255) NOT NULL,
  `es_staffid` varchar(255) NOT NULL,
  `es_t1` varchar(255) NOT NULL,
  `es_t2` varchar(255) NOT NULL,
  `es_t3` varchar(255) NOT NULL,
  `es_t4` varchar(255) NOT NULL,
  `es_t5` varchar(255) NOT NULL,
  `es_t6` varchar(255) NOT NULL,
  `es_t7` varchar(255) NOT NULL,
  `es_t8` varchar(255) NOT NULL,
  `es_t9` varchar(255) NOT NULL,
  `es_w1` varchar(255) NOT NULL,
  `es_w2` varchar(255) NOT NULL,
  `es_w3` varchar(255) NOT NULL,
  `es_w4` varchar(255) NOT NULL,
  `es_w5` varchar(255) NOT NULL,
  `es_w6` varchar(255) NOT NULL,
  `es_w7` varchar(255) NOT NULL,
  `es_w8` varchar(255) NOT NULL,
  `es_w9` varchar(255) NOT NULL,
  `es_th1` varchar(255) NOT NULL,
  `es_th2` varchar(255) NOT NULL,
  `es_th3` varchar(255) NOT NULL,
  `es_th4` varchar(255) NOT NULL,
  `es_th5` varchar(255) NOT NULL,
  `es_th6` varchar(255) NOT NULL,
  `es_th7` varchar(255) NOT NULL,
  `es_th8` varchar(255) NOT NULL,
  `es_th9` varchar(255) NOT NULL,
  `es_f1` varchar(255) NOT NULL,
  `es_f2` varchar(255) NOT NULL,
  `es_f3` varchar(255) NOT NULL,
  `es_f4` varchar(255) NOT NULL,
  `es_f5` varchar(255) NOT NULL,
  `es_f6` varchar(255) NOT NULL,
  `es_f7` varchar(255) NOT NULL,
  `es_f8` varchar(255) NOT NULL,
  `es_f9` varchar(255) NOT NULL,
  `es_s1` varchar(255) NOT NULL,
  `es_s2` varchar(255) NOT NULL,
  `es_s3` varchar(255) NOT NULL,
  `es_s4` varchar(255) NOT NULL,
  `es_s5` varchar(255) NOT NULL,
  `es_s6` varchar(255) NOT NULL,
  `es_s7` varchar(255) NOT NULL,
  `es_s8` varchar(255) NOT NULL,
  `es_s9` varchar(255) NOT NULL,
  `es_startfrom` time DEFAULT '09:00:00',
  `es_endto` int(11) DEFAULT '9',
  `es_breakfrom` int(11) DEFAULT '20',
  `es_breakto` int(11) DEFAULT '1',
  `es_lunchfrom` int(11) DEFAULT '20',
  `es_lunchto` int(11) DEFAULT '2',
  `es_duration` int(11) NOT NULL DEFAULT '45',
  PRIMARY KEY (`es_timetableid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_timetable`
--

LOCK TABLES `es_timetable` WRITE;
/*!40000 ALTER TABLE `es_timetable` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_timetable6june2012`
--

DROP TABLE IF EXISTS `es_timetable6june2012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_timetable6june2012` (
  `es_timetableid` int(11) NOT NULL AUTO_INCREMENT,
  `es_class` varchar(255) NOT NULL,
  `es_m1` varchar(255) NOT NULL,
  `es_m2` varchar(255) NOT NULL,
  `es_m3` varchar(255) NOT NULL,
  `es_m4` varchar(255) NOT NULL,
  `es_m5` varchar(255) NOT NULL,
  `es_m6` varchar(255) NOT NULL,
  `es_m7` varchar(255) NOT NULL,
  `es_m8` varchar(255) NOT NULL,
  `es_m9` varchar(255) NOT NULL,
  `es_m11` varchar(255) NOT NULL,
  `es_m22` varchar(255) NOT NULL,
  `es_m33` varchar(255) NOT NULL,
  `es_m44` varchar(255) NOT NULL,
  `es_m55` varchar(255) NOT NULL,
  `es_m66` varchar(255) NOT NULL,
  `es_m77` varchar(255) NOT NULL,
  `es_m88` varchar(255) NOT NULL,
  `es_m99` varchar(255) NOT NULL,
  `es_subject` varchar(255) NOT NULL,
  `es_staffid` varchar(255) NOT NULL,
  `es_t1` varchar(255) NOT NULL,
  `es_t2` varchar(255) NOT NULL,
  `es_t3` varchar(255) NOT NULL,
  `es_t4` varchar(255) NOT NULL,
  `es_t5` varchar(255) NOT NULL,
  `es_t6` varchar(255) NOT NULL,
  `es_t7` varchar(255) NOT NULL,
  `es_t8` varchar(255) NOT NULL,
  `es_t9` varchar(255) NOT NULL,
  `es_t11` varchar(255) NOT NULL,
  `es_t22` varchar(255) NOT NULL,
  `es_t33` varchar(255) NOT NULL,
  `es_t44` varchar(255) NOT NULL,
  `es_t55` varchar(255) NOT NULL,
  `es_t66` varchar(255) NOT NULL,
  `es_t77` varchar(255) NOT NULL,
  `es_t88` varchar(255) NOT NULL,
  `es_t99` varchar(255) NOT NULL,
  `es_w1` varchar(255) NOT NULL,
  `es_w2` varchar(255) NOT NULL,
  `es_w3` varchar(255) NOT NULL,
  `es_w4` varchar(255) NOT NULL,
  `es_w5` varchar(255) NOT NULL,
  `es_w6` varchar(255) NOT NULL,
  `es_w7` varchar(255) NOT NULL,
  `es_w8` varchar(255) NOT NULL,
  `es_w9` varchar(255) NOT NULL,
  `es_w11` varchar(255) NOT NULL,
  `es_w22` varchar(255) NOT NULL,
  `es_w33` varchar(255) NOT NULL,
  `es_w44` varchar(255) NOT NULL,
  `es_w55` varchar(255) NOT NULL,
  `es_w66` varchar(255) NOT NULL,
  `es_w77` varchar(255) NOT NULL,
  `es_w88` varchar(255) NOT NULL,
  `es_w99` varchar(255) NOT NULL,
  `es_th1` varchar(255) NOT NULL,
  `es_th2` varchar(255) NOT NULL,
  `es_th3` varchar(255) NOT NULL,
  `es_th4` varchar(255) NOT NULL,
  `es_th5` varchar(255) NOT NULL,
  `es_th6` varchar(255) NOT NULL,
  `es_th7` varchar(255) NOT NULL,
  `es_th8` varchar(255) NOT NULL,
  `es_th9` varchar(255) NOT NULL,
  `es_th11` varchar(255) NOT NULL,
  `es_th22` varchar(255) NOT NULL,
  `es_th33` varchar(255) NOT NULL,
  `es_th44` varchar(255) NOT NULL,
  `es_th55` varchar(255) NOT NULL,
  `es_th66` varchar(255) NOT NULL,
  `es_th77` varchar(255) NOT NULL,
  `es_th88` varchar(255) NOT NULL,
  `es_th99` varchar(255) NOT NULL,
  `es_f1` varchar(255) NOT NULL,
  `es_f2` varchar(255) NOT NULL,
  `es_f3` varchar(255) NOT NULL,
  `es_f4` varchar(255) NOT NULL,
  `es_f5` varchar(255) NOT NULL,
  `es_f6` varchar(255) NOT NULL,
  `es_f7` varchar(255) NOT NULL,
  `es_f8` varchar(255) NOT NULL,
  `es_f9` varchar(255) NOT NULL,
  `es_f11` varchar(255) NOT NULL,
  `es_f22` varchar(255) NOT NULL,
  `es_f33` varchar(255) NOT NULL,
  `es_f44` varchar(255) NOT NULL,
  `es_f55` varchar(255) NOT NULL,
  `es_f66` varchar(255) NOT NULL,
  `es_f77` varchar(255) NOT NULL,
  `es_f88` varchar(255) NOT NULL,
  `es_f99` varchar(255) NOT NULL,
  `es_s1` varchar(255) NOT NULL,
  `es_s2` varchar(255) NOT NULL,
  `es_s3` varchar(255) NOT NULL,
  `es_s4` varchar(255) NOT NULL,
  `es_s5` varchar(255) NOT NULL,
  `es_s6` varchar(255) NOT NULL,
  `es_s7` varchar(255) NOT NULL,
  `es_s8` varchar(255) NOT NULL,
  `es_s9` varchar(255) NOT NULL,
  `es_s11` varchar(255) NOT NULL,
  `es_s22` varchar(255) NOT NULL,
  `es_s33` varchar(255) NOT NULL,
  `es_s44` varchar(255) NOT NULL,
  `es_s55` varchar(255) NOT NULL,
  `es_s66` varchar(255) NOT NULL,
  `es_s77` varchar(255) NOT NULL,
  `es_s88` varchar(255) NOT NULL,
  `es_s99` varchar(255) NOT NULL,
  `es_startfrom` time DEFAULT '09:00:00',
  `es_endto` int(11) DEFAULT '9',
  `es_breakfrom` int(11) DEFAULT '20',
  `es_breakto` int(11) DEFAULT '1',
  `es_lunchfrom` int(11) DEFAULT '20',
  `es_lunchto` int(11) DEFAULT '2',
  `es_duration` int(11) NOT NULL DEFAULT '45',
  PRIMARY KEY (`es_timetableid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_timetable6june2012`
--

LOCK TABLES `es_timetable6june2012` WRITE;
/*!40000 ALTER TABLE `es_timetable6june2012` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_timetable6june2012` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_timetable_staff`
--

DROP TABLE IF EXISTS `es_timetable_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_timetable_staff` (
  `es_st_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_class` varchar(255) NOT NULL,
  `es_m1` varchar(255) NOT NULL,
  `es_m2` varchar(255) NOT NULL,
  `es_m3` varchar(255) NOT NULL,
  `es_m4` varchar(255) NOT NULL,
  `es_m5` varchar(255) NOT NULL,
  `es_m6` varchar(255) NOT NULL,
  `es_m7` varchar(255) NOT NULL,
  `es_m8` varchar(255) NOT NULL,
  `es_m9` varchar(255) NOT NULL,
  `es_m11` varchar(255) NOT NULL,
  `es_m22` varchar(255) NOT NULL,
  `es_m33` varchar(255) NOT NULL,
  `es_m44` varchar(255) NOT NULL,
  `es_m55` varchar(255) NOT NULL,
  `es_m66` varchar(255) NOT NULL,
  `es_m77` varchar(255) NOT NULL,
  `es_m88` varchar(255) NOT NULL,
  `es_m99` varchar(255) NOT NULL,
  `es_subject` varchar(255) NOT NULL,
  `es_staffid` varchar(255) NOT NULL,
  `es_t1` varchar(255) NOT NULL,
  `es_t2` varchar(255) NOT NULL,
  `es_t3` varchar(255) NOT NULL,
  `es_t4` varchar(255) NOT NULL,
  `es_t5` varchar(255) NOT NULL,
  `es_t6` varchar(255) NOT NULL,
  `es_t7` varchar(255) NOT NULL,
  `es_t8` varchar(255) NOT NULL,
  `es_t9` varchar(255) NOT NULL,
  `es_t11` varchar(255) NOT NULL,
  `es_t22` varchar(255) NOT NULL,
  `es_t33` varchar(255) NOT NULL,
  `es_t44` varchar(255) NOT NULL,
  `es_t55` varchar(255) NOT NULL,
  `es_t66` varchar(255) NOT NULL,
  `es_t77` varchar(255) NOT NULL,
  `es_t88` varchar(255) NOT NULL,
  `es_t99` varchar(255) NOT NULL,
  `es_w1` varchar(255) NOT NULL,
  `es_w2` varchar(255) NOT NULL,
  `es_w3` varchar(255) NOT NULL,
  `es_w4` varchar(255) NOT NULL,
  `es_w5` varchar(255) NOT NULL,
  `es_w6` varchar(255) NOT NULL,
  `es_w7` varchar(255) NOT NULL,
  `es_w8` varchar(255) NOT NULL,
  `es_w9` varchar(255) NOT NULL,
  `es_w11` varchar(255) NOT NULL,
  `es_w22` varchar(255) NOT NULL,
  `es_w33` varchar(255) NOT NULL,
  `es_w44` varchar(255) NOT NULL,
  `es_w55` varchar(255) NOT NULL,
  `es_w66` varchar(255) NOT NULL,
  `es_w77` varchar(255) NOT NULL,
  `es_w88` varchar(255) NOT NULL,
  `es_w99` varchar(255) NOT NULL,
  `es_th1` varchar(255) NOT NULL,
  `es_th2` varchar(255) NOT NULL,
  `es_th3` varchar(255) NOT NULL,
  `es_th4` varchar(255) NOT NULL,
  `es_th5` varchar(255) NOT NULL,
  `es_th6` varchar(255) NOT NULL,
  `es_th7` varchar(255) NOT NULL,
  `es_th8` varchar(255) NOT NULL,
  `es_th9` varchar(255) NOT NULL,
  `es_th11` varchar(255) NOT NULL,
  `es_th22` varchar(255) NOT NULL,
  `es_th33` varchar(255) NOT NULL,
  `es_th44` varchar(255) NOT NULL,
  `es_th55` varchar(255) NOT NULL,
  `es_th66` varchar(255) NOT NULL,
  `es_th77` varchar(255) NOT NULL,
  `es_th88` varchar(255) NOT NULL,
  `es_th99` varchar(255) NOT NULL,
  `es_f1` varchar(255) NOT NULL,
  `es_f2` varchar(255) NOT NULL,
  `es_f3` varchar(255) NOT NULL,
  `es_f4` varchar(255) NOT NULL,
  `es_f5` varchar(255) NOT NULL,
  `es_f6` varchar(255) NOT NULL,
  `es_f7` varchar(255) NOT NULL,
  `es_f8` varchar(255) NOT NULL,
  `es_f9` varchar(255) NOT NULL,
  `es_f11` varchar(255) NOT NULL,
  `es_f22` varchar(255) NOT NULL,
  `es_f33` varchar(255) NOT NULL,
  `es_f44` varchar(255) NOT NULL,
  `es_f55` varchar(255) NOT NULL,
  `es_f66` varchar(255) NOT NULL,
  `es_f77` varchar(255) NOT NULL,
  `es_f88` varchar(255) NOT NULL,
  `es_f99` varchar(255) NOT NULL,
  `es_s1` varchar(255) NOT NULL,
  `es_s2` varchar(255) NOT NULL,
  `es_s3` varchar(255) NOT NULL,
  `es_s4` varchar(255) NOT NULL,
  `es_s5` varchar(255) NOT NULL,
  `es_s6` varchar(255) NOT NULL,
  `es_s7` varchar(255) NOT NULL,
  `es_s8` varchar(255) NOT NULL,
  `es_s9` varchar(255) NOT NULL,
  `es_s11` varchar(255) NOT NULL,
  `es_s22` varchar(255) NOT NULL,
  `es_s33` varchar(255) NOT NULL,
  `es_s44` varchar(255) NOT NULL,
  `es_s55` varchar(255) NOT NULL,
  `es_s66` varchar(255) NOT NULL,
  `es_s77` varchar(255) NOT NULL,
  `es_s88` varchar(255) NOT NULL,
  `es_s99` varchar(255) NOT NULL,
  PRIMARY KEY (`es_st_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_timetable_staff`
--

LOCK TABLES `es_timetable_staff` WRITE;
/*!40000 ALTER TABLE `es_timetable_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_timetable_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_timetable_subject`
--

DROP TABLE IF EXISTS `es_timetable_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_timetable_subject` (
  `es_sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_class` varchar(255) NOT NULL,
  `es_m1` varchar(255) NOT NULL,
  `es_m2` varchar(255) NOT NULL,
  `es_m3` varchar(255) NOT NULL,
  `es_m4` varchar(255) NOT NULL,
  `es_m5` varchar(255) NOT NULL,
  `es_m6` varchar(255) NOT NULL,
  `es_m7` varchar(255) NOT NULL,
  `es_m8` varchar(255) NOT NULL,
  `es_m9` varchar(255) NOT NULL,
  `es_m11` varchar(255) NOT NULL,
  `es_m22` varchar(255) NOT NULL,
  `es_m33` varchar(255) NOT NULL,
  `es_m44` varchar(255) NOT NULL,
  `es_m55` varchar(255) NOT NULL,
  `es_m66` varchar(255) NOT NULL,
  `es_m77` varchar(255) NOT NULL,
  `es_m88` varchar(255) NOT NULL,
  `es_m99` varchar(255) NOT NULL,
  `es_subject` varchar(255) NOT NULL,
  `es_staffid` varchar(255) NOT NULL,
  `es_t1` varchar(255) NOT NULL,
  `es_t2` varchar(255) NOT NULL,
  `es_t3` varchar(255) NOT NULL,
  `es_t4` varchar(255) NOT NULL,
  `es_t5` varchar(255) NOT NULL,
  `es_t6` varchar(255) NOT NULL,
  `es_t7` varchar(255) NOT NULL,
  `es_t8` varchar(255) NOT NULL,
  `es_t9` varchar(255) NOT NULL,
  `es_t11` varchar(255) NOT NULL,
  `es_t22` varchar(255) NOT NULL,
  `es_t33` varchar(255) NOT NULL,
  `es_t44` varchar(255) NOT NULL,
  `es_t55` varchar(255) NOT NULL,
  `es_t66` varchar(255) NOT NULL,
  `es_t77` varchar(255) NOT NULL,
  `es_t88` varchar(255) NOT NULL,
  `es_t99` varchar(255) NOT NULL,
  `es_w1` varchar(255) NOT NULL,
  `es_w2` varchar(255) NOT NULL,
  `es_w3` varchar(255) NOT NULL,
  `es_w4` varchar(255) NOT NULL,
  `es_w5` varchar(255) NOT NULL,
  `es_w6` varchar(255) NOT NULL,
  `es_w7` varchar(255) NOT NULL,
  `es_w8` varchar(255) NOT NULL,
  `es_w9` varchar(255) NOT NULL,
  `es_w11` varchar(255) NOT NULL,
  `es_w22` varchar(255) NOT NULL,
  `es_w33` varchar(255) NOT NULL,
  `es_w44` varchar(255) NOT NULL,
  `es_w55` varchar(255) NOT NULL,
  `es_w66` varchar(255) NOT NULL,
  `es_w77` varchar(255) NOT NULL,
  `es_w88` varchar(255) NOT NULL,
  `es_w99` varchar(255) NOT NULL,
  `es_th1` varchar(255) NOT NULL,
  `es_th2` varchar(255) NOT NULL,
  `es_th3` varchar(255) NOT NULL,
  `es_th4` varchar(255) NOT NULL,
  `es_th5` varchar(255) NOT NULL,
  `es_th6` varchar(255) NOT NULL,
  `es_th7` varchar(255) NOT NULL,
  `es_th8` varchar(255) NOT NULL,
  `es_th9` varchar(255) NOT NULL,
  `es_th11` varchar(255) NOT NULL,
  `es_th22` varchar(255) NOT NULL,
  `es_th33` varchar(255) NOT NULL,
  `es_th44` varchar(255) NOT NULL,
  `es_th55` varchar(255) NOT NULL,
  `es_th66` varchar(255) NOT NULL,
  `es_th77` varchar(255) NOT NULL,
  `es_th88` varchar(255) NOT NULL,
  `es_th99` varchar(255) NOT NULL,
  `es_f1` varchar(255) NOT NULL,
  `es_f2` varchar(255) NOT NULL,
  `es_f3` varchar(255) NOT NULL,
  `es_f4` varchar(255) NOT NULL,
  `es_f5` varchar(255) NOT NULL,
  `es_f6` varchar(255) NOT NULL,
  `es_f7` varchar(255) NOT NULL,
  `es_f8` varchar(255) NOT NULL,
  `es_f9` varchar(255) NOT NULL,
  `es_f11` varchar(255) NOT NULL,
  `es_f22` varchar(255) NOT NULL,
  `es_f33` varchar(255) NOT NULL,
  `es_f44` varchar(255) NOT NULL,
  `es_f55` varchar(255) NOT NULL,
  `es_f66` varchar(255) NOT NULL,
  `es_f77` varchar(255) NOT NULL,
  `es_f88` varchar(255) NOT NULL,
  `es_f99` varchar(255) NOT NULL,
  `es_s1` varchar(255) NOT NULL,
  `es_s2` varchar(255) NOT NULL,
  `es_s3` varchar(255) NOT NULL,
  `es_s4` varchar(255) NOT NULL,
  `es_s5` varchar(255) NOT NULL,
  `es_s6` varchar(255) NOT NULL,
  `es_s7` varchar(255) NOT NULL,
  `es_s8` varchar(255) NOT NULL,
  `es_s9` varchar(255) NOT NULL,
  `es_s11` varchar(255) NOT NULL,
  `es_s22` varchar(255) NOT NULL,
  `es_s33` varchar(255) NOT NULL,
  `es_s44` varchar(255) NOT NULL,
  `es_s55` varchar(255) NOT NULL,
  `es_s66` varchar(255) NOT NULL,
  `es_s77` varchar(255) NOT NULL,
  `es_s88` varchar(255) NOT NULL,
  `es_s99` varchar(255) NOT NULL,
  `es_startfrom` time DEFAULT '09:00:00',
  `es_endto` int(11) DEFAULT '9',
  `es_breakfrom` int(11) DEFAULT '20',
  `es_breakto` int(11) DEFAULT '1',
  `es_lunchfrom` int(11) DEFAULT '20',
  `es_lunchto` int(11) DEFAULT '2',
  `es_duration` int(11) NOT NULL DEFAULT '45',
  PRIMARY KEY (`es_sub_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_timetable_subject`
--

LOCK TABLES `es_timetable_subject` WRITE;
/*!40000 ALTER TABLE `es_timetable_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_timetable_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_timetable_subjects`
--

DROP TABLE IF EXISTS `es_timetable_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_timetable_subjects` (
  `ts_id` int(11) NOT NULL AUTO_INCREMENT,
  `classid` int(11) NOT NULL,
  `subjectname` varchar(255) NOT NULL,
  PRIMARY KEY (`ts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_timetable_subjects`
--

LOCK TABLES `es_timetable_subjects` WRITE;
/*!40000 ALTER TABLE `es_timetable_subjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_timetable_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_timetablemaster`
--

DROP TABLE IF EXISTS `es_timetablemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_timetablemaster` (
  `es_timetablemasterid` int(11) NOT NULL AUTO_INCREMENT,
  `es_class` varchar(255) NOT NULL,
  `es_staffid` varchar(255) NOT NULL,
  `es_subject` varchar(255) NOT NULL,
  `es_teachername` varchar(255) NOT NULL,
  PRIMARY KEY (`es_timetablemasterid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_timetablemaster`
--

LOCK TABLES `es_timetablemaster` WRITE;
/*!40000 ALTER TABLE `es_timetablemaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_timetablemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_tips`
--

DROP TABLE IF EXISTS `es_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_tips` (
  `tip_id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  `lastupdated_on` datetime NOT NULL,
  PRIMARY KEY (`tip_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_tips`
--

LOCK TABLES `es_tips` WRITE;
/*!40000 ALTER TABLE `es_tips` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_tips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_board`
--

DROP TABLE IF EXISTS `es_trans_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_board` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `board_title` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL,
  `status` enum('Active','Inactive','Delete') NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_board`
--

LOCK TABLES `es_trans_board` WRITE;
/*!40000 ALTER TABLE `es_trans_board` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_board_allocation_to_student`
--

DROP TABLE IF EXISTS `es_trans_board_allocation_to_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_board_allocation_to_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `board_id` int(11) NOT NULL,
  `student_staff_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` enum('Active','Inactive','Delete') NOT NULL,
  `created_on` date NOT NULL,
  `deallocated` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_board_allocation_to_student`
--

LOCK TABLES `es_trans_board_allocation_to_student` WRITE;
/*!40000 ALTER TABLE `es_trans_board_allocation_to_student` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_board_allocation_to_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_driver_allocation_to_vehicle`
--

DROP TABLE IF EXISTS `es_trans_driver_allocation_to_vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_driver_allocation_to_vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `status` enum('Active','Inactive','Delete') NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_driver_allocation_to_vehicle`
--

LOCK TABLES `es_trans_driver_allocation_to_vehicle` WRITE;
/*!40000 ALTER TABLE `es_trans_driver_allocation_to_vehicle` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_driver_allocation_to_vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_driver_details`
--

DROP TABLE IF EXISTS `es_trans_driver_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_driver_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_license` varchar(255) NOT NULL,
  `issuing_authority` varchar(255) NOT NULL,
  `valid_date` date NOT NULL,
  `driver_id` int(11) NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `license_doc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_driver_details`
--

LOCK TABLES `es_trans_driver_details` WRITE;
/*!40000 ALTER TABLE `es_trans_driver_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_driver_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_fee_details`
--

DROP TABLE IF EXISTS `es_trans_fee_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_fee_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `installment_type` enum('monthly','yearly') NOT NULL,
  `fee_fromdate` date NOT NULL,
  `fee_todate` date NOT NULL,
  `financial_year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_fee_details`
--

LOCK TABLES `es_trans_fee_details` WRITE;
/*!40000 ALTER TABLE `es_trans_fee_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_fee_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_maintenance`
--

DROP TABLE IF EXISTS `es_trans_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_maintenance` (
  `es_transport_maintenanceid` int(11) NOT NULL AUTO_INCREMENT,
  `tr_transportid` varchar(255) NOT NULL,
  `tr_maintenance_type` varchar(255) NOT NULL,
  `tr_date_of_maintenance` date NOT NULL,
  `tr_amount_paid` double NOT NULL,
  `tr_remarks` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`es_transport_maintenanceid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_maintenance`
--

LOCK TABLES `es_trans_maintenance` WRITE;
/*!40000 ALTER TABLE `es_trans_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_payment_history`
--

DROP TABLE IF EXISTS `es_trans_payment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` bigint(20) NOT NULL,
  `due_month` varchar(100) NOT NULL,
  `pay_amount` double NOT NULL,
  `amount_paid` double NOT NULL,
  `deduction` double NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `paid_on` date NOT NULL,
  `pay_status` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL,
  `voucherid` varchar(255) NOT NULL,
  `balance` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_payment_history`
--

LOCK TABLES `es_trans_payment_history` WRITE;
/*!40000 ALTER TABLE `es_trans_payment_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_payment_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_route`
--

DROP TABLE IF EXISTS `es_trans_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_title` varchar(255) NOT NULL,
  `route_Via` text NOT NULL,
  `amount` double NOT NULL,
  `status` enum('Active','Inactive','Delete') NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_route`
--

LOCK TABLES `es_trans_route` WRITE;
/*!40000 ALTER TABLE `es_trans_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_vehicle`
--

DROP TABLE IF EXISTS `es_trans_vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_vehicle` (
  `es_transportid` int(11) NOT NULL AUTO_INCREMENT,
  `tr_transport_type` enum('bus','Car(Manual)','Car(Auto)','coach','minibus','van','other') NOT NULL,
  `tr_purchase_date` date NOT NULL,
  `tr_transport_name` varchar(255) NOT NULL,
  `tr_vehicle_no` varchar(255) NOT NULL,
  `tr_insurance_date` date NOT NULL,
  `tr_ins_renewal_date` date NOT NULL,
  `tr_seating_capacity` int(11) NOT NULL,
  `status` enum('Active','Inactive','Delete') NOT NULL,
  PRIMARY KEY (`es_transportid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_vehicle`
--

LOCK TABLES `es_trans_vehicle` WRITE;
/*!40000 ALTER TABLE `es_trans_vehicle` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_trans_vehicle_allocation_to_board`
--

DROP TABLE IF EXISTS `es_trans_vehicle_allocation_to_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_trans_vehicle_allocation_to_board` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `board_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `status` enum('Active','Inactive','Delete') NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_trans_vehicle_allocation_to_board`
--

LOCK TABLES `es_trans_vehicle_allocation_to_board` WRITE;
/*!40000 ALTER TABLE `es_trans_vehicle_allocation_to_board` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_trans_vehicle_allocation_to_board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_transferstudent`
--

DROP TABLE IF EXISTS `es_transferstudent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_transferstudent` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `sno` varchar(222) NOT NULL,
  `name` varchar(222) NOT NULL,
  `fname` varchar(222) NOT NULL,
  `nationality` varchar(222) NOT NULL,
  `sc` varchar(222) NOT NULL,
  `dobw` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `subject` text NOT NULL,
  `dobp` date NOT NULL,
  `monthfeepay` varchar(222) NOT NULL,
  `feecons` varchar(222) NOT NULL,
  `doblast` date NOT NULL,
  `datestuck` date NOT NULL,
  `attendance` varchar(222) NOT NULL,
  `sissuecetrti` date NOT NULL,
  `rls` text NOT NULL,
  `ncc` varchar(222) NOT NULL,
  `games` text NOT NULL,
  `conduct` varchar(222) NOT NULL,
  `acharge` varchar(222) NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL DEFAULT 'Active',
  `created_on` date NOT NULL,
  `exam_date` varchar(2222) NOT NULL,
  `gender` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `admissionno` varchar(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_transferstudent`
--

LOCK TABLES `es_transferstudent` WRITE;
/*!40000 ALTER TABLE `es_transferstudent` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_transferstudent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_translist`
--

DROP TABLE IF EXISTS `es_translist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_translist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_title` varchar(255) NOT NULL,
  `status` enum('Active','Inactive','Delete') NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_translist`
--

LOCK TABLES `es_translist` WRITE;
/*!40000 ALTER TABLE `es_translist` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_translist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_transport`
--

DROP TABLE IF EXISTS `es_transport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_transport` (
  `es_transportid` int(11) NOT NULL AUTO_INCREMENT,
  `tr_transport_type` enum('bus','Car(Manual)','Car(Auto)','coach','minibus','van','other') NOT NULL,
  `tr_purchase_date` datetime NOT NULL,
  `tr_transport_no` varchar(255) NOT NULL,
  `tr_transport_name` varchar(255) NOT NULL,
  `tr_vehicle_no` varchar(255) NOT NULL,
  `tr_insurance_date` datetime NOT NULL,
  `tr_ins_renewal_date` datetime NOT NULL,
  `tr_seating_capacity` int(11) NOT NULL,
  `tr_route` varchar(255) NOT NULL,
  `tr_route_from` varchar(255) NOT NULL,
  `tr_route_to` varchar(255) NOT NULL,
  `tr_route_via` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  PRIMARY KEY (`es_transportid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_transport`
--

LOCK TABLES `es_transport` WRITE;
/*!40000 ALTER TABLE `es_transport` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_transport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_transport_allots`
--

DROP TABLE IF EXISTS `es_transport_allots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_transport_allots` (
  `driver_allot_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_staffid` int(11) NOT NULL,
  `es_transportid` int(11) NOT NULL,
  `driver_alloted_date` date DEFAULT NULL,
  `deallocate_date` date NOT NULL,
  `status` enum('Allocated','Deallocated') NOT NULL,
  PRIMARY KEY (`driver_allot_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_transport_allots`
--

LOCK TABLES `es_transport_allots` WRITE;
/*!40000 ALTER TABLE `es_transport_allots` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_transport_allots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_transport_drivers`
--

DROP TABLE IF EXISTS `es_transport_drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_transport_drivers` (
  `driver_id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_license` varchar(255) NOT NULL,
  `issuing_authority` varchar(255) NOT NULL,
  `valid_date` date NOT NULL,
  `es_staffid` int(11) NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `license_doc` varchar(255) NOT NULL,
  PRIMARY KEY (`driver_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_transport_drivers`
--

LOCK TABLES `es_transport_drivers` WRITE;
/*!40000 ALTER TABLE `es_transport_drivers` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_transport_drivers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_transport_maintenance`
--

DROP TABLE IF EXISTS `es_transport_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_transport_maintenance` (
  `es_transport_maintenanceid` int(11) NOT NULL AUTO_INCREMENT,
  `tr_transportid` varchar(255) NOT NULL,
  `tr_maintenance_type` varchar(255) NOT NULL,
  `tr_date_of_maintenance` datetime NOT NULL,
  `tr_amount_paid` double NOT NULL,
  `tr_remarks` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `tr_transportno` varchar(255) NOT NULL,
  `tr_transportname` varchar(255) NOT NULL,
  `es_ledger` varchar(255) NOT NULL,
  PRIMARY KEY (`es_transport_maintenanceid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_transport_maintenance`
--

LOCK TABLES `es_transport_maintenance` WRITE;
/*!40000 ALTER TABLE `es_transport_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_transport_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_transport_places`
--

DROP TABLE IF EXISTS `es_transport_places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_transport_places` (
  `tr_place_id` int(11) NOT NULL AUTO_INCREMENT,
  `place_name` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`tr_place_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_transport_places`
--

LOCK TABLES `es_transport_places` WRITE;
/*!40000 ALTER TABLE `es_transport_places` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_transport_places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_tutorials`
--

DROP TABLE IF EXISTS `es_tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_tutorials` (
  `tut_id` int(11) NOT NULL AUTO_INCREMENT,
  `chapter_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `tut_desc` longtext NOT NULL,
  `lesson` longtext NOT NULL,
  `summary` longtext NOT NULL,
  `created_on` date NOT NULL,
  `user_type` enum('admin','staff') NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`tut_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_tutorials`
--

LOCK TABLES `es_tutorials` WRITE;
/*!40000 ALTER TABLE `es_tutorials` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_tutorials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_undertaking`
--

DROP TABLE IF EXISTS `es_undertaking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_undertaking` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sno` int(22) NOT NULL,
  `date` date NOT NULL,
  `student_name` varchar(222) NOT NULL,
  `father_name` varchar(222) NOT NULL,
  `mother_name` varchar(222) NOT NULL,
  `class_name` varchar(222) NOT NULL,
  `section` varchar(222) NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  `hobbies` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_undertaking`
--

LOCK TABLES `es_undertaking` WRITE;
/*!40000 ALTER TABLE `es_undertaking` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_undertaking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_units`
--

DROP TABLE IF EXISTS `es_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_units` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `es_classesid` int(11) NOT NULL,
  `es_subjectid` int(11) NOT NULL,
  `unit_name` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_units`
--

LOCK TABLES `es_units` WRITE;
/*!40000 ALTER TABLE `es_units` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_userlogs`
--

DROP TABLE IF EXISTS `es_userlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_userlogs` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(9) NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `submodule` varchar(255) NOT NULL,
  `record_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `posted_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_userlogs`
--

LOCK TABLES `es_userlogs` WRITE;
/*!40000 ALTER TABLE `es_userlogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_userlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_videogallery`
--

DROP TABLE IF EXISTS `es_videogallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_videogallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_videogallery`
--

LOCK TABLES `es_videogallery` WRITE;
/*!40000 ALTER TABLE `es_videogallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_videogallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_voucher`
--

DROP TABLE IF EXISTS `es_voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_voucher` (
  `es_voucherid` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_type` varchar(255) NOT NULL,
  `voucher_mode` varchar(255) NOT NULL,
  PRIMARY KEY (`es_voucherid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_voucher`
--

LOCK TABLES `es_voucher` WRITE;
/*!40000 ALTER TABLE `es_voucher` DISABLE KEYS */;
INSERT INTO `es_voucher` (`es_voucherid`, `voucher_type`, `voucher_mode`) VALUES (1,'Sales Order','paidin'),(2,'Sales','paidin'),(3,'Rejection Out','paidin'),(4,'Rejection In','paidout'),(5,'Receipt Note','paidin'),(6,'Contra','paidout'),(7,'Purchase Order','paidout'),(8,'Purchase','paidout'),(9,'Payment','paidout'),(10,'Journal','paidout'),(11,'Debit Note','paidout'),(12,'Credit Note','paidin'),(13,'Receipt','paidin');
/*!40000 ALTER TABLE `es_voucher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es_voucherentry`
--

DROP TABLE IF EXISTS `es_voucherentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es_voucherentry` (
  `es_voucherentryid` int(11) NOT NULL AUTO_INCREMENT,
  `es_vouchertype` varchar(255) NOT NULL,
  `es_receiptno` varchar(255) NOT NULL,
  `es_receiptdate` date NOT NULL,
  `es_paymentmode` varchar(255) NOT NULL,
  `es_bankacc` varchar(255) NOT NULL,
  `es_particulars` varchar(255) NOT NULL,
  `es_amount` double NOT NULL,
  `es_narration` longtext NOT NULL,
  `es_vouchermode` varchar(255) NOT NULL,
  `es_checkno` varchar(255) NOT NULL,
  `es_teller_number` bigint(20) NOT NULL,
  `es_bank_pin` bigint(20) NOT NULL,
  `es_bank_name` varchar(255) NOT NULL,
  `ve_fromfinance` date NOT NULL,
  `ve_tofinance` date NOT NULL,
  PRIMARY KEY (`es_voucherentryid`)
) ENGINE=MyISAM AUTO_INCREMENT=149 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es_voucherentry`
--

LOCK TABLES `es_voucherentry` WRITE;
/*!40000 ALTER TABLE `es_voucherentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `es_voucherentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects_cat`
--

DROP TABLE IF EXISTS `subjects_cat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects_cat` (
  `scat_id` int(11) NOT NULL AUTO_INCREMENT,
  `classid` int(11) NOT NULL,
  `scat_name` varchar(255) NOT NULL,
  `subject_id_array` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`scat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects_cat`
--

LOCK TABLES `subjects_cat` WRITE;
/*!40000 ALTER TABLE `subjects_cat` DISABLE KEYS */;
/*!40000 ALTER TABLE `subjects_cat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'rkgps_test'
--

--
-- Dumping routines for database 'rkgps_test'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-16 13:29:09
