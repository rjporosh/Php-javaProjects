<?php
	sm_registerglobal('pid', 'action','emsg', 'update', 'submit',  'admin', 'back','exportdatabase' ,'sqlfile');
	
if ($action =="exportdatabase"){

$log_insert_sql="INSERT INTO es_userlogs (`user_id`,`table_name`,`module`,`submodule`,`record_id`,`action`,`ipaddress`,`posted_on`)
	 VALUES('".$_SESSION['eschools']['admin_id']."','','BACK UP','EXPORT','".$uid."','EXPORT TABLE DATA','".$_SERVER['REMOTE_ADDR']."',NOW())";
$log_insert_exe=mysql_query($log_insert_sql);

 		
			function tep_db_query($query, $link = 'db_link') {
				$result = mysql_query($query) or tep_db_error($query, mysql_errno(), mysql_error());   
				return $result;
			}
			
			function tep_set_time_limit($limit) {
				if (!get_cfg_var('safe_mode')) {
					set_time_limit($limit);
				}
			}
			function tep_db_fetch_array($db_query) {
				return mysql_fetch_array($db_query);
			}
			function tep_not_null($value) {
				if (is_array($value)) {
					if (sizeof($value) > 0) {
						return true;
					} else {
						return false;
					}
				} else {
					if ( (is_string($value) || is_int($value)) && ($value != '') && ($value != 'NULL') && (strlen(trim($value)) > 0)) {
						return true;
					} else {
						return false;
					}
				}
			}
			tep_set_time_limit(0);
			$backup_file = 'db_' . DB_DATABASE . '-' . date('YmdHis') . '.sql';
			
			$fp = fopen(DIR_FS_BACKUP . $backup_file, 'w');
			
			$schema = '# Exported Data base File in Mysql' . "\n" .                
			'#' . "\n" .
			'# Database Backup For ' . CMP_NAME . "\n" .
			'# Copyright (c) ' . date('Y') . ' ' . CMP_OWNER . "\n" .
			'#' . "\n" .
			'# Database: ' . DB_DATABASE . "\n" .
			'# Database Server: ' . DB_SERVER . "\n" .
			'#' . "\n" .
			'# Backup Date: ' . date(PHP_DATE_TIME_FORMAT) . "\n\n";
			@fputs($fp, $schema);
			
			$tables_query = tep_db_query('show tables');
			while ($tables = tep_db_fetch_array($tables_query)) {
				list(,$table) = each($tables);
			
				$schema = 'drop table if exists ' . $table . ';' . "\n" . 'create table ' . $table . ' (' . "\n";
			
				$table_list = array();
				$fields_query = tep_db_query("show fields from " . $table);
				while ($fields = tep_db_fetch_array($fields_query)) {
					$table_list[] = $fields['Field'];
			
					$schema .= '  ' . $fields['Field'] . ' ' . $fields['Type'];
			
					if (strlen($fields['Default']) > 0) $schema .= ' default \'' . $fields['Default'] . '\'';
			
					if ($fields['Null'] != 'YES') $schema .= ' not null';
			
					if (isset($fields['Extra'])) $schema .= ' ' . $fields['Extra'];
			
					$schema .= ',' . "\n";
				}
			
				$schema = ereg_replace(",\n$", '', $schema);
			
				// add the keys
				$index = array();
				$keys_query = tep_db_query("show keys from " . $table);
				while ($keys = tep_db_fetch_array($keys_query)) {
					$kname = $keys['Key_name'];
			
					if (!isset($index[$kname])) {
						$index[$kname] = array('unique' => !$keys['Non_unique'],
						'fulltext' => ($keys['Index_type'] == 'FULLTEXT' ? '1' : '0'),
						'columns' => array());
					}
				
					$index[$kname]['columns'][] = $keys['Column_name'];
				}
			
				while (list($kname, $info) = each($index)) {
					$schema .= ',' . "\n";
					
					$columns = implode($info['columns'], ', ');
					
					if ($kname == 'PRIMARY') {
						$schema .= '  PRIMARY KEY (' . $columns . ')';
					} elseif ( $info['fulltext'] == '1' ) {
						$schema .= '  FULLTEXT ' . $kname . ' (' . $columns . ')';
					} elseif ($info['unique']) {
						$schema .= '  UNIQUE ' . $kname . ' (' . $columns . ')';
					} else {
						$schema .= '  KEY ' . $kname . ' (' . $columns . ')';
					}
				}
			
				$schema .= "\n" . ');' . "\n\n";
				@fputs($fp, $schema);
			
				// dump the data
				if ( ($table != TABLE_SESSIONS ) && ($table != TABLE_WHOS_ONLINE) ) {
					$rows_query = tep_db_query("select " . implode(',', $table_list) . " from " . $table);
					while ($rows = tep_db_fetch_array($rows_query)) {
						$schema = 'insert into ' . $table . ' (' . implode(', ', $table_list) . ') values (';
						
						reset($table_list);
						while (list(,$i) = each($table_list)) {
							if (!isset($rows[$i])) {
								$schema .= 'NULL, ';
							} elseif (tep_not_null($rows[$i])) {
								$row = addslashes($rows[$i]);
								$row = ereg_replace("\n#", "\n".'\#', $row);
								$schema .= '\'' . $row . '\', ';
							} else {
								$schema .= '\'\', ';
							}
						}
						$schema = ereg_replace(', $', '', $schema) . ');' . "\n";
						@fputs($fp, $schema);
					}
				}
			}
			
			@fclose($fp);
			
			header('Content-type: application/x-octet-stream');
			header('Content-disposition: attachment; filename=' . $backup_file);
			
			readfile(DIR_FS_BACKUP . $backup_file);
			//unlink(DIR_FS_BACKUP . $backup_file);
			exit;
		
	

}

 
 //for import
if ($action=='importdatabase'){
$log_insert_sql="INSERT INTO es_userlogs (`user_id`,`table_name`,`module`,`submodule`,`record_id`,`action`,`ipaddress`,`posted_on`)
	 VALUES('".$_SESSION['eschools']['admin_id']."','','BACK UP','IMPORT','".$uid."','IMPORT TABLE DATA','".$_SERVER['REMOTE_ADDR']."',NOW())";
$log_insert_exe=mysql_query($log_insert_sql);

		
	function osc_db_select_db($database) {
		return mysql_select_db($database);
	}
		
	function osc_db_query($query, $link = 'db_link') {
		global $$link;
		return mysql_query($query);
	}
	
	function osc_db_num_rows($db_query) {
		return mysql_num_rows($db_query);
	}
		
	function osc_db_install($database, $sql_file) {
		global $db_error;
		$db_error = false;
		
			if (!@osc_db_select_db($database)) {
			  if (@osc_db_query('create database ' . $database)) {
				osc_db_select_db($database);
			  } else {
				$db_error = mysql_error();
			  }
			}
		
			if (!$db_error) {
			   if (file_exists($sql_file)) {
				$fd = fopen($sql_file, 'rb');
				$restore_query = fread($fd, filesize($sql_file));
				fclose($fd);
			  } else {
				$db_error = 'SQL file does not exist: ' . $sql_file;
				return $db_error;
			  }
		
			  $sql_array = array();
			  $sql_length = strlen($restore_query);
			  $pos = strpos($restore_query, ';');
			  for ($i=$pos; $i<$sql_length; $i++) {
				if ($restore_query[0] == '#') {
				  $restore_query = ltrim(substr($restore_query, strpos($restore_query, "\n")));
				  $sql_length = strlen($restore_query);
				  $i = strpos($restore_query, ';')-1;
				  continue;
				}
				if ($restore_query[($i+1)] == "\n") {
				  for ($j=($i+2); $j<$sql_length; $j++) {
					if (trim($restore_query[$j]) != '') {
					  $next = substr($restore_query, $j, 6);
					  if ($next[0] == '#') {
		// find out where the break position is so we can remove this line (#comment line)
						for ($k=$j; $k<$sql_length; $k++) {
						  if ($restore_query[$k] == "\n") break;
						}
						$query = substr($restore_query, 0, $i+1);
						$restore_query = substr($restore_query, $k);
		// join the query before the comment appeared, with the rest of the dump
						$restore_query = $query . $restore_query;
						$sql_length = strlen($restore_query);
						$i = strpos($restore_query, ';')-1;
						continue 2;
					  }
					  break;
					}
				  }
				  if ($next == '') { // get the last insert query
					$next = 'insert';
				  }
				  if ( (eregi('create', $next)) || (eregi('insert', $next)) || (eregi('drop t', $next)) ) {
					$next = '';
					$sql_array[] = substr($restore_query, 0, $i);
					$restore_query = ltrim(substr($restore_query, $i+1));
					$sql_length = strlen($restore_query);
					$i = strpos($restore_query, ';')-1;
				  }
				}
			  }   
		
			  for ($i=0; $i<sizeof($sql_array); $i++) {
				osc_db_query($sql_array[$i]);
			  }
			} else {
			  return false;
			}
	}
/**
* For SQL FILE UPLOAD
*/
	if ($_POST['Submit']=='Submit'){
		$error = array();
		if (!ereg("^[a-zA-Z0-9._-]+.sql", $_FILES['sqlfile']['name'])){
			$errormessage[0] = "Please select a SQL File"; 
			$action = "Import";
			unset($emsg);
		}
		if (count($errormessage)==0){
			 if(is_uploaded_file($_FILES['sqlfile']['tmp_name'])) {					
				$uppath = "backups/db_backup.sql";
				if (move_uploaded_file($_FILES['sqlfile']['tmp_name'], $uppath)){
					osc_db_install(DB_DATABASE, $uppath);
					header("Location:?pid=48&action=Import&emsg=23");
				} 			  
			 }
		}
		$action = "Import";
	} 
}
?>