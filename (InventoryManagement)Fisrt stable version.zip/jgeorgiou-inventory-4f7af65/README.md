# inventory
inventory system with barcode support , great for those have simple cashier
