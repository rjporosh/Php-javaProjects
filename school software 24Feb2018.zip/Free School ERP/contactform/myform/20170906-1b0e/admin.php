<?php
require_once( dirname(__FILE__).'/form.lib.php' );

define( 'PHPFMG_USER', "info@cialforlab.com" ); // must be a email address. for sending password to you.
define( 'PHPFMG_PW', "e27de8" );

?>
<?php
/**
 * GNU Library or Lesser General Public License version 2.0 (LGPLv2)
*/

# main
# ------------------------------------------------------
error_reporting( E_ERROR ) ;
phpfmg_admin_main();
# ------------------------------------------------------




function phpfmg_admin_main(){
    $mod  = isset($_REQUEST['mod'])  ? $_REQUEST['mod']  : '';
    $func = isset($_REQUEST['func']) ? $_REQUEST['func'] : '';
    $function = "phpfmg_{$mod}_{$func}";
    if( !function_exists($function) ){
        phpfmg_admin_default();
        exit;
    };

    // no login required modules
    $public_modules   = false !== strpos('|captcha||ajax|', "|{$mod}|");
    $public_functions = false !== strpos('|phpfmg_ajax_submit||phpfmg_mail_request_password||phpfmg_filman_download||phpfmg_image_processing||phpfmg_dd_lookup|', "|{$function}|") ;   
    if( $public_modules || $public_functions ) { 
        $function();
        exit;
    };
    
    return phpfmg_user_isLogin() ? $function() : phpfmg_admin_default();
}

function phpfmg_ajax_submit(){
    $phpfmg_send = phpfmg_sendmail( $GLOBALS['form_mail'] );
    $isHideForm  = isset($phpfmg_send['isHideForm']) ? $phpfmg_send['isHideForm'] : false;

    $response = array(
        'ok' => $isHideForm,
        'error_fields' => isset($phpfmg_send['error']) ? $phpfmg_send['error']['fields'] : '',
        'OneEntry' => isset($GLOBALS['OneEntry']) ? $GLOBALS['OneEntry'] : '',
    );
    
    @header("Content-Type:text/html; charset=$charset");
    echo "<html><body><script>
    var response = " . json_encode( $response ) . ";
    try{
        parent.fmgHandler.onResponse( response );
    }catch(E){};
    \n\n";
    echo "\n\n</script></body></html>";

}


function phpfmg_admin_default(){
    if( phpfmg_user_login() ){
        phpfmg_admin_panel();
    };
}



function phpfmg_admin_panel()
{    
    if( !phpfmg_user_isLogin() ){
        exit;
    };

    phpfmg_admin_header();
    phpfmg_writable_check();
?>    
<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td valign=top style="padding-left:280px;">

<style type="text/css">
    .fmg_title{
        font-size: 16px;
        font-weight: bold;
        padding: 10px;
    }
    
    .fmg_sep{
        width:32px;
    }
    
    .fmg_text{
        line-height: 150%;
        vertical-align: top;
        padding-left:28px;
    }

</style>

<script type="text/javascript">
    function deleteAll(n){
        if( confirm("Are you sure you want to delete?" ) ){
            location.href = "admin.php?mod=log&func=delete&file=" + n ;
        };
        return false ;
    }
</script>


<div class="fmg_title">
    1. Email Traffics
</div>
<div class="fmg_text">
    <a href="admin.php?mod=log&func=view&file=1">view</a> &nbsp;&nbsp;
    <a href="admin.php?mod=log&func=download&file=1">download</a> &nbsp;&nbsp;
    <?php 
        if( file_exists(PHPFMG_EMAILS_LOGFILE) ){
            echo '<a href="#" onclick="return deleteAll(1);">delete all</a>';
        };
    ?>
</div>


<div class="fmg_title">
    2. Form Data
</div>
<div class="fmg_text">
    <a href="admin.php?mod=log&func=view&file=2">view</a> &nbsp;&nbsp;
    <a href="admin.php?mod=log&func=download&file=2">download</a> &nbsp;&nbsp;
    <?php 
        if( file_exists(PHPFMG_SAVE_FILE) ){
            echo '<a href="#" onclick="return deleteAll(2);">delete all</a>';
        };
    ?>
</div>

<div class="fmg_title">
    3. Form Generator
</div>
<div class="fmg_text">
    <a href="http://www.formmail-maker.com/generator.php" onclick="document.frmFormMail.submit(); return false;" title="<?php echo htmlspecialchars(PHPFMG_SUBJECT);?>">Edit Form</a> &nbsp;&nbsp;
    <a href="http://www.formmail-maker.com/generator.php" >New Form</a>
</div>
    <form name="frmFormMail" action='http://www.formmail-maker.com/generator.php' method='post' enctype='multipart/form-data'>
    <input type="hidden" name="uuid" value="<?php echo PHPFMG_ID; ?>">
    <input type="hidden" name="external_ini" value="<?php echo function_exists('phpfmg_formini') ?  phpfmg_formini() : ""; ?>">
    </form>

		</td>
	</tr>
</table>

<?php
    phpfmg_admin_footer();
}



function phpfmg_admin_header( $title = '' ){
    header( "Content-Type: text/html; charset=" . PHPFMG_CHARSET );
?>
<html>
<head>
    <title><?php echo '' == $title ? '' : $title . ' | ' ; ?>PHP FormMail Admin Panel </title>
    <meta name="keywords" content="PHP FormMail Generator, PHP HTML form, send html email with attachment, PHP web form,  Free Form, Form Builder, Form Creator, phpFormMailGen, Customized Web Forms, phpFormMailGenerator,formmail.php, formmail.pl, formMail Generator, ASP Formmail, ASP form, PHP Form, Generator, phpFormGen, phpFormGenerator, anti-spam, web hosting">
    <meta name="description" content="PHP formMail Generator - A tool to ceate ready-to-use web forms in a flash. Validating form with CAPTCHA security image, send html email with attachments, send auto response email copy, log email traffics, save and download form data in Excel. ">
    <meta name="generator" content="PHP Mail Form Generator, phpfmg.sourceforge.net">

    <style type='text/css'>
    body, td, label, div, span{
        font-family : Verdana, Arial, Helvetica, sans-serif;
        font-size : 12px;
    }
    </style>
</head>
<body  marginheight="0" marginwidth="0" leftmargin="0" topmargin="0">

<table cellspacing=0 cellpadding=0 border=0 width="100%">
    <td nowrap align=center style="background-color:#024e7b;padding:10px;font-size:18px;color:#ffffff;font-weight:bold;width:250px;" >
        Form Admin Panel
    </td>
    <td style="padding-left:30px;background-color:#86BC1B;width:100%;font-weight:bold;" >
        &nbsp;
<?php
    if( phpfmg_user_isLogin() ){
        echo '<a href="admin.php" style="color:#ffffff;">Main Menu</a> &nbsp;&nbsp;' ;
        echo '<a href="admin.php?mod=user&func=logout" style="color:#ffffff;">Logout</a>' ;
    }; 
?>
    </td>
</table>

<div style="padding-top:28px;">

<?php
    
}


function phpfmg_admin_footer(){
?>

</div>

<div style="color:#cccccc;text-decoration:none;padding:18px;font-weight:bold;">
	:: <a href="http://phpfmg.sourceforge.net" target="_blank" title="Free Mailform Maker: Create read-to-use Web Forms in a flash. Including validating form with CAPTCHA security image, send html email with attachments, send auto response email copy, log email traffics, save and download form data in Excel. " style="color:#cccccc;font-weight:bold;text-decoration:none;">PHP FormMail Generator</a> ::
</div>

</body>
</html>
<?php
}


function phpfmg_image_processing(){
    $img = new phpfmgImage();
    $img->out_processing_gif();
}


# phpfmg module : captcha
# ------------------------------------------------------
function phpfmg_captcha_get(){
    $img = new phpfmgImage();
    $img->out();
    //$_SESSION[PHPFMG_ID.'fmgCaptchCode'] = $img->text ;
    $_SESSION[ phpfmg_captcha_name() ] = $img->text ;
}



function phpfmg_captcha_generate_images(){
    for( $i = 0; $i < 50; $i ++ ){
        $file = "$i.png";
        $img = new phpfmgImage();
        $img->out($file);
        $data = base64_encode( file_get_contents($file) );
        echo "'{$img->text}' => '{$data}',\n" ;
        unlink( $file );
    };
}


function phpfmg_dd_lookup(){
    $paraOk = ( isset($_REQUEST['n']) && isset($_REQUEST['lookup']) && isset($_REQUEST['field_name']) );
    if( !$paraOk )
        return;
        
    $base64 = phpfmg_dependent_dropdown_data();
    $data = @unserialize( base64_decode($base64) );
    if( !is_array($data) ){
        return ;
    };
    
    
    foreach( $data as $field ){
        if( $field['name'] == $_REQUEST['field_name'] ){
            $nColumn = intval($_REQUEST['n']);
            $lookup  = $_REQUEST['lookup']; // $lookup is an array
            $dd      = new DependantDropdown(); 
            echo $dd->lookupFieldColumn( $field, $nColumn, $lookup );
            return;
        };
    };
    
    return;
}


function phpfmg_filman_download(){
    if( !isset($_REQUEST['filelink']) )
        return ;
        
    $filelink =  base64_decode($_REQUEST['filelink']);
    $file = PHPFMG_SAVE_ATTACHMENTS_DIR . basename($filelink);

    // 2016-12-05:  to prevent *LFD/LFI* attack. patch provided by Pouya Darabi, a security researcher in cert.org
    $real_basePath = realpath(PHPFMG_SAVE_ATTACHMENTS_DIR); 
    $real_requestPath = realpath($file);
    if ($real_requestPath === false || strpos($real_requestPath, $real_basePath) !== 0) { 
        return; 
    }; 

    if( !file_exists($file) ){
        return ;
    };
    
    phpfmg_util_download( $file, $filelink );
}


class phpfmgDataManager
{
    var $dataFile = '';
    var $columns = '';
    var $records = '';
    
    function __construct(){
        $this->dataFile = PHPFMG_SAVE_FILE; 
    }

    function phpfmgDataManager(){
        $this->dataFile = PHPFMG_SAVE_FILE; 
    }
    
    function parseFile(){
        $fp = @fopen($this->dataFile, 'rb');
        if( !$fp ) return false;
        
        $i = 0 ;
        $phpExitLine = 1; // first line is php code
        $colsLine = 2 ; // second line is column headers
        $this->columns = array();
        $this->records = array();
        $sep = chr(0x09);
        while( !feof($fp) ) { 
            $line = fgets($fp);
            $line = trim($line);
            if( empty($line) ) continue;
            $line = $this->line2display($line);
            $i ++ ;
            switch( $i ){
                case $phpExitLine:
                    continue;
                    break;
                case $colsLine :
                    $this->columns = explode($sep,$line);
                    break;
                default:
                    $this->records[] = explode( $sep, phpfmg_data2record( $line, false ) );
            };
        }; 
        fclose ($fp);
    }
    
    function displayRecords(){
        $this->parseFile();
        echo "<table border=1 style='width=95%;border-collapse: collapse;border-color:#cccccc;' >";
        echo "<tr><td>&nbsp;</td><td><b>" . join( "</b></td><td>&nbsp;<b>", $this->columns ) . "</b></td></tr>\n";
        $i = 1;
        foreach( $this->records as $r ){
            echo "<tr><td align=right>{$i}&nbsp;</td><td>" . join( "</td><td>&nbsp;", $r ) . "</td></tr>\n";
            $i++;
        };
        echo "</table>\n";
    }
    
    function line2display( $line ){
        $line = str_replace( array('"' . chr(0x09) . '"', '""'),  array(chr(0x09),'"'),  $line );
        $line = substr( $line, 1, -1 ); // chop first " and last "
        return $line;
    }
    
}
# end of class



# ------------------------------------------------------
class phpfmgImage
{
    var $im = null;
    var $width = 73 ;
    var $height = 33 ;
    var $text = '' ; 
    var $line_distance = 8;
    var $text_len = 4 ;

    function __construct( $text = '', $len = 4 ){
        $this->phpfmgImage( $text, $len );
    }

    function phpfmgImage( $text = '', $len = 4 ){
        $this->text_len = $len ;
        $this->text = '' == $text ? $this->uniqid( $this->text_len ) : $text ;
        $this->text = strtoupper( substr( $this->text, 0, $this->text_len ) );
    }
    
    function create(){
        $this->im = imagecreate( $this->width, $this->height );
        $bgcolor   = imagecolorallocate($this->im, 255, 255, 255);
        $textcolor = imagecolorallocate($this->im, 0, 0, 0);
        $this->drawLines();
        imagestring($this->im, 5, 20, 9, $this->text, $textcolor);
    }
    
    function drawLines(){
        $linecolor = imagecolorallocate($this->im, 210, 210, 210);
    
        //vertical lines
        for($x = 0; $x < $this->width; $x += $this->line_distance) {
          imageline($this->im, $x, 0, $x, $this->height, $linecolor);
        };
    
        //horizontal lines
        for($y = 0; $y < $this->height; $y += $this->line_distance) {
          imageline($this->im, 0, $y, $this->width, $y, $linecolor);
        };
    }
    
    function out( $filename = '' ){
        if( function_exists('imageline') ){
            $this->create();
            if( '' == $filename ) header("Content-type: image/png");
            ( '' == $filename ) ? imagepng( $this->im ) : imagepng( $this->im, $filename );
            imagedestroy( $this->im ); 
        }else{
            $this->out_predefined_image(); 
        };
    }

    function uniqid( $len = 0 ){
        $md5 = md5( uniqid(rand()) );
        return $len > 0 ? substr($md5,0,$len) : $md5 ;
    }
    
    function out_predefined_image(){
        header("Content-type: image/png");
        $data = $this->getImage(); 
        echo base64_decode($data);
    }
    
    // Use predefined captcha random images if web server doens't have GD graphics library installed  
    function getImage(){
        $images = array(
			'E006' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXUlEQVR4nGNYhQEaGAYTpIn7QkMYAhimMEx1QBILaGAMYQhlCAhAEWNtZXR0dBBAERNpdG0IdEB2X2jUtJWpqyJTs5DcB1WHZh5ErwgWO0QIuAWbmwcq/KgIsbgPAGmkzGuUDCoeAAAAAElFTkSuQmCC',
			'1D16' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7GB1EQximMEx1QBJjdRBpZQhhCAhAEhN1EGl0DGF0EEDRK9LoMIXRAdl9K7OmgVBqFpL7oOpQzIPpFSEs1gp0H6pbQkRDGEMdUNw8UOFHRYjFfQBZyclJsfzPMAAAAABJRU5ErkJggg==',
			'0418' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nGNYhQEaGAYTpIn7GB0YWhmmMEx1QBJjDWCYyhDCEBCAJCYyhSGUMYTRQQRJLKCV0RWoF6YO7KSopUuXrpq2amoWkvsCWkVakdRBxURDHaagmge0A6gOVQzoFgy9IDczhjqguHmgwo+KEIv7AF7nyt/N8CwtAAAAAElFTkSuQmCC',
			'95D1' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7WANEQ1lDGVqRxUSmiDSwNjpMRRYLaAWKNQSEoomFAMVgesFOmjZ16tKlq6KWIruP1ZWh0RWhDgJbMcUEWkUwxESmsLYC3YIixhrAGAJ0c2jAIAg/KkIs7gMAHwjM9nIEDA8AAAAASUVORK5CYII=',
			'4C76' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdUlEQVR4nM2QsQ2AMAwEnSI9RQYyBb2R4hFomMLZIWQDCjIlobOBEgT+7vR6nQz1cgJ/yjt+2bFnWlCz6BMKESnmYhCUETvFfA4CqUftV0qpdd2mWfnR0cvO7DE3Rg6DcQnS45n5NLQmGdacBazzV/97Ljd+O2GqzDt/1CGpAAAAAElFTkSuQmCC',
			'D212' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7QgMYQximMEx1QBILmMLayhDCEBCALNYq0ugYwugggiLG0OgwhaFBBMl9UUtXLV01DUgjuQ+obgoQNjqg6g0AirUyoIgxOoBVorqlASgSgOpm0VBHIAwZBOFHRYjFfQDRhM10TrvN8wAAAABJRU5ErkJggg==',
			'D55D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7QgNEQ1lDHUMdkMQCpog0sDYwOgQgi7VCxERQxUJYp8LFwE6KWjp16dLMzKxpSO4LaGVodGgIRNOLTUyk0RVdbAprK6OjI4pbQgMYQxhCGVHcPFDhR0WIxX0ACv3M55lACZoAAAAASUVORK5CYII=',
			'A264' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdElEQVR4nM2QvRGAIAxGQ5ENcJ9Q2Mc70jBNLNgAR6BhSikDWuppvu5dft4F2qUU/pRX/By5CALKhiFjdoF2y3zx+6qULeMMnUFh45dqq/VoKRm/3lcwBLKzIsCom8RhnyPsJuMN1O4ysUVocv7qfw/mxu8EXlbOOBxrI54AAAAASUVORK5CYII=',
			'CC6E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7WEMYQxlCGUMDkMREWlkbHR0dHZDVBTSKNLg2oIk1iDSwNjDCxMBOilo1bdXSqStDs5DcB1aHbh5YbyAWO1DFsLkFm5sHKvyoCLG4DwCsFMr+obtggQAAAABJRU5ErkJggg==',
			'2D2D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdElEQVR4nGNYhQEaGAYTpIn7WANEQxhCGUMdkMREpoi0Mjo6OgQgiQW0ijS6NgQ6iCDrBoo5IMQgbpo2bWXWysysacjuCwCqa2VE0QvkNTpMQRVjbQCKBaCKiTQA3eLAiOKW0FDRENbQQBQ3D1T4URFicR8AqWfK5bGAquIAAAAASUVORK5CYII=',
			'1708' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7GB1EQx2mMEx1QBJjdWBodAhlCAhAEhMFijk6OjqIoOhlaGVtCICpAztpZdaqaUtXRU3NQnIfUF0AkjqoGKMDa0MgmnmsDYwYdgB56G4JAYqhuXmgwo+KEIv7AJvuyTwh/LgvAAAAAElFTkSuQmCC',
			'7E19' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7QkNFQxmmMEx1QBZtFWlgCGEICEATYwxhdBBBFpsC5E2Bi0HcFDU1bNW0VVFhSO4DqwDagayXtQEs1oAsJgIRQ7EjACKG4paABtFQxlAHVDcPUPhREWJxHwAuusrSf3F4ogAAAABJRU5ErkJggg==',
			'F928' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7QkMZQxhCGaY6IIkFNLC2Mjo6BASgiIk0ujYEOoigiTk0BMDUgZ0UGrV0adbKrKlZSO4LaGAMdGhlQDOPodFhCiOaeSyNDgHoYkC3OKDrZQxhDQ1AcfNAhR8VIRb3AQDAu81jmAqpGgAAAABJRU5ErkJggg==',
			'BE35' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7QgNEQxmBMABJLGCKSANro6MDsrqAVhEgGYgqBlTH0Ojo6oDkvtCoqWGrpq6MikJyH0SdQ4MIhnkBWMQCHUQa0N3iEIDsPoibGaY6DILwoyLE4j4AoNvNhBnUWMQAAAAASUVORK5CYII=',
			'8C25' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7WAMYQxlCGUMDkMREprA2Ojo6OiCrC2gVaXBtCEQRE5kiAiQDXR2Q3Lc0atqqVSszo6KQ3AdW1wqk0cxjmIIp5hDA6CDSgOYWB4YAZPeB3MwaGjDVYRCEHxUhFvcBAJTZy89ATydXAAAAAElFTkSuQmCC',
			'7537' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7QkNFQxmBMARZtFWkgbXRoUEETYyhIQBVbIpICANQXQCy+6KmLl01ddXKLCT3MToAVTU6tCLby9oA1jkFWUykQQQkFoAsFtDA2sra6OiAKsYYAnQzithAhR8VIRb3AQDrQMyuZH/88wAAAABJRU5ErkJggg==',
			'E2D5' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7QkMYQ1hDGUMDkMQCGlhbWRsdHRhQxEQaXRsC0cQYQGKuDkjuC41atXTpqsioKCT3AdVNYQWZgKo3AFOM0YEVaAeqGGsDa6NDALL7QkNEQ11DGaY6DILwoyLE4j4AoI7Neb7JeTkAAAAASUVORK5CYII=',
			'686A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7WAMYQxhCGVqRxUSmsLYyOjpMdUASC2gRaXRtcAgIQBZrYG1lbWB0EEFyX2TUyrClU1dmTUNyXwjQPFZHR5g6iN5WkHmBoSGYYijqIG5B1QtxMyOK2ECFHxUhFvcBAN7Cy9b6b+c6AAAAAElFTkSuQmCC',
			'008A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7GB0YAhhCGVqRxVgDGEMYHR2mOiCJiUxhbWVtCAgIQBILaBVpdHR0dBBBcl/U0mkrs0JXZk1Dch+aOriYa0NgaAiGHYEo6iBuQdULcTMjithAhR8VIRb3AQDzEMpHeGyd3AAAAABJRU5ErkJggg==',
			'C039' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7WEMYAhhDGaY6IImJtDKGsDY6BAQgiQU0srYyNAQ6iCCLNYg0OjQ6wsTATopaNW1l1tRVUWFI7oOoc5iKoRdEYtgRgGIHNrdgc/NAhR8VIRb3AQAo2M0JsLaa3QAAAABJRU5ErkJggg==',
			'FD70' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7QkNFQ1hDA1qRxQIaRID8gKkOqGKNDg0BAQHoYo2ODiJI7guNmrYya+nKrGlI7gOrm8IIU4cQC8AUc3RgQLejlbWBAc0tQDc3MKC4eaDCj4oQi/sAQcjOdU0lRVwAAAAASUVORK5CYII=',
			'1C60' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7GB0YQxlCGVqRxVgdWBsdHR2mOiCJiTqINLg2OAQEoOgVaWAFkwj3rcyatmrpVBCJcB9YHdBAEQy9gRhirg0BaHZgcUsIppsHKvyoCLG4DwAL+snBZC+BAQAAAABJRU5ErkJggg==',
			'EEE3' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAT0lEQVR4nGNYhQEaGAYTpIn7QkNEQ1lDHUIdkMQCGkQaWBsYHQIwxBiAJKZYAJL7QqOmhi0NXbU0C8l9aOoImocphuoWbG4eqPCjIsTiPgApHsz508GPYgAAAABJRU5ErkJggg==',
			'6E8C' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYElEQVR4nGNYhQEaGAYTpIn7WANEQxlCGaYGIImJTBFpYHR0CBBBEgtoEWlgbQh0YEEWawCpc3RAdl9k1NSwVaErs5DdFzIFRR1EbyvEPGxiyHZgcws2Nw9U+FERYnEfAFyMysU87wlkAAAAAElFTkSuQmCC',
			'3A75' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7RAMYAlhDA0MDkMQCpjCGMDQEOqCobGVtxRCbItLo0Ojo6oDkvpVR01ZmLV0ZFYXsPpC6KQwNIijmiYY6BKCLiTQ6OjA6iKC4RaTRtYEhANl9ogFgsakOgyD8qAixuA8A083MHmad7e4AAAAASUVORK5CYII=',
			'CE93' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAX0lEQVR4nGNYhQEaGAYTpIn7WENEQxmA0AFJTKRVpIHR0dEhAEksoFGkgbUhoEEEWawBIhaA5L6oVVPDVmZGLc1Cch9YVwhcHUIM3TygHYxoYtjcgs3NAxV+VIRY3AcA8ffM0App1PwAAAAASUVORK5CYII=',
			'A72B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdklEQVR4nGNYhQEaGAYTpIn7GB1EQx1CGUMdkMRYAxgaHR0dHQKQxESmMDS6NgQ6iCCJBbQytDIAxQKQ3Be1dNW0VSszQ7OQ3AdUF8DQyohiXmgoowPDFEY081gbGALQxUSAbkTVCxJjDQ1EcfNAhR8VIRb3AQDySstEPBnG2AAAAABJRU5ErkJggg==',
			'9EB7' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7WANEQ1lDGUNDkMREpog0sDY6NIggiQW0AsUaAjDFgOoCkNw3berUsKWhq1ZmIbmP1RWsrhXFZoh5U5DFBCBiAQwYbnF0wOJmFLGBCj8qQizuAwAi18vY1bBFKwAAAABJRU5ErkJggg==',
			'8E12' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7WANEQxmmMEx1QBITmSLSwBDCEBCAJBbQKtLAGMLoIIKubgqQRnLf0qipYaumrVoVheQ+qLpGBzTzgGKtDJhiUxgw7QhAdzNjqGNoyCAIPypCLO4DAIjcy7Uf17kDAAAAAElFTkSuQmCC',
			'0517' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdElEQVR4nGNYhQEaGAYTpIn7GB1EQxmmMIaGIImxBog0MIQwNIggiYlMEWlgRBMLaBUJYZgCpJHcF7V06tJV01atzEJyX0ArQ6PDFIZWBhS9YLEpDKh2gMQCGFDcwtoKdJ8DqpsZQxhDHVHEBir8qAixuA8AwbfK8JjTj6cAAAAASUVORK5CYII=',
			'38B8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAVElEQVR4nGNYhQEaGAYTpIn7RAMYQ1hDGaY6IIkFTGFtZW10CAhAVtkq0ujaEOgggiyGqg7spJVRK8OWhq6amoXsPmLNwyKGzS3Y3DxQ4UdFiMV9ACYszP7ttjDeAAAAAElFTkSuQmCC',
			'8176' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7WAMYAlhDA6Y6IImJTGEMYGgICAhAEgtoBapsCHQQQFHHEMDQ6OiA7L6lUauiVi1dmZqF5D6wOqCZqOYBxQIYHUTQxBgdUMVAelkbGFD0sgJdDBRDcfNAhR8VIRb3AQBffsm/amXD8AAAAABJRU5ErkJggg==',
			'AE5A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7GB1EQ1lDHVqRxVgDRBpYGximOiCJiUwBiwUEIIkFtALFpjI6iCC5L2rp1LClmZlZ05DcB1LH0BAIUweGoaFgsdAQdPPQ1IHEGB0d0cREQxlCGVHEBir8qAixuA8AH9/LdMjB+R4AAAAASUVORK5CYII=',
			'288B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAX0lEQVR4nGNYhQEaGAYTpIn7WAMYQxhCGUMdkMREprC2Mjo6OgQgiQW0ijS6NgQ6iCDrbkVRB3HTtJVhq0JXhmYhuy8A0zxGB0zzWBswxUQaMPWGhmK6eaDCj4oQi/sAFUPKjeyHqHsAAAAASUVORK5CYII=',
			'EBF3' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAVklEQVR4nGNYhQEaGAYTpIn7QkNEQ1hDA0IdkMQCGkRaWRsYHQJQxRpdgbQIhjoQjXBfaNTUsKWhq5ZmIbkPTR0+83DYgeoWsJsbGFDcPFDhR0WIxX0AMz/NyXUCYSUAAAAASUVORK5CYII=',
			'2675' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdklEQVR4nM2Quw2AMAxEncIbmH1MQe9IhCLTOIU3ADagIFOS0nxKkPB1d/bpyVBvo/AnfcKHEkZMMYnzaEYDjez3xKhcPTBSKP3Anm9dp7rtOXs+6Qzm1utuA1NhOXuoVHpuiWdRNGwNni+lxqyw8A/+96Ie+A5/+MrTdGFpyQAAAABJRU5ErkJggg==',
			'C189' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7WEMYAhhCGaY6IImJtDIGMDo6BAQgiQU0sgawNgQ6iCCLNTAA1TnCxMBOigKh0FVRYUjug6hzmIqulxVIoog1gsVQ7BBpZcBwC2sIayi6mwcq/KgIsbgPACYZydg6I2xiAAAAAElFTkSuQmCC',
			'12B0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7GB0YQ1hDGVqRxVgdWFtZGx2mOiCJiTqINLo2BAQEoOhlaHRtdHQQQXLfyqxVS5eGrsyahuQ+oLoprAh1MLEA1oZANDFGB1YMO1gbMNwSIhrqiubmgQo/KkIs7gMAROTJ4Jr5QIMAAAAASUVORK5CYII=',
			'9364' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7WANYQxhCGRoCkMREpoi0Mjo6NCKLBbQyNLo2OLSiibWyNjBMCUBy37Spq8KWTl0VFYXkPlZXoDpHRwdkvQxg8wJDQ5DEBMBiAdjcgiKGzc0DFX5UhFjcBwDGjs103EVBMQAAAABJRU5ErkJggg==',
			'BFB4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXElEQVR4nGNYhQEaGAYTpIn7QgNEQ11DGRoCkMQCpog0sDY6NKKItQLFgCQWdVMCkNwXGjU1bGnoqqgoJPdB1Dk6YJoXGBqCaQc2t6CIhQYAxdDcPFDhR0WIxX0ALOzQMERyNY8AAAAASUVORK5CYII=',
			'C36C' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7WENYQxhCGaYGIImJtIq0Mjo6BIggiQU0MjS6Njg6sCCLNTC0sjYwOiC7L2rVqrClU1dmIbsPrM7R0YEBVS/QvEBUsUaIGLId2NyCzc0DFX5UhFjcBwA1l8t0RQN//gAAAABJRU5ErkJggg==',
			'EA6F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7QkMYAhhCGUNDkMQCGhhDGB0dHRhQxFhbWRvQxUQaXRsYYWJgJ4VGTVuZOnVlaBaS+8DqMMwTDXVtCMRiHqaYI5re0BCRRodQRhSxgQo/KkIs7gMAC6TLeZFG60MAAAAASUVORK5CYII=',
			'F277' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7QkMZQ1hDA0NDkMQCGlhbQaQIiphIowOGGEOjA1gU4b7QqFVLgXBlFpL7gPJTgLCVAVVvABBOQRVjdGB0AIqiugUIgaIoYqKhrmhiAxV+VIRY3AcA5LzND1HTUy4AAAAASUVORK5CYII=',
			'E3BE' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAU0lEQVR4nGNYhQEaGAYTpIn7QkNYQ1hDGUMDkMQCGkRaWRsdHRhQxBgaXRsC0cWQ1YGdFBq1Kmxp6MrQLCT3oanDZx4WMUy3YHPzQIUfFSEW9wEA0d/L7SjWJl8AAAAASUVORK5CYII=',
			'B59F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7QgNEQxlCGUNDkMQCpog0MDo6OiCrC2gVaWBtCEQVmyISgiQGdlJo1NSlKzMjQ7OQ3BcwhaHRIQRNbytQDN28VpFGRww7WFvR3RIawBgCdDOK2ECFHxUhFvcBABMEyzYk8YRBAAAAAElFTkSuQmCC',
			'C757' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7WENEQ11DHUNDkMREWhkaXUE0klhAIxaxBoZW1qlgGu6+qFWrpi3NzFqZheQ+oHwAkGxlQNHL6AAkp6CINbI2sDYEBCCLibSKNDA6OjqguhnoilBGFLGBCj8qQizuAwCIA8wWkravkQAAAABJRU5ErkJggg==',
			'98B4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDGRoCkMREprC2sjY6NCKLBbSKNLoCSVQxsLopAUjumzZ1ZdjS0FVRUUjuY3UFqXN0QNbLADYvMDQESUwAYgc2t6CIYXPzQIUfFSEW9wEADAnOdu3YwOYAAAAASUVORK5CYII=',
			'8FB2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAY0lEQVR4nGNYhQEaGAYTpIn7WANEQ11DGaY6IImJTBFpYG10CAhAEgtoBYo1BDqIYKprEEFy39KoqWFLQ1etikJyH1RdowOGeQGtDJhiUxiwuAXVzUCxUMbQkEEQflSEWNwHAMwXzW1kssltAAAAAElFTkSuQmCC',
			'F948' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7QkMZQxgaHaY6IIkFNLC2MrQ6BASgiIkAVTk6iKCLBcLVgZ0UGrV0aWZm1tQsJPcFNDAGujaim8fQ6BoaiGYeS6NDI7odQLdg6MV080CFHxUhFvcBAJfAzvHr3Nx+AAAAAElFTkSuQmCC',
			'6C91' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7WAMYQxlCGVqRxUSmsDY6OjpMRRYLaBFpcG0ICEURaxBpYG0IgOkFOykyatqqlZlRS5HdFzJFpIEhJADFjoBWETCJLuaIJgZ1C4oY1M2hAYMg/KgIsbgPADCBzQ+C6ufFAAAAAElFTkSuQmCC',
			'4240' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nGNYhQEaGAYTpI37pjCGMDQ6tKKIhbC2MrQ6THVAEmMMEWkEigQEIImxTgHqDHR0EEFy37Rpq5auzMzMmobkvoApDFNYG+HqwDA0lCGANTQQRQzoFgegiSh2AHU2MDSiuoVhimioA7qbByr8qAexuA8Axj3MvGbgv3IAAAAASUVORK5CYII=',
			'973A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nM2QMQ6AMAhF6cDugPehgzsm9hKegg69ge0d7Ck1caHqqFF+wvAC5AWol1L4U17xQ+mDD5AsowXiEDmzYZIgsopIy3bqmYxfybXUvM7F+OEAYuaOJMegY5gM6xLufWzmaCHF0y4KqQuuvffR/x7Mjd8GfYfMDKktywAAAAAASUVORK5CYII=',
			'B8E4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAW0lEQVR4nGNYhQEaGAYTpIn7QgMYQ1hDHRoCkMQCprC2sjYwNKKItYo0ujYwtGJRNyUAyX2hUSvDloauiopCch9EHaMDpnmMoSGYdmBzC4oYNjcPVPhREWJxHwB0sM7XzRBqAQAAAABJRU5ErkJggg==',
			'5E59' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7QkNEQ1lDHaY6IIkFNIg0sDYwBARgiDE6iCCJBQYAxabCxcBOCps2NWxpZlZUGLL7WkEqAqYi64WKNSCLBbSC7AhAsUNkikgDo6MDiltYA0RDGUIZUNw8UOFHRYjFfQCUacufaR2nVQAAAABJRU5ErkJggg==',
			'B5FF' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7QgNEQ1lDA0NDkMQCpog0sDYwOiCrC2jFIjZFJARJDOyk0KipS5eGrgzNQnJfwBSGRlcM87CJiWCKTWFtRbc3NIAxBF1soMKPihCL+wBsXsqjaWgENQAAAABJRU5ErkJggg==',
			'0392' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7GB1YQxhCGaY6IImxBoi0Mjo6BAQgiYlMYWh0bQh0EEESC2hlaGVtCGgQQXJf1NJVYSszo1ZFIbkPpI4hJKDRAVUvkA8k0exwbAiYwoDFLZhuZgwNGQThR0WIxX0Am5LLtTdblrUAAAAASUVORK5CYII=',
			'4543' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nGNYhQEaGAYTpI37poiGMjQ6hDogi4WINDC0OjoEIIkxgsSmOjSIIImxThEJYQh0aAhAct+0aVOXrszMWpqF5L6AKQyNro1wdWAYCrTVNTQAxTyGKSKNDo0OaGKsrQyNqG5hmMIYguHmgQo/6kEs7gMABm3N0+ChKUAAAAAASUVORK5CYII=',
			'29C4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7WAMYQxhCHRoCkMREprC2MjoENCKLBbSKNLo2CLQiizGAxRimBCC7b9rSpamrVkVFIbsvgDHQtQFoIpJeRgcGoF7G0BBktzSwgOxAdUsD2C0oYqGhmG4eqPCjIsTiPgDNps138zSMYAAAAABJRU5ErkJggg==',
			'C8F8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7WEMYQ1hDA6Y6IImJtLK2sjYwBAQgiQU0ijS6NjA6iCCLNaCoAzspatXKsKWhq6ZmIbkPTR1UDIt5WOzA5hawmxsYUNw8UOFHRYjFfQA7Z8wz1TPRQQAAAABJRU5ErkJggg==',
			'F57B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7QkNFQ1lDA0MdkMQCGkSAZKBDABYxEVSxEIZGR5g6sJNCo6YuXbV0ZWgWkvuA8o0OUxjRzAOKBTCimwc0DV2MtZW1AV0vYwhQDMXNAxV+VIRY3AcAUjfM7oL2pgQAAAAASUVORK5CYII=',
			'0BB6' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7GB1EQ1hDGaY6IImxBoi0sjY6BAQgiYlMEWl0bQh0EEASC2gFqXN0QHZf1NKpYUtDV6ZmIbkPqg7FPKAY2DwRLHaIEHALNjcPVPhREWJxHwBbssxpqb43UAAAAABJRU5ErkJggg==',
			'B7E0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7QgNEQ11DHVqRxQKmMDS6NjBMdUAWawWLBQSgqmtlbWB0EEFyX2jUqmlLQ1dmTUNyH1BdAJI6qHmMDphirA2sGHaIgMRQ3BIaABRDc/NAhR8VIRb3AQBLgMzvPG9BpgAAAABJRU5ErkJggg==',
			'DC55' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7QgMYQ1lDHUMDkMQCprA2ujYwOiCrC2gVacAmxjqV0dUByX1RS6etWpqZGRWF5D6QOiDZIIKmF5uYa0OgA4oY0C2Ojg4ByO4DuZkhlGGqwyAIPypCLO4DAObEzbYhoRo0AAAAAElFTkSuQmCC',
			'DC33' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWklEQVR4nGNYhQEaGAYTpIn7QgMYQxlDGUIdkMQCprA2ujY6OgQgi7WKNDg0BDSIoIkxNIJEEe6LWjpt1aqpq5ZmIbkPTR1CDIt5GHZgcQs2Nw9U+FERYnEfACr60CtKNz/bAAAAAElFTkSuQmCC',
			'5B5F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7QkNEQ1hDHUNDkMQCGkRaWRsYHRhQxRpd0cQCA4DqpsLFwE4KmzY1bGlmZmgWsvtaRVqBqlH0AsUaHdDEAlpBdqCKiUwRaWV0dEQRYw0QDWEIRXXLQIUfFSEW9wEA0i3KD84i95oAAAAASUVORK5CYII=',
			'A8FE' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWklEQVR4nGNYhQEaGAYTpIn7GB0YQ1hDA0MDkMRYA1hbWYEyyOpEpog0uqKJBbSiqAM7KWrpyrCloStDs5Dch6YODENDsZlH0A6oGNDNDYwobh6o8KMixOI+ABAVyfIFizQSAAAAAElFTkSuQmCC',
			'1592' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAeElEQVR4nM2QsQ2AMAwE7SIbOPuYDYzkNGwAUzhFNoARKGBKQucISpDil7446aWT4XycQU/5xQ85JkiwsWOByXBgEcdiZcHG2n5LGkyMnN+xbPsxT+fk/JAhs0rmZluZSWldKA8ma8tCuV08i4oKCZN28L8P8+J3Ad06yZApuhUpAAAAAElFTkSuQmCC',
			'3965' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7RAMYQxhCGUMDkMQCprC2Mjo6OqCobBVpdG1AE5sCEmN0dUBy38qopUtTp66MikJ23xTGQFdHhwYRFPMYgHoD0MRYgGKBDiIYbnEIQHYfxM0MUx0GQfhREWJxHwAaCMuAF1TFXgAAAABJRU5ErkJggg==',
			'9C65' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7WAMYQxlCGUMDkMREprA2Ojo6OiCrC2gVaXBtwBRjbWB0dUBy37Sp01YtnboyKgrJfayuQHWODg0iyDaD9QagiAmA7Qh0EMFwi0MAsvsgbmaY6jAIwo+KEIv7AHajy7lML8L3AAAAAElFTkSuQmCC',
			'8AFD' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7WAMYAlhDA0MdkMREpjCGsDYwOgQgiQW0sraCxERQ1Ik0uiLEwE5aGjVtZWroyqxpSO5DUwc1TzQUUwxTHUwvsltYA8BiKG4eqPCjIsTiPgD/ssuARLLiUgAAAABJRU5ErkJggg==',
			'8A11' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAX0lEQVR4nGNYhQEaGAYTpIn7WAMYAhimMLQii4lMYQxhCGGYiiwW0MraChQNRVUn0uiA0At20tKoaSuzpq1aiuw+NHVQ80RDMcUw1WHTyxog0ugY6hAaMAjCj4oQi/sAQnfMsU2QCpsAAAAASUVORK5CYII=',
			'3784' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nM2QsQ2AMAwEP0U2IPs4Bb2RSJNpnCIbROyApyRlDJQg8HdX/J8MvZzgT3nFL3BIlCA8MG4oMVIZGSrKLFwNa6guUuPBb8+6adKcR78Gdr3Q9jnysqTVMC++m1iXSfqGYYEnwcn5q/89mBu/A8BfzVkkvLq8AAAAAElFTkSuQmCC',
			'1FA3' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAY0lEQVR4nGNYhQEaGAYTpIn7GB1EQx2mMIQ6IImxOog0MIQyOgQgiYkCxRgdHRpEUPSKNLA2BDQEILlvZdbUsKWropZmIbkPTR1CLDQAq3mYYoGobgkBq0Nx80CFHxUhFvcBAAk2yroAL62AAAAAAElFTkSuQmCC',
			'92DD' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDGUMdkMREprC2sjY6OgQgiQW0ijS6NgQ6iKCIMSCLgZ00beqqpUtXRWZNQ3IfqyvDFFY0vQytDAHoYgKtjA7oYkC3NKC7hTVANNQVzc0DFX5UhFjcBwCeqcueUJflqwAAAABJRU5ErkJggg==',
			'BE47' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaElEQVR4nGNYhQEaGAYTpIn7QgNEQxkaHUNDkMQCpog0MLQ6NIggi7UCeVPRxEDqAh0aApDcFxo1NWxlZtbKLCT3gdSxNjq0MqCZxxoaMAVdjKHRIYAB3Y5GRwcsbkYRG6jwoyLE4j4AjkXN2UuIXsMAAAAASUVORK5CYII=',
			'C576' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAc0lEQVR4nGNYhQEaGAYTpIn7WENEQ1lDA6Y6IImJtIoAyYCAACSxgEaQWKCDALJYg0gIQ6OjA7L7olZNXbpq6crULCT3Ac1pdJjCiGoeSCyA0UEE1Q6gaahiIq2srawNDCh6WUMYQ4BiKG4eqPCjIsTiPgC/W8x3pfIVUAAAAABJRU5ErkJggg==',
			'9C93' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7WAMYQxmA0AFJTGQKa6Ojo6NDAJJYQKtIg2tDQIMImhgrUCwAyX3Tpk5btTIzamkWkvtYXYG6QuDqILAVZBKqeQJAMUc0MWxuwebmgQo/KkIs7gMAa1LNGvyGQSwAAAAASUVORK5CYII=',
			'0E2D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7GB1EQxlCGUMdkMRYA0QaGB0dHQKQxESmiDSwNgQ6iCCJBbSCeHAxsJOilk4NW7UyM2sakvvA6loZMfVOQRUD2cEQgCoGdosDI4pbQG5mDQ1EcfNAhR8VIRb3AQD9aMmTvm9T+gAAAABJRU5ErkJggg==',
			'F0C8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXUlEQVR4nGNYhQEaGAYTpIn7QkMZAhhCHaY6IIkFNDCGMDoEBASgiLG2sjYIOoigiIk0ujYwwNSBnRQaNW1l6qpVU7OQ3IemDkmMEc08bHZgcwummwcq/KgIsbgPAFiEzSYJIshoAAAAAElFTkSuQmCC',
			'F6D2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7QkMZQ1hDGaY6IIkFNLC2sjY6BASgiIk0sjYEOoigijWwgkmE+0KjpoUtXRUFhAj3BTSItgLVNTqgmefaENDKgCk2hQGLW1DFQG5mDA0ZBOFHRYjFfQAEG86DNoSDjwAAAABJRU5ErkJggg==',
			'6E4F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7WANEQxkaHUNDkMREpog0MLQ6OiCrC2gBik1FE2sAigXCxcBOioyaGrYyMzM0C8l9IUDzWBvR9LYCxUIDMcQY0NSB3YImBnUzithAhR8VIRb3AQA4IcqEhECWuAAAAABJRU5ErkJggg==',
			'586A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nGNYhQEaGAYTpIn7QkMYQxhCGVqRxQIaWFsZHR2mOqCIiTS6NjgEBCCJBQawtrI2MDqIILkvbNrKsKVTV2ZNQ3ZfK1CdoyNMHVQMZF5gaAiyHRAxFHUiU0BuQdXLGgByMyOqeQMUflSEWNwHANJ7y6VgphieAAAAAElFTkSuQmCC',
			'1812' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7GB0YQximMEx1QBJjdWBtZQhhCAhAEhN1EGl0DGF0EEHRC1Q3haFBBMl9K7NWhq2atmpVFJL7oOoaHVD0ijQ6TGFoZcAUm8KAaUcAsphoCGMIY6hjaMggCD8qQizuAwAmNckOE/E7nwAAAABJRU5ErkJggg==',
			'A57A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7GB1EQ1lDA1qRxVgDRIBkwFQHJDGRKWCxgAAksYBWkRCGRkcHEST3RS2dunTV0pVZ05DcBzS90WEKI0wdGIaGAsUCGENDUM0DmoaqLqCVtZW1AV2MMQRdbKDCj4oQi/sAZpDMRNirn04AAAAASUVORK5CYII=',
			'E9FF' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAVklEQVR4nGNYhQEaGAYTpIn7QkMYQ1hDA0NDkMQCGlhbWRsYHRhQxEQaXfGLgZ0UGrV0aWroytAsJPcFNDAGYuplwGIeCxYxTLeA3YwmNlDhR0WIxX0AN83KbBLA08oAAAAASUVORK5CYII=',
			'B5C4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7QgNEQxlCHRoCkMQCpog0MDoENKKItYo0sDYItKKpC2FtYJgSgOS+0KipS5euWhUVheS+gCkMja4gE1HMA4uFhqDaARQTQHMLaytIJ7JYaABjCLqbByr8qAixuA8ANwvPdPOrbUAAAAAASUVORK5CYII=',
			'7FA1' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXUlEQVR4nGNYhQEaGAYTpIn7QkNFQx2mMLSiiLaKNDCEMkxFF2N0dAhFEZsi0sDaEADTC3FT1NSwpauiliK7j9EBRR0YsjYAxUJRxUQaMNUF4BYLDRgE4UdFiMV9AFQezKlI0bMaAAAAAElFTkSuQmCC',
			'114D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAY0lEQVR4nGNYhQEaGAYTpIn7GB0YAhgaHUMdkMRYHRgDGFodHQKQxEQdWAMYpjo6iKDrDYSLgZ20MmtV1MrMzKxpSO4DqWNtxNTLGhqIaR4WdSAxFLeEsIaiu3mgwo+KEIv7AHKJxtzQ2JbJAAAAAElFTkSuQmCC',
			'4234' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAc0lEQVR4nM2QsRGAMAhFScEGug/ZAO9Ck2lI4QaYDWwypdoRtdRTfvfuc7wD2mUU/pR3/CykIKDsWcIZCxXPQhoKKc+eocHeImPnV2tb29Jydn5ssDcj+V0RYNBJUu9Ch0nnYqh4XO7YKPHs/NX/nsuN3wbyG8576cF6dQAAAABJRU5ErkJggg==',
			'88FA' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDA1qRxUSmsLayNjBMdUASC2gVaXRtYAgIwFDH6CCC5L6lUSvDloauzJqG5D40dUjmMYaGYIqhqMOmF+xmNLGBCj8qQizuAwAa/8sl/65B5AAAAABJRU5ErkJggg==',
			'2E89' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7WANEQxlCGaY6IImJTBFpYHR0CAhAEgtoFWlgbQh0EEHW3QpS5wgTg7hp2tSwVaGrosKQ3RcANm8qsl5GB5B5AQ3IYqwNYDEUO0QaMN0SGorp5oEKPypCLO4DADgGyrCtRTRlAAAAAElFTkSuQmCC',
			'2BBC' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7WANEQ1hDGaYGIImJTBFpZW10CBBBEgtoFWl0bQh0YEHW3QpS5+iA4r5pU8OWhq7MQnFfAIo6MGR0gJiH4pYGTDtEGjDdEhqK6eaBCj8qQizuAwCP98u3Yc8J4wAAAABJRU5ErkJggg==',
			'0287' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdUlEQVR4nM2QvRGAMAhGocgGcZ+ksKcIjSM4BSmyQVZIIVNKGU5LPeXr3vHzDtBLCfwpr/hhwgKMXCYWKDTMSeLEYo91FXKMGtRsfTT5bUOHsh775Gd93fY18LMUhDq4G5iMEXgXQTvinRdOjI599b8Hc+N3AtBWytd8ad83AAAAAElFTkSuQmCC',
			'E4E3' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYklEQVR4nGNYhQEaGAYTpIn7QkMYWllDHUIdkMQCGhimsjYwOgSgioWyAmkRFDFGV1aIHNx9oVFLly4NXbU0C8l9AQ0irUjqoGKioa4Y5jG0YtoBEkN1CzY3D1T4URFicR8AIrTM/5BF2ToAAAAASUVORK5CYII=',
			'EEC2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7QkNEQxlCHaY6IIkFNIg0MDoEBASgibE2CDqIYIgxNIgguS80amrYUiAdheQ+qLpGdDuAYq0MGGICU9DFQG7BdLNjaMggCD8qQizuAwBDcMz7cr0oUgAAAABJRU5ErkJggg==',
			'630B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaElEQVR4nGNYhQEaGAYTpIn7WANYQximMIY6IImJTBFpZQhldAhAEgtoYWh0dHR0EEEWa2BoZW0IhKkDOykyalXY0lWRoVlI7guZgqIOoreVodEVKCaCJoZuBza3YHPzQIUfFSEW9wEAUpDLisFHK50AAAAASUVORK5CYII=',
			'3C40' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7RAMYQxkaHVqRxQKmsAJFHKY6IKtsFWkAigQEIItNEWlgCHR0EEFy38qoaatWZmZmTUN2H1AdayNcHdw81tBADDGHRlQ7wG5pRHULNjcPVPhREWJxHwDRBc2AJxejvAAAAABJRU5ErkJggg==',
			'0F3E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXUlEQVR4nGNYhQEaGAYTpIn7GB1EQx1DGUMDkMRYA0QaWBsdHZDViUwRAZKBKGIBrUAxhDqwk6KWTg1bNXVlaBaS+9DUIcTQzMNmBza3MDqINDCiuXmgwo+KEIv7AOwLyl7BnV4IAAAAAElFTkSuQmCC',
			'8FD9' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7WANEQ11DGaY6IImJTBFpYG10CAhAEgtoBYo1BDqIoKtDiIGdtDRqatjSVVFRYUjug6gLmCqCYV5AAxYxTDvQ3MIaABRDc/NAhR8VIRb3AQBc980v4zmLPgAAAABJRU5ErkJggg==',
			'F68A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7QkMZQxhCGVqRxQIaWFsZHR2mOqCIiTSyNgQEBKCKNTA6OjqIILkvNGpa2KrQlVnTkNwX0CDaiqQObp5rQ2BoCKYYmjpWLHpBbmZEERuo8KMixOI+AHiSzGHj9/kuAAAAAElFTkSuQmCC'        
        );
        $this->text = array_rand( $images );
        return $images[ $this->text ] ;    
    }
    
    function out_processing_gif(){
        $image = dirname(__FILE__) . '/processing.gif';
        $base64_image = "R0lGODlhFAAUALMIAPh2AP+TMsZiALlcAKNOAOp4ANVqAP+PFv///wAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFCgAIACwAAAAAFAAUAAAEUxDJSau9iBDMtebTMEjehgTBJYqkiaLWOlZvGs8WDO6UIPCHw8TnAwWDEuKPcxQml0Ynj2cwYACAS7VqwWItWyuiUJB4s2AxmWxGg9bl6YQtl0cAACH5BAUKAAgALAEAAQASABIAAAROEMkpx6A4W5upENUmEQT2feFIltMJYivbvhnZ3Z1h4FMQIDodz+cL7nDEn5CH8DGZhcLtcMBEoxkqlXKVIgAAibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkphaA4W5upMdUmDQP2feFIltMJYivbvhnZ3V1R4BNBIDodz+cL7nDEn5CH8DGZAMAtEMBEoxkqlXKVIg4HibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpjaE4W5tpKdUmCQL2feFIltMJYivbvhnZ3R0A4NMwIDodz+cL7nDEn5CH8DGZh8ONQMBEoxkqlXKVIgIBibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpS6E4W5spANUmGQb2feFIltMJYivbvhnZ3d1x4JMgIDodz+cL7nDEn5CH8DGZgcBtMMBEoxkqlXKVIggEibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpAaA4W5vpOdUmFQX2feFIltMJYivbvhnZ3V0Q4JNhIDodz+cL7nDEn5CH8DGZBMJNIMBEoxkqlXKVIgYDibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpz6E4W5tpCNUmAQD2feFIltMJYivbvhnZ3R1B4FNRIDodz+cL7nDEn5CH8DGZg8HNYMBEoxkqlXKVIgQCibbK9YLBYvLtHH5K0J0IACH5BAkKAAgALAEAAQASABIAAAROEMkpQ6A4W5spIdUmHQf2feFIltMJYivbvhnZ3d0w4BMAIDodz+cL7nDEn5CH8DGZAsGtUMBEoxkqlXKVIgwGibbK9YLBYvLtHH5K0J0IADs=";
        $binary = is_file($image) ? join("",file($image)) : base64_decode($base64_image); 
        header("Cache-Control: post-check=0, pre-check=0, max-age=0, no-store, no-cache, must-revalidate");
        header("Pragma: no-cache");
        header("Content-type: image/gif");
        echo $binary;
    }

}
# end of class phpfmgImage
# ------------------------------------------------------
# end of module : captcha


# module user
# ------------------------------------------------------
function phpfmg_user_isLogin(){
    return ( isset($_SESSION['authenticated']) && true === $_SESSION['authenticated'] );
}


function phpfmg_user_logout(){
    session_destroy();
    header("Location: admin.php");
}

function phpfmg_user_login()
{
    if( phpfmg_user_isLogin() ){
        return true ;
    };
    
    $sErr = "" ;
    if( 'Y' == $_POST['formmail_submit'] ){
        if(
            defined( 'PHPFMG_USER' ) && strtolower(PHPFMG_USER) == strtolower($_POST['Username']) &&
            defined( 'PHPFMG_PW' )   && strtolower(PHPFMG_PW) == strtolower($_POST['Password']) 
        ){
             $_SESSION['authenticated'] = true ;
             return true ;
             
        }else{
            $sErr = 'Login failed. Please try again.';
        }
    };
    
    // show login form 
    phpfmg_admin_header();
?>
<form name="frmFormMail" action="" method='post' enctype='multipart/form-data'>
<input type='hidden' name='formmail_submit' value='Y'>
<br><br><br>

<center>
<div style="width:380px;height:260px;">
<fieldset style="padding:18px;" >
<table cellspacing='3' cellpadding='3' border='0' >
	<tr>
		<td class="form_field" valign='top' align='right'>Email :</td>
		<td class="form_text">
            <input type="text" name="Username"  value="<?php echo $_POST['Username']; ?>" class='text_box' >
		</td>
	</tr>

	<tr>
		<td class="form_field" valign='top' align='right'>Password :</td>
		<td class="form_text">
            <input type="password" name="Password"  value="" class='text_box'>
		</td>
	</tr>

	<tr><td colspan=3 align='center'>
        <input type='submit' value='Login'><br><br>
        <?php if( $sErr ) echo "<span style='color:red;font-weight:bold;'>{$sErr}</span><br><br>\n"; ?>
        <a href="admin.php?mod=mail&func=request_password">I forgot my password</a>   
    </td></tr>
</table>
</fieldset>
</div>
<script type="text/javascript">
    document.frmFormMail.Username.focus();
</script>
</form>
<?php
    phpfmg_admin_footer();
}


function phpfmg_mail_request_password(){
    $sErr = '';
    if( $_POST['formmail_submit'] == 'Y' ){
        if( strtoupper(trim($_POST['Username'])) == strtoupper(trim(PHPFMG_USER)) ){
            phpfmg_mail_password();
            exit;
        }else{
            $sErr = "Failed to verify your email.";
        };
    };
    
    $n1 = strpos(PHPFMG_USER,'@');
    $n2 = strrpos(PHPFMG_USER,'.');
    $email = substr(PHPFMG_USER,0,1) . str_repeat('*',$n1-1) . 
            '@' . substr(PHPFMG_USER,$n1+1,1) . str_repeat('*',$n2-$n1-2) . 
            '.' . substr(PHPFMG_USER,$n2+1,1) . str_repeat('*',strlen(PHPFMG_USER)-$n2-2) ;


    phpfmg_admin_header("Request Password of Email Form Admin Panel");
?>
<form name="frmRequestPassword" action="admin.php?mod=mail&func=request_password" method='post' enctype='multipart/form-data'>
<input type='hidden' name='formmail_submit' value='Y'>
<br><br><br>

<center>
<div style="width:580px;height:260px;text-align:left;">
<fieldset style="padding:18px;" >
<legend>Request Password</legend>
Enter Email Address <b><?php echo strtoupper($email) ;?></b>:<br />
<input type="text" name="Username"  value="<?php echo $_POST['Username']; ?>" style="width:380px;">
<input type='submit' value='Verify'><br>
The password will be sent to this email address. 
<?php if( $sErr ) echo "<br /><br /><span style='color:red;font-weight:bold;'>{$sErr}</span><br><br>\n"; ?>
</fieldset>
</div>
<script type="text/javascript">
    document.frmRequestPassword.Username.focus();
</script>
</form>
<?php
    phpfmg_admin_footer();    
}


function phpfmg_mail_password(){
    phpfmg_admin_header();
    if( defined( 'PHPFMG_USER' ) && defined( 'PHPFMG_PW' ) ){
        $body = "Here is the password for your form admin panel:\n\nUsername: " . PHPFMG_USER . "\nPassword: " . PHPFMG_PW . "\n\n" ;
        if( 'html' == PHPFMG_MAIL_TYPE )
            $body = nl2br($body);
        mailAttachments( PHPFMG_USER, "Password for Your Form Admin Panel", $body, PHPFMG_USER, 'You', "You <" . PHPFMG_USER . ">" );
        echo "<center>Your password has been sent.<br><br><a href='admin.php'>Click here to login again</a></center>";
    };   
    phpfmg_admin_footer();
}


function phpfmg_writable_check(){
 
    if( is_writable( dirname(PHPFMG_SAVE_FILE) ) && is_writable( dirname(PHPFMG_EMAILS_LOGFILE) )  ){
        return ;
    };
?>
<style type="text/css">
    .fmg_warning{
        background-color: #F4F6E5;
        border: 1px dashed #ff0000;
        padding: 16px;
        color : black;
        margin: 10px;
        line-height: 180%;
        width:80%;
    }
    
    .fmg_warning_title{
        font-weight: bold;
    }

</style>
<br><br>
<div class="fmg_warning">
    <div class="fmg_warning_title">Your form data or email traffic log is NOT saving.</div>
    The form data (<?php echo PHPFMG_SAVE_FILE ?>) and email traffic log (<?php echo PHPFMG_EMAILS_LOGFILE?>) will be created automatically when the form is submitted. 
    However, the script doesn't have writable permission to create those files. In order to save your valuable information, please set the directory to writable.
     If you don't know how to do it, please ask for help from your web Administrator or Technical Support of your hosting company.   
</div>
<br><br>
<?php
}


function phpfmg_log_view(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );
    
    phpfmg_admin_header();
   
    $file = $files[$n];
    if( is_file($file) ){
        if( 1== $n ){
            echo "<pre>\n";
            echo join("",file($file) );
            echo "</pre>\n";
        }else{
            $man = new phpfmgDataManager();
            $man->displayRecords();
        };
     

    }else{
        echo "<b>No form data found.</b>";
    };
    phpfmg_admin_footer();
}


function phpfmg_log_download(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );

    $file = $files[$n];
    if( is_file($file) ){
        phpfmg_util_download( $file, PHPFMG_SAVE_FILE == $file ? 'form-data.csv' : 'email-traffics.txt', true, 1 ); // skip the first line
    }else{
        phpfmg_admin_header();
        echo "<b>No email traffic log found.</b>";
        phpfmg_admin_footer();
    };

}


function phpfmg_log_delete(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );
    phpfmg_admin_header();

    $file = $files[$n];
    if( is_file($file) ){
        echo unlink($file) ? "It has been deleted!" : "Failed to delete!" ;
    };
    phpfmg_admin_footer();
}


function phpfmg_util_download($file, $filename='', $toCSV = false, $skipN = 0 ){
    if (!is_file($file)) return false ;

    set_time_limit(0);


    $buffer = "";
    $i = 0 ;
    $fp = @fopen($file, 'rb');
    while( !feof($fp)) { 
        $i ++ ;
        $line = fgets($fp);
        if($i > $skipN){ // skip lines
            if( $toCSV ){ 
              $line = str_replace( chr(0x09), ',', $line );
              $buffer .= phpfmg_data2record( $line, false );
            }else{
                $buffer .= $line;
            };
        }; 
    }; 
    fclose ($fp);
  

    
    /*
        If the Content-Length is NOT THE SAME SIZE as the real conent output, Windows+IIS might be hung!!
    */
    $len = strlen($buffer);
    $filename = basename( '' == $filename ? $file : $filename );
    $file_extension = strtolower(substr(strrchr($filename,"."),1));

    switch( $file_extension ) {
        case "pdf": $ctype="application/pdf"; break;
        case "exe": $ctype="application/octet-stream"; break;
        case "zip": $ctype="application/zip"; break;
        case "doc": $ctype="application/msword"; break;
        case "xls": $ctype="application/vnd.ms-excel"; break;
        case "ppt": $ctype="application/vnd.ms-powerpoint"; break;
        case "gif": $ctype="image/gif"; break;
        case "png": $ctype="image/png"; break;
        case "jpeg":
        case "jpg": $ctype="image/jpg"; break;
        case "mp3": $ctype="audio/mpeg"; break;
        case "wav": $ctype="audio/x-wav"; break;
        case "mpeg":
        case "mpg":
        case "mpe": $ctype="video/mpeg"; break;
        case "mov": $ctype="video/quicktime"; break;
        case "avi": $ctype="video/x-msvideo"; break;
        //The following are for extensions that shouldn't be downloaded (sensitive stuff, like php files)
        case "php":
        case "htm":
        case "html": 
                $ctype="text/plain"; break;
        default: 
            $ctype="application/x-download";
    }
                                            

    //Begin writing headers
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: public"); 
    header("Content-Description: File Transfer");
    //Use the switch-generated Content-Type
    header("Content-Type: $ctype");
    //Force the download
    header("Content-Disposition: attachment; filename=".$filename.";" );
    header("Content-Transfer-Encoding: binary");
    header("Content-Length: ".$len);
    
    while (@ob_end_clean()); // no output buffering !
    flush();
    echo $buffer ;
    
    return true;
 
    
}
?>